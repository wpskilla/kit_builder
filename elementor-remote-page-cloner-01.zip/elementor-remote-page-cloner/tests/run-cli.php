<?php
if ( PHP_SAPI !== "cli" ) { exit; } // CLI-only engine test: php tests/run-cli.php
define('ABSPATH', __DIR__);
foreach (['util','css-parser','dom','registry','env','detector','style-mapper','widgets','converter','validator'] as $f) require __DIR__."/../includes/class-$f.php";
$html = file_get_contents(__DIR__.'/fixture.html');
$det = new ERPC\Detector($html, 'https://wdldistribution.com/about-us/');
$a = $det->analyse();
echo json_encode(['main'=>$a['main_doc'],'kit'=>$a['kit_id'],'el'=>$a['elementor'],'docs'=>$a['documents'],'plugins'=>$a['plugins'],'unknown'=>$a['unknown_widgets'],'css'=>array_map(fn($s)=>$s['kind'].':'.$s['url'],$a['css_sources']),'fonts'=>$a['font_links'],'bp'=>$a['breakpoints']], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES), "\n";
$sources=[];
foreach ($a['css_sources'] as $s) { $c = strpos($s['url'],'post-6')? file_get_contents(__DIR__.'/kit.css') : (strpos($s['url'],'post-120')? file_get_contents(__DIR__.'/post.css') : ($s['inline']??'')); $s['content']=$c; $sources[]=$s; }
class TEnv extends ERPC\Env { function widget_exists(string $t): ?bool { return !str_starts_with($t,'elementskit'); } }
$conv = new ERPC\Converter($det->dom(), $a, $sources, new TEnv(), []);
$r = $conv->convert_document($a['main_doc']);
echo json_encode($r['elements'], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES), "\n";
echo "LAYER:\n", $r['layer'], "\n";
echo json_encode(['assets'=>$r['assets'],'report'=>$r['report'],'icons'=>$r['icon_libs'],'fbp'=>$r['fallback_plugins'],'inline'=>array_keys($r['inline'])], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES), "\n";
