<?php
namespace ERPC;

defined( 'ABSPATH' ) || exit;

/**
 * Installs/activates the plugins a cloned page needs, Envato-kit style.
 */
class Installer {

	private static function load_wp(): void {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	}

	/** Find the main plugin file for a slug ("folder/file.php") or null. */
	public static function plugin_file( string $slug ): ?string {
		self::load_wp();
		foreach ( array_keys( get_plugins() ) as $file ) {
			if ( 0 === strpos( $file, $slug . '/' ) ) {
				return $file;
			}
		}
		return null;
	}

	/** @return array ['status'=>'active'|'installed'|'missing','version'=>string] */
	public static function status( string $slug ): array {
		self::load_wp();
		$file = self::plugin_file( $slug );
		if ( ! $file ) {
			return [ 'status' => 'missing', 'version' => '' ];
		}
		$data = get_plugins()[ $file ] ?? [];
		return [
			'status'  => is_plugin_active( $file ) ? 'active' : 'installed',
			'version' => $data['Version'] ?? '',
		];
	}

	/**
	 * Install from wordpress.org (if missing) and activate.
	 *
	 * @return true|\WP_Error
	 */
	public static function install_and_activate( string $slug ) {
		self::load_wp();
		if ( ! current_user_can( 'install_plugins' ) || ! current_user_can( 'activate_plugins' ) ) {
			return new \WP_Error( 'erpc_cap', __( 'You are not allowed to install plugins.', 'erpc' ) );
		}
		$slug = sanitize_key( $slug );
		$file = self::plugin_file( $slug );
		if ( ! $file ) {
			$api = plugins_api( 'plugin_information', [ 'slug' => $slug, 'fields' => [ 'sections' => false ] ] );
			if ( is_wp_error( $api ) ) {
				return $api;
			}
			$res = self::run_upgrader( $api->download_link );
			if ( is_wp_error( $res ) ) {
				return $res;
			}
			wp_clean_plugins_cache();
			$file = self::plugin_file( $slug );
			if ( ! $file ) {
				return new \WP_Error( 'erpc_install', __( 'Plugin installed but its main file was not found.', 'erpc' ) );
			}
		}
		return self::activate( $file );
	}

	/** Install a premium plugin from an uploaded ZIP (e.g. Elementor Pro). */
	public static function install_zip( string $zip_path ) {
		self::load_wp();
		if ( ! current_user_can( 'install_plugins' ) ) {
			return new \WP_Error( 'erpc_cap', __( 'You are not allowed to install plugins.', 'erpc' ) );
		}
		$before = array_keys( get_plugins() );
		$res    = self::run_upgrader( $zip_path, true );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		wp_clean_plugins_cache();
		$new = array_diff( array_keys( get_plugins() ), $before );
		$file = $new ? reset( $new ) : null;
		if ( ! $file ) {
			return new \WP_Error( 'erpc_install', __( 'The ZIP did not contain a new plugin (it may already be installed – activate it from Plugins).', 'erpc' ) );
		}
		$act = self::activate( $file );
		return is_wp_error( $act ) ? $act : $file;
	}

	private static function run_upgrader( string $package, bool $overwrite = false ) {
		$skin     = new \WP_Ajax_Upgrader_Skin();
		$upgrader = new \Plugin_Upgrader( $skin );
		$result   = $upgrader->install( $package, [ 'overwrite_package' => $overwrite ] );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		if ( is_wp_error( $skin->result ) ) {
			return $skin->result;
		}
		if ( $skin->get_errors()->has_errors() ) {
			return $skin->get_errors();
		}
		if ( ! $result ) {
			global $wp_filesystem;
			if ( $wp_filesystem instanceof \WP_Filesystem_Base && is_wp_error( $wp_filesystem->errors ) && $wp_filesystem->errors->has_errors() ) {
				return $wp_filesystem->errors;
			}
			return new \WP_Error( 'erpc_install', __( 'Installation failed. The server may require FTP credentials (define FS_METHOD "direct") or file permissions are restricted.', 'erpc' ) );
		}
		return true;
	}

	/** Activate silently and suppress add-on "welcome" redirects. */
	private static function activate( string $file ) {
		if ( is_plugin_active( $file ) ) {
			return true;
		}
		global $wpdb;
		$before = $wpdb->get_col( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE '%redirect%'" );
		$res    = activate_plugin( $file, '', false, false );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$after = $wpdb->get_col( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE '%redirect%'" );
		foreach ( array_diff( $after, $before ) as $opt ) {
			if ( preg_match( '/(activation|welcome|do_|onboard|redirect_to)/i', $opt ) ) {
				delete_option( $opt );
			}
		}
		delete_transient( 'elementor_activation_redirect' );
		return true;
	}

	/** Elementor experiments the clone depends on. */
	public static function features(): array {
		return [
			'container'       => __( 'Flexbox Container', 'erpc' ),
			'nested-elements' => __( 'Nested Elements (nested tabs/accordion)', 'erpc' ),
		];
	}

	public static function feature_active( string $key ): bool {
		if ( ! class_exists( '\Elementor\Plugin' ) ) {
			return false;
		}
		return \Elementor\Plugin::$instance->experiments->is_feature_active( $key );
	}

	public static function activate_feature( string $key ) {
		if ( ! current_user_can( 'manage_options' ) || ! array_key_exists( $key, self::features() ) ) {
			return new \WP_Error( 'erpc_feature', __( 'Unknown feature.', 'erpc' ) );
		}
		update_option( 'elementor_experiment-' . $key, 'active' );
		if ( 'nested-elements' === $key ) {
			update_option( 'elementor_experiment-container', 'active' );
		}
		return true;
	}
}
