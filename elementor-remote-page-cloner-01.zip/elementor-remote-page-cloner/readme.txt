=== Elementor Remote Page Cloner ===
Requires at least: 6.2
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Clone one public Elementor page from any URL into an editable Elementor page on this site — no access to the source site's admin or editor needed.

== How to use ==

1. Upload the ZIP in Plugins › Add New › Upload, activate.
2. Open "Page Cloner" in the admin menu.
3. Paste the source page URL, confirm you have permission, click "Analyze page".
4. Review the report: stack, documents found (page content, header/footer templates), every widget marked
   "native" (rebuilt as a real Elementor widget) or "static" (exact-looking HTML fallback), and the
   required-plugins table. Click "Install & activate all required". Premium plugins (Elementor Pro) can be
   installed by uploading their ZIP in the same table. Activate "Flexbox Container" if asked.
5. Choose options (new page / replace an existing page / library template, status, template, media, fidelity).
6. Click "Clone now". Then "Edit with Elementor". Every clone can be undone from the result or the History tab.

== How it works ==

Elementor pages expose their structure publicly:
* data-id / data-element_type / data-widget_type / data-settings in the HTML → element tree & widget types
* uploads/elementor/css/post-ID.css and the kit CSS → nearly every style setting, keyed by element id

The plugin
* rebuilds content into real widget settings (25+ core widgets + Pro form),
* reverse-maps CSS into real Elementor controls (typography, colours, spacing, borders, shadows,
  backgrounds/gradients, container flex/grid, column widths, tablet/mobile values),
* validates every setting against the installed Elementor's live control definitions,
* keeps the full source CSS as a scoped "style layer" on the new page (source element ids are kept so
  selectors line up). In Editable mode the layer loads before Elementor's CSS: unmapped details render
  exactly, while your edits in Elementor always win. Locked mode loads it last.
* imports images, SVGs (sanitised) and fonts in batches, rewrites internal links to this site.

== Extending ==

* Add plugins/prefixes in data/plugin-registry.json or via the `erpc_plugin_registry` filter.
* Add native translators for add-on widgets:
  add_filter( 'erpc_widget_translators', function ( $t ) {
      $t['eael-creative-button'] = function ( $node, $root, $data_settings, $converter ) {
          return [ 'creative_button_text' => trim( $root->textContent ) ];
      };
      return $t;
  } );

== Limits ==

* Source must be built with Elementor (other builders are rejected with a clear message).
* Add-on widgets (ElementsKit, Essential Addons, Happy, Premium, PowerPack, Qi, MetForm …) and most Pro
  widgets are reproduced as static HTML that looks identical but is not editable as that widget, until a
  translator is added. MetForm / Pro forms need their actions (email etc.) configured after import.
* JS-driven behaviour of static fallbacks (sliders, counters of add-ons) is not re-initialised.
* Shape dividers and some motion effects may need a manual touch.
* Pages behind bot challenges (Cloudflare "checking your browser") cannot be fetched.
* The style layer is printed by this plugin: keep it active on sites that use cloned pages.

== Legal ==

Only clone pages you own or have written permission to reuse. Images, fonts and text remain the property
of their owners.
