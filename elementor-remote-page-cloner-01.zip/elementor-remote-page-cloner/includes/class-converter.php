<?php
namespace ERPC;

defined( 'ABSPATH' ) || exit;

/**
 * Turns the rendered Elementor DOM + generated CSS into `_elementor_data`.
 *
 * Strategy (the "fidelity sandwich"):
 *  1. Element ids are kept from the source, so Elementor's own selector scheme lines up.
 *  2. Content → real widget settings (Widgets), CSS → real control settings (Style_Mapper).
 *  3. The *complete* source CSS is kept as a scoped "style layer" (doc ids rewritten to the
 *     new page) printed before Elementor's CSS: whatever was not mapped still renders
 *     exactly, while edits made in Elementor still win (same specificity, later in cascade).
 */
class Converter {

	const DOC_TOKEN = '{{ERPC_DOC}}';

	/** @var Dom */
	public $dom;
	/** @var Env */
	public $env;
	public $base;
	public $opts;
	public $icon_libs  = [];
	public $inline     = [];
	private $analysis;
	private $sources;
	private $blocks    = [];
	private $vars      = [];
	/** @var Style_Mapper */
	private $mapper;
	/** @var Widgets */
	private $widgets;
	private $report;

	/**
	 * @param array $sources list of ['url','kind','doc_id','content']
	 */
	public function __construct( Dom $dom, array $analysis, array $sources, Env $env, array $opts = [] ) {
		$this->dom      = $dom;
		$this->analysis = $analysis;
		$this->sources  = $sources;
		$this->env      = $env;
		$this->base     = $analysis['url'];
		$this->opts     = $opts;
		$this->reset_report();
		$this->parse_sources();
		$this->mapper  = new Style_Mapper( $this->post_blocks(), $this->vars, $analysis['breakpoints'] );
		$this->widgets = new Widgets( $this );
	}

	private function reset_report(): void {
		$this->report = [
			'native'    => [],
			'fallbacks' => [],
			'warnings'  => [],
			'counts'    => [ 'elements' => 0, 'widgets' => 0, 'native' => 0, 'fallback' => 0 ],
		];
	}

	public function warn( string $msg ): void {
		$this->report['warnings'][] = $msg;
	}

	/* ------------------------------------------------------------ CSS sources */

	private function parse_sources(): void {
		foreach ( $this->sources as $i => $src ) {
			$base = 0 === strpos( $src['url'], 'inline:' ) ? $this->base : $src['url'];
			$css  = Css_Parser::absolutize_urls( (string) $src['content'], $base );
			$kind = $src['kind'];
			if ( 'post' === $kind && (int) $src['doc_id'] === (int) $this->analysis['kit_id'] ) {
				$kind = 'kit';
			}
			$this->sources[ $i ]['kind'] = $kind;
			$this->blocks[ $i ]          = Css_Parser::parse( $css );
			foreach ( $this->blocks[ $i ] as $b ) {
				if ( 'rule' !== $b['type'] ) {
					continue;
				}
				foreach ( $b['decls'] as [ $p, $v ] ) {
					if ( 0 === strpos( $p, '--e-global-' ) && '' === $b['media'] ) {
						$this->vars[ $p ] = $v;
					}
				}
			}
		}
		// Resolve vars that reference other vars.
		foreach ( $this->vars as $k => $v ) {
			if ( preg_match( '/^var\(\s*(--[\w-]+)/', $v, $m ) && isset( $this->vars[ $m[1] ] ) ) {
				$this->vars[ $k ] = $this->vars[ $m[1] ];
			}
		}
	}

	private function post_blocks(): array {
		$all = [];
		foreach ( $this->sources as $i => $src ) {
			if ( 'post' === $src['kind'] ) {
				foreach ( $this->blocks[ $i ] as $b ) {
					$all[] = $b;
				}
			}
		}
		return $all;
	}

	public function vars(): array {
		return $this->vars;
	}

	/* --------------------------------------------------------------- convert */

	/**
	 * Convert one document (by source doc id).
	 *
	 * @return array ['elements'=>[], 'layer'=>string, 'assets'=>[], 'report'=>[], 'icon_libs'=>[], 'fallback_plugins'=>[], 'inline'=>[]]
	 */
	public function convert_document( int $doc_id ): array {
		$this->reset_report();
		$this->icon_libs = [];
		$root            = null;
		foreach ( $this->dom->qa( $this->dom->doc, '[data-elementor-id]' ) as $r ) {
			if ( (int) $r->getAttribute( 'data-elementor-id' ) === $doc_id ) {
				$root = $r;
				break;
			}
		}
		if ( ! $root ) {
			return [ 'error' => 'Document #' . $doc_id . ' not found in page' ];
		}

		$elements = [];
		$uses_containers = false;
		foreach ( Dom::element_children( $root ) as $child ) {
			$el = $this->node( $child, 'root' );
			if ( $el ) {
				if ( 'container' === $el['elType'] ) {
					$uses_containers = true;
				}
				$elements[] = $el;
			}
		}
		// Root may only contain sections/containers.
		foreach ( $elements as $i => $el ) {
			if ( ! in_array( $el['elType'], [ 'section', 'container' ], true ) ) {
				$elements[ $i ] = $this->wrap_root( $el, $uses_containers || $this->env->container_active() );
			}
		}

		$doc_ids = array_merge( [ $doc_id ], $this->nested_doc_ids( $root ) );
		$layer   = $this->build_layer( $doc_ids );
		$assets  = $this->collect_assets( $elements, $layer );

		$fallback_plugins = [];
		foreach ( $this->report['fallbacks'] as $f ) {
			$slug = Registry::plugin_for_widget( $f['type'] );
			if ( $slug ) {
				$fallback_plugins[ $slug ] = true;
			}
		}

		return [
			'elements'         => $elements,
			'layer'            => $layer,
			'assets'           => $assets,
			'report'           => $this->report,
			'icon_libs'        => array_keys( $this->icon_libs ),
			'fallback_plugins' => array_keys( $fallback_plugins ),
			'inline'           => $this->inline,
		];
	}

	private function nested_doc_ids( \DOMElement $root ): array {
		$ids = [];
		foreach ( $this->dom->qa( $root, '[data-elementor-id]' ) as $n ) {
			$ids[] = (int) $n->getAttribute( 'data-elementor-id' );
		}
		return array_values( array_unique( $ids ) );
	}

	private function wrap_root( array $el, bool $container ): array {
		if ( $container ) {
			return [ 'id' => Util::gen_id(), 'elType' => 'container', 'isInner' => false, 'settings' => [ 'content_width' => 'full' ], 'elements' => [ $el ] ];
		}
		return [
			'id'       => Util::gen_id(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => [],
			'elements' => [ [ 'id' => Util::gen_id(), 'elType' => 'column', 'isInner' => false, 'settings' => [ '_column_size' => 100 ], 'elements' => [ $el ] ] ],
		];
	}

	/** Convert one Elementor element node. */
	private function node( \DOMElement $n, string $parent ): ?array {
		$type    = $n->getAttribute( 'data-element_type' );
		$id      = $n->getAttribute( 'data-id' );
		$classes = Dom::classes( $n );
		$ds      = json_decode( (string) $n->getAttribute( 'data-settings' ), true );
		$ds      = is_array( $ds ) ? $ds : [];
		$this->report['counts']['elements']++;

		if ( ! preg_match( '/^[0-9a-z]{5,10}$/i', $id ) ) {
			$id = Util::gen_id();
		}

		switch ( $type ) {
			case 'section':
				return $this->section( $n, $id, $classes, $ds, $parent );
			case 'column':
				return $this->column( $n, $id, $classes, $ds );
			case 'container':
				return $this->container( $n, $id, $classes, $ds, $parent );
			case 'widget':
				return $this->widget( $n, $id, $classes, $ds );
			default:
				// Unknown element types (e.g. new atomic elements) → static HTML widget.
				$fb = $this->widgets->fallback( $n, $n, $type ?: 'unknown', 'unsupported element type "' . $type . '"' );
				$this->report['fallbacks'][] = [ 'id' => $id, 'type' => $type, 'reason' => $fb['fallback'] ];
				$this->report['counts']['fallback']++;
				return [ 'id' => $id, 'elType' => 'widget', 'widgetType' => 'html', 'settings' => $fb['settings'], 'elements' => [] ];
		}
	}

	private function children( \DOMElement $n, string $as ): array {
		$out = [];
		foreach ( Dom::element_children( $n ) as $c ) {
			$el = $this->node( $c, $as );
			if ( $el ) {
				$out[] = $el;
			}
		}
		return $out;
	}

	private function section( \DOMElement $n, string $id, array $classes, array $ds, string $parent ): array {
		$s = [];
		$this->mapper->apply( $id, 'section', '', $s );
		if ( in_array( 'elementor-section-full_width', $classes, true ) ) {
			$s['layout'] = 'full_width';
		} elseif ( in_array( 'elementor-section-boxed', $classes, true ) ) {
			$s['layout'] = 'boxed';
		}
		foreach ( $classes as $c ) {
			if ( preg_match( '/^elementor-section-height-(full|min-height)$/', $c, $m ) ) {
				$s['height'] = $m[1];
			}
			if ( preg_match( '/^elementor-section-content-(top|middle|bottom)$/', $c, $m ) ) {
				$s['content_position'] = $m[1];
			}
			if ( preg_match( '/^elementor-section-items-(top|middle|bottom|stretch)$/', $c, $m ) ) {
				$s['column_position'] = $m[1];
			}
		}
		$container = $this->dom->q( $n, '> .elementor-container' );
		if ( $container ) {
			foreach ( Dom::classes( $container ) as $c ) {
				if ( preg_match( '/^elementor-column-gap-(\w+)$/', $c, $m ) ) {
					$s['gap'] = $m[1];
				}
			}
		}
		if ( isset( $s['custom_height'] ) && empty( $s['height'] ) ) {
			$s['height'] = 'min-height';
		}
		$cols           = $this->children( $n, 'section' );
		$s['structure'] = (string) ( max( 1, count( $cols ) ) * 10 );
		$this->common( $n, $id, $classes, $ds, $s, 'css_classes' );
		return [
			'id'       => $id,
			'elType'   => 'section',
			'isInner'  => in_array( 'elementor-inner-section', $classes, true ) || 'column' === $parent,
			'settings' => $s,
			'elements' => $cols,
		];
	}

	private function column( \DOMElement $n, string $id, array $classes, array $ds ): array {
		$s = [];
		foreach ( $classes as $c ) {
			if ( preg_match( '/^elementor-col-(\d+)$/', $c, $m ) ) {
				$s['_column_size'] = (int) $m[1];
			}
		}
		$this->mapper->apply( $id, 'column', '', $s );
		$this->common( $n, $id, $classes, $ds, $s, 'css_classes' );
		return [
			'id'       => $id,
			'elType'   => 'column',
			'isInner'  => (bool) $n->parentNode && $this->inside_inner_section( $n ),
			'settings' => $s,
			'elements' => $this->children( $n, 'column' ),
		];
	}

	private function inside_inner_section( \DOMElement $n ): bool {
		for ( $p = $n->parentNode; $p instanceof \DOMElement; $p = $p->parentNode ) {
			if ( 'section' === $p->getAttribute( 'data-element_type' ) ) {
				return Dom::has_class( $p, 'elementor-inner-section' );
			}
		}
		return false;
	}

	private function container( \DOMElement $n, string $id, array $classes, array $ds, string $parent ): array {
		$s = [];
		$s['content_width'] = in_array( 'e-con-boxed', $classes, true ) ? 'boxed' : 'full';
		if ( in_array( 'e-grid', $classes, true ) ) {
			$s['container_type'] = 'grid';
		}
		$this->mapper->apply( $id, 'container', '', $s );
		if ( 'grid' === ( $s['container_type'] ?? '' ) ) {
			foreach ( array_keys( $s ) as $k ) {
				if ( 0 === strpos( $k, 'flex_gap' ) ) {
					$s[ str_replace( 'flex_gap', 'grid_gaps', $k ) ] = $s[ $k ];
					unset( $s[ $k ] );
				}
			}
		}
		$tag = strtolower( $n->nodeName );
		if ( 'div' !== $tag && in_array( $tag, [ 'section', 'header', 'footer', 'aside', 'article', 'nav', 'main', 'a' ], true ) ) {
			$s['html_tag'] = $tag;
			if ( 'a' === $tag && $n->hasAttribute( 'href' ) ) {
				$s['link'] = [ 'url' => Util::abs_url( $n->getAttribute( 'href' ), $this->base ), 'is_external' => '_blank' === $n->getAttribute( 'target' ) ? 'on' : '', 'nofollow' => '', 'custom_attributes' => '' ];
			}
		}
		$this->common( $n, $id, $classes, $ds, $s, 'css_classes' );
		return [
			'id'       => $id,
			'elType'   => 'container',
			'isInner'  => in_array( 'e-child', $classes, true ) || in_array( $parent, [ 'container', 'widget' ], true ),
			'settings' => $s,
			'elements' => $this->children( $n, 'container' ),
		];
	}

	private function widget( \DOMElement $n, string $id, array $classes, array $ds ): array {
		$this->report['counts']['widgets']++;
		$wt    = (string) $n->getAttribute( 'data-widget_type' );
		$parts = explode( '.', $wt, 2 );
		$type  = $parts[0];
		$skin  = $parts[1] ?? 'default';

		$tr = $this->widgets->translate( $n, $type, $ds );
		$s  = $tr['settings'];
		if ( $tr['fallback'] ) {
			$this->report['fallbacks'][] = [ 'id' => $id, 'type' => $type, 'reason' => $tr['fallback'] ];
			$this->report['counts']['fallback']++;
		} else {
			$this->report['native'][ $type ] = ( $this->report['native'][ $type ] ?? 0 ) + 1;
			$this->report['counts']['native']++;
			if ( 'default' !== $skin ) {
				$s['_skin'] = $skin;
			}
		}

		$style = [];
		$this->mapper->apply( $id, 'widget', $tr['fallback'] ? '' : $type, $style );
		$s = array_merge( $style, $s );

		foreach ( $classes as $c ) {
			if ( preg_match( '/^elementor-widget(?:-(tablet|mobile|laptop|tablet_extra|mobile_extra|widescreen))?__width-(auto|initial|inherit)$/', $c, $m ) ) {
				$s[ '_element_width' . ( $m[1] ? '_' . $m[1] : '' ) ] = $m[2];
			}
			if ( 'elementor-absolute' === $c ) {
				$s['_position'] = 'absolute';
			} elseif ( 'elementor-fixed' === $c ) {
				$s['_position'] = 'fixed';
			}
		}
		foreach ( $this->mapper->raw( $id ) as $bp => $by ) {
			$d = $by[''] ?? [];
			if ( isset( $d['--container-widget-width'] ) && ( $v = $this->mapper->slider( $d['--container-widget-width'] ) ) ) {
				$s[ '_element_custom_width' . $bp ] = $v;
				$s[ '_element_width' . $bp ]        = 'initial';
			} elseif ( isset( $d['width'] ) && in_array( 'elementor-widget__width-initial', $classes, true ) && ( $v = $this->mapper->slider( $d['width'] ) ) ) {
				$s[ '_element_custom_width' . $bp ] = $v;
			}
		}

		$el = [
			'id'         => $id,
			'elType'     => 'widget',
			'widgetType' => $tr['widgetType'],
			'settings'   => $s,
			'elements'   => [],
		];
		$this->common( $n, $id, $classes, $tr['fallback'] ? $this->motion_only( $ds ) : $ds, $el['settings'], '_css_classes' );
		if ( $tr['nested'] ) {
			$el['elements'] = $this->children( $n, 'widget' );
		}
		return $el;
	}

	private function motion_only( array $ds ): array {
		return array_filter( $ds, function ( $k ) {
			return (bool) preg_match( '/^(_animation|animation|_animation_delay|motion_fx|sticky|_position|_element_)/', $k );
		}, ARRAY_FILTER_USE_KEY );
	}

	/** Advanced-tab bits shared by all element types + data-settings merge. */
	private function common( \DOMElement $n, string $id, array $classes, array $ds, array &$s, string $class_key ): void {
		$custom = [];
		foreach ( $classes as $c ) {
			if ( preg_match( '/^elementor-hidden-(desktop|tablet|mobile|laptop|tablet_extra|mobile_extra|widescreen)$/', $c, $m ) ) {
				$s[ 'hide_' . $m[1] ] = 'hidden-' . $m[1];
				continue;
			}
			if ( preg_match( '/^(elementor|e-con|e-flex|e-grid|e-parent|e-child|e-lazyloaded|e-transform|animated|e-)/', $c ) ) {
				continue;
			}
			$custom[] = $c;
		}
		if ( $custom ) {
			$existing       = isset( $s[ $class_key ] ) ? $s[ $class_key ] . ' ' : '';
			$s[ $class_key ] = trim( $existing . implode( ' ', $custom ) );
		}
		if ( $n->hasAttribute( 'id' ) && '' !== $n->getAttribute( 'id' ) ) {
			$s['_element_id'] = $n->getAttribute( 'id' );
		}
		foreach ( $ds as $k => $v ) {
			if ( in_array( $k, [ 'html', 'editor' ], true ) ) {
				continue;
			}
			$s[ $k ] = $v;
		}
	}

	/* ----------------------------------------------------------------- layer */

	/**
	 * Build the scoped CSS layer for a document. Uses DOC_TOKEN as placeholder
	 * for the destination post id (known only at import time).
	 */
	public function build_layer( array $doc_ids ): string {
		$scope = '.elementor.elementor-' . self::DOC_TOKEN;
		$css   = [ 'fonts' => '', 'kit' => '', 'global' => '', 'post' => '' ];
		$seen_fonts = [];
		$id_re = '(?:' . implode( '|', array_map( 'intval', $doc_ids ) ) . ')';

		foreach ( $this->sources as $i => $src ) {
			$blocks = $this->blocks[ $i ];
			// @font-face from anywhere.
			foreach ( $blocks as $b ) {
				if ( 'font-face' === $b['type'] ) {
					$str = Css_Parser::serialize( [ $b ] );
					if ( ! isset( $seen_fonts[ $str ] ) ) {
						$seen_fonts[ $str ] = true;
						$css['fonts']      .= $str;
					}
				}
			}
			$non_font = array_values( array_filter( $blocks, function ( $b ) {
				return 'font-face' !== $b['type'] && 'import' !== $b['type'];
			} ) );

			switch ( $src['kind'] ) {
				case 'kit':
					$css['kit'] .= Css_Parser::serialize( $non_font, function ( $sel ) use ( $scope ) {
						$sel = preg_replace( '/(^|[\s>+~,(])(?:body|html)?\.elementor-kit-\d+/', '$1' . $scope, $sel, -1, $c );
						if ( ! $c ) {
							$sel = preg_replace( '/^(:root|html|body)\b/', $scope, trim( $sel ), 1, $c2 );
							if ( ! $c2 ) {
								$sel = $scope . ' ' . trim( $sel );
							}
						}
						return $sel;
					} );
					break;
				case 'global':
					$css['global'] .= Css_Parser::serialize( $non_font, function ( $sel ) use ( $scope ) {
						$sel = trim( $sel );
						if ( preg_match( '/^(:root|html|body)\b/', $sel ) ) {
							return preg_replace( '/^(:root|html|body)\b/', $scope, $sel, 1 );
						}
						return $scope . ' ' . $sel;
					} );
					break;
				case 'post':
					if ( ! in_array( (int) $src['doc_id'], array_map( 'intval', $doc_ids ), true ) && 0 !== (int) $src['doc_id'] ) {
						break;
					}
					$css['post'] .= Css_Parser::serialize( $non_font, function ( $sel ) use ( $id_re ) {
						$sel = preg_replace( '/\.elementor-' . $id_re . '(?![\w-])/', '.elementor-' . Converter::DOC_TOKEN, $sel );
						$sel = preg_replace( '/\.elementor-page-' . $id_re . '(?![\w-])/', '.elementor-page-' . Converter::DOC_TOKEN, $sel );
						return $sel;
					} );
					break;
			}
		}
		return "/* ERPC style layer: fonts */\n" . $css['fonts']
			. "\n/* kit (scoped) */\n" . $css['kit']
			. "\n/* global (scoped) */\n" . $css['global']
			. "\n/* page */\n" . $css['post'];
	}

	/* ---------------------------------------------------------------- assets */

	public function inline_svg( string $svg ): string {
		$key                  = 'erpc-inline:' . md5( $svg ) . '.svg';
		$this->inline[ $key ] = $svg;
		return $key;
	}

	public function scan_icon_libs( string $html ): void {
		if ( preg_match( '/\bclass="[^"]*\bfas?\b/', $html ) || false !== strpos( $html, 'fa-solid' ) ) {
			$this->icon_libs['fa-solid'] = true;
		}
		if ( preg_match( '/\bclass="[^"]*\bfar\b/', $html ) ) {
			$this->icon_libs['fa-regular'] = true;
		}
		if ( preg_match( '/\bclass="[^"]*\bfab\b/', $html ) ) {
			$this->icon_libs['fa-brands'] = true;
		}
		if ( false !== strpos( $html, 'eicon-' ) ) {
			$this->icon_libs['eicons'] = true;
		}
	}

	public function collect_assets( array $elements, string $layer ): array {
		$urls = [];
		$add  = function ( $u ) use ( &$urls ) {
			$u = html_entity_decode( trim( $u ) );
			if ( 0 === strpos( $u, 'erpc-inline:' ) ) {
				$urls[ $u ] = 'svg';
				return;
			}
			if ( ! preg_match( '~^https?://~i', $u ) ) {
				return;
			}
			if ( Util::is_media_ext( Util::ext( $u ) ) ) {
				$urls[ $u ] = Util::asset_kind( $u );
			}
		};
		$walk = function ( $arr ) use ( &$walk, $add ) {
			foreach ( $arr as $k => $v ) {
				if ( is_array( $v ) ) {
					if ( isset( $v['url'] ) && is_string( $v['url'] ) && ! array_key_exists( 'is_external', $v ) ) {
						$add( $v['url'] );
					}
					$walk( $v );
				} elseif ( is_string( $v ) && strlen( $v ) > 10 && ( false !== strpos( $v, '<' ) || false !== strpos( $v, 'url(' ) ) ) {
					if ( preg_match_all( '/(?:src|poster|data-bg|href)=["\']([^"\']+)["\']/i', $v, $m ) ) {
						foreach ( $m[1] as $u ) {
							$add( $u );
						}
					}
					if ( preg_match_all( '/url\(\s*[\'"]?([^\'")]+)[\'"]?\s*\)/i', $v, $m ) ) {
						foreach ( $m[1] as $u ) {
							$add( $u );
						}
					}
				}
			}
		};
		$walk( $elements );
		if ( preg_match_all( '/url\(\s*[\'"]?([^\'")]+)[\'"]?\s*\)/i', $layer, $m ) ) {
			foreach ( $m[1] as $u ) {
				$add( $u );
			}
		}
		$out = [];
		foreach ( $urls as $u => $kind ) {
			$out[] = [ 'url' => $u, 'kind' => $kind ];
		}
		return $out;
	}
}
