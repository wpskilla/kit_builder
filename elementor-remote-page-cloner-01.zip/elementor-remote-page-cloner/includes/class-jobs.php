<?php
namespace ERPC;

defined( 'ABSPATH' ) || exit;

/**
 * File-based job store in wp-content/uploads/erpc/jobs/<id>/ (protected from web access).
 */
class Jobs {

	public static function root(): string {
		$u = wp_upload_dir( null, false );
		return trailingslashit( $u['basedir'] ) . 'erpc';
	}

	public static function ensure_dir(): void {
		$root = self::root();
		foreach ( [ $root, $root . '/jobs', $root . '/fonts' ] as $d ) {
			if ( ! is_dir( $d ) ) {
				wp_mkdir_p( $d );
			}
		}
		if ( ! file_exists( $root . '/jobs/.htaccess' ) ) {
			file_put_contents( $root . '/jobs/.htaccess', "Require all denied\nDeny from all\n" );
			file_put_contents( $root . '/jobs/index.php', "<?php // Silence.\n" );
		}
	}

	public static function dir( string $id ): string {
		return self::root() . '/jobs/' . preg_replace( '/[^a-z0-9]/', '', $id );
	}

	public static function create( string $url ): array {
		self::ensure_dir();
		$id = strtolower( wp_generate_password( 12, false, false ) );
		wp_mkdir_p( self::dir( $id ) );
		$job = [
			'id'                  => $id,
			'url'                 => $url,
			'created'             => time(),
			'user'                => get_current_user_id(),
			'status'              => 'new',
			'analysis'            => null,
			'options'             => [],
			'assets'              => [],
			'media_map'           => [],
			'created_attachments' => [],
			'result'              => null,
			'log'                 => [],
		];
		self::save( $job );
		return $job;
	}

	public static function load( string $id ): ?array {
		$f = self::dir( $id ) . '/job.json';
		if ( ! $id || ! file_exists( $f ) ) {
			return null;
		}
		$job = json_decode( (string) file_get_contents( $f ), true );
		return is_array( $job ) ? $job : null;
	}

	public static function save( array $job ): void {
		file_put_contents( self::dir( $job['id'] ) . '/job.json', wp_json_encode( $job ) );
		self::index( $job );
	}

	public static function put( string $id, string $name, string $content ): void {
		file_put_contents( self::dir( $id ) . '/' . sanitize_file_name( $name ), $content );
	}

	public static function get( string $id, string $name ): string {
		$f = self::dir( $id ) . '/' . sanitize_file_name( $name );
		return file_exists( $f ) ? (string) file_get_contents( $f ) : '';
	}

	public static function log( array &$job, string $msg ): void {
		$job['log'][] = gmdate( 'H:i:s' ) . ' ' . $msg;
	}

	/** Small history index kept in an option. */
	private static function index( array $job ): void {
		$idx = get_option( 'erpc_jobs', [] );
		$idx[ $job['id'] ] = [
			'id'      => $job['id'],
			'url'     => $job['url'],
			'created' => $job['created'],
			'status'  => $job['status'],
			'post_id' => $job['result']['posts'][0]['post_id'] ?? 0,
		];
		uasort( $idx, function ( $a, $b ) {
			return $b['created'] <=> $a['created'];
		} );
		update_option( 'erpc_jobs', array_slice( $idx, 0, 50, true ), false );
	}

	public static function history(): array {
		return array_values( get_option( 'erpc_jobs', [] ) );
	}
}
