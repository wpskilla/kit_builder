<?php
namespace ERPC;

defined( 'ABSPATH' ) || exit;

/**
 * Plugin registry: which add-on provides which widgets. Shipped as editable JSON
 * (data/plugin-registry.json) and filterable via `erpc_plugin_registry`.
 */
class Registry {

	private static $data;

	public static function all(): array {
		if ( null === self::$data ) {
			$file       = dirname( __DIR__ ) . '/data/plugin-registry.json';
			$json       = json_decode( (string) file_get_contents( $file ), true );
			self::$data = $json['plugins'] ?? [];
			if ( function_exists( 'apply_filters' ) ) {
				self::$data = apply_filters( 'erpc_plugin_registry', self::$data );
			}
		}
		return self::$data;
	}

	public static function get( string $slug ): ?array {
		$all = self::all();
		return $all[ $slug ] ?? null;
	}

	/** Which plugin provides a widget type? Returns slug or null. */
	public static function plugin_for_widget( string $type ): ?string {
		$best     = null;
		$best_len = 0;
		foreach ( self::all() as $slug => $p ) {
			if ( in_array( $type, $p['widget_types'] ?? [], true ) ) {
				return $slug;
			}
			foreach ( $p['widget_prefixes'] ?? [] as $pre ) {
				if ( 0 === strpos( $type, $pre ) && strlen( $pre ) > $best_len ) {
					$best     = $slug;
					$best_len = strlen( $pre );
				}
			}
		}
		return $best;
	}
}
