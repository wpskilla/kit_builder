<?php
namespace ERPC;

defined( 'ABSPATH' ) || exit;

/**
 * DOM helpers on top of DOMDocument (no external libraries).
 */
class Dom {

	/** @var \DOMDocument */
	public $doc;
	/** @var \DOMXPath */
	public $xp;

	public function __construct( string $html ) {
		$this->doc = new \DOMDocument();
		$prev      = libxml_use_internal_errors( true );
		// Force UTF-8 interpretation.
		$html = preg_replace( '/^\xEF\xBB\xBF/', '', $html );
		$this->doc->loadHTML( '<?xml encoding="UTF-8">' . $html, LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_COMPACT | ( defined( 'LIBXML_PARSEHUGE' ) ? LIBXML_PARSEHUGE : 0 ) );
		libxml_clear_errors();
		libxml_use_internal_errors( $prev );
		$this->xp = new \DOMXPath( $this->doc );
	}

	public static function has_class( \DOMElement $el, string $class ): bool {
		return in_array( $class, self::classes( $el ), true );
	}

	public static function classes( \DOMElement $el ): array {
		$c = trim( (string) $el->getAttribute( 'class' ) );
		return '' === $c ? [] : preg_split( '/\s+/', $c );
	}

	/** Convert a tiny CSS selector (tag, .class, [attr], [attr=v], descendant and >) to XPath. */
	public static function to_xpath( string $sel ): string {
		$sel    = trim( preg_replace( '/\s*>\s*/', ' > ', $sel ) );
		$tokens = preg_split( '/\s+/', $sel );
		$xp     = '.';
		$axis   = '//';
		foreach ( $tokens as $t ) {
			if ( '>' === $t ) {
				$axis = '/';
				continue;
			}
			$tag   = '*';
			$preds = [];
			if ( preg_match( '/^([a-z0-9*]+)/i', $t, $m ) ) {
				$tag = $m[1];
				$t   = substr( $t, strlen( $m[1] ) );
			}
			preg_match_all( '/\.([\w-]+)|\[([\w:-]+)(?:([*^$]?=)["\']?([^"\'\]]*)["\']?)?\]/', $t, $parts, PREG_SET_ORDER );
			foreach ( $parts as $p ) {
				if ( ! empty( $p[1] ) ) {
					$preds[] = "contains(concat(' ',normalize-space(@class),' '),' {$p[1]} ')";
				} elseif ( ! empty( $p[2] ) ) {
					if ( empty( $p[3] ) ) {
						$preds[] = '@' . $p[2];
					} elseif ( '=' === $p[3] ) {
						$preds[] = "@{$p[2]}='{$p[4]}'";
					} elseif ( '*=' === $p[3] ) {
						$preds[] = "contains(@{$p[2]},'{$p[4]}')";
					} elseif ( '^=' === $p[3] ) {
						$preds[] = "starts-with(@{$p[2]},'{$p[4]}')";
					}
				}
			}
			$xp  .= $axis . $tag . ( $preds ? '[' . implode( ' and ', $preds ) . ']' : '' );
			$axis = '//';
		}
		return $xp;
	}

	/** First match inside $ctx. */
	public function q( \DOMNode $ctx, string $sel ): ?\DOMElement {
		$list = $this->xp->query( self::to_xpath( $sel ), $ctx );
		return ( $list && $list->length ) ? $list->item( 0 ) : null;
	}

	/** All matches inside $ctx. @return \DOMElement[] */
	public function qa( \DOMNode $ctx, string $sel ): array {
		$list = $this->xp->query( self::to_xpath( $sel ), $ctx );
		$out  = [];
		if ( $list ) {
			foreach ( $list as $n ) {
				if ( $n instanceof \DOMElement ) {
					$out[] = $n;
				}
			}
		}
		return $out;
	}

	public function inner_html( \DOMNode $el ): string {
		$h = '';
		foreach ( $el->childNodes as $c ) {
			$h .= $this->doc->saveHTML( $c );
		}
		return trim( $h );
	}

	public function outer_html( \DOMNode $el ): string {
		return $this->doc->saveHTML( $el );
	}

	public static function text( ?\DOMNode $el ): string {
		return $el ? trim( preg_replace( '/\s+/u', ' ', $el->textContent ) ) : '';
	}

	/** Direct element children. @return \DOMElement[] */
	public static function children( \DOMNode $el ): array {
		$out = [];
		foreach ( $el->childNodes as $c ) {
			if ( $c instanceof \DOMElement ) {
				$out[] = $c;
			}
		}
		return $out;
	}

	/**
	 * Find the nearest descendant Elementor elements (nodes with data-element_type),
	 * without descending into them. Wrapper divs (elementor-container, widget-wrap,
	 * e-con-inner, section-wrap, ...) are skipped automatically.
	 *
	 * @return \DOMElement[]
	 */
	public static function element_children( \DOMNode $parent ): array {
		$out   = [];
		$stack = array_reverse( self::children( $parent ) );
		while ( $stack ) {
			$n = array_pop( $stack );
			if ( $n->hasAttribute( 'data-element_type' ) && $n->hasAttribute( 'data-id' ) ) {
				$out[] = $n;
				continue;
			}
			if ( $n->hasAttribute( 'data-elementor-type' ) ) {
				continue; // nested document – handled separately.
			}
			foreach ( array_reverse( self::children( $n ) ) as $c ) {
				$stack[] = $c;
			}
		}
		return $out;
	}

	/** Best source URL for an <img>, honoring lazy-load attributes. */
	public static function img_src( \DOMElement $img, string $base ): string {
		foreach ( [ 'data-lazy-src', 'data-src', 'data-orig-src', 'data-original', 'src' ] as $a ) {
			$v = trim( (string) $img->getAttribute( $a ) );
			if ( '' !== $v && 0 !== stripos( $v, 'data:' ) ) {
				return Util::abs_url( $v, $base );
			}
		}
		return '';
	}

	/**
	 * Clean a fragment for use inside Elementor content (text editor, HTML widget):
	 * absolutize URLs, resolve lazy images, drop srcset/sizes, strip scripts (unless allowed),
	 * drop noscript duplicates. Returns inner HTML of $el.
	 */
	public function clean_inner( \DOMElement $el, string $base, bool $keep_scripts = false ): string {
		$clone = $el->cloneNode( true );
		$this->clean_node( $clone, $base, $keep_scripts );
		return $this->inner_html( $clone );
	}

	public function clean_node( \DOMElement $root, string $base, bool $keep_scripts = false ): void {
		$remove = [];
		$all    = [ $root ];
		foreach ( $root->getElementsByTagName( '*' ) as $n ) {
			$all[] = $n;
		}
		foreach ( $all as $n ) {
			$tag = strtolower( $n->nodeName );
			if ( 'noscript' === $tag || ( ! $keep_scripts && 'script' === $tag ) ) {
				$remove[] = $n;
				continue;
			}
			if ( 'img' === $tag ) {
				$src = self::img_src( $n, $base );
				if ( $src ) {
					$n->setAttribute( 'src', $src );
				}
				foreach ( [ 'srcset', 'sizes', 'data-srcset', 'data-src', 'data-lazy-src', 'data-lazy-srcset' ] as $a ) {
					$n->removeAttribute( $a );
				}
				$cls = trim( preg_replace( '/\b(lazyload|lazyloaded|lazyloading)\b/', '', (string) $n->getAttribute( 'class' ) ) );
				if ( '' === $cls ) {
					$n->removeAttribute( 'class' );
				} else {
					$n->setAttribute( 'class', $cls );
				}
			}
			foreach ( [ 'href', 'src', 'poster', 'data-bg', 'action' ] as $a ) {
				if ( $n->hasAttribute( $a ) ) {
					$v = $n->getAttribute( $a );
					if ( '' !== $v && '#' !== $v[0] ) {
						$n->setAttribute( $a, Util::abs_url( $v, $base ) );
					}
				}
			}
			if ( $n->hasAttribute( 'style' ) && false !== stripos( $n->getAttribute( 'style' ), 'url(' ) ) {
				$n->setAttribute( 'style', Css_Parser::absolutize_urls( $n->getAttribute( 'style' ), $base ) );
			}
			if ( ! $keep_scripts ) {
				foreach ( iterator_to_array( $n->attributes ) as $attr ) {
					if ( 0 === stripos( $attr->name, 'on' ) ) {
						$n->removeAttribute( $attr->name );
					}
				}
			}
		}
		foreach ( $remove as $n ) {
			if ( $n->parentNode ) {
				$n->parentNode->removeChild( $n );
			}
		}
	}
}
