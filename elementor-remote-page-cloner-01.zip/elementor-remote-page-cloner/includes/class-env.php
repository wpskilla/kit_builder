<?php
namespace ERPC;

defined( 'ABSPATH' ) || exit;

/**
 * Abstracts what the converter needs to know about the *recipient* site, so the
 * conversion engine stays testable outside WordPress.
 */
class Env {

	/** Is this widget type registered on this site? null = unknown (assume yes). */
	public function widget_exists( string $type ): ?bool {
		return null;
	}

	/** Control definitions for an element, or null if unknown. */
	public function controls( string $el_type, string $widget_type = '' ): ?array {
		return null;
	}

	public function container_active(): bool {
		return true;
	}
}

/**
 * Live Elementor environment.
 */
class WP_Env extends Env {

	private $controls_cache = [];

	private function elementor(): ?\Elementor\Plugin {
		return class_exists( '\Elementor\Plugin' ) ? \Elementor\Plugin::$instance : null;
	}

	public function widget_exists( string $type ): ?bool {
		$el = $this->elementor();
		if ( ! $el ) {
			return false;
		}
		return (bool) $el->widgets_manager->get_widget_types( $type );
	}

	public function controls( string $el_type, string $widget_type = '' ): ?array {
		$key = $el_type . ':' . $widget_type;
		if ( array_key_exists( $key, $this->controls_cache ) ) {
			return $this->controls_cache[ $key ];
		}
		$el  = $this->elementor();
		$res = null;
		if ( $el ) {
			try {
				if ( 'widget' === $el_type ) {
					$w = $el->widgets_manager->get_widget_types( $widget_type );
				} else {
					$w = $el->elements_manager->get_element_types( $el_type );
				}
				if ( $w ) {
					$res = $w->get_controls();
				}
			} catch ( \Throwable $e ) {
				$res = null;
			}
		}
		$this->controls_cache[ $key ] = $res;
		return $res;
	}

	public function container_active(): bool {
		$el = $this->elementor();
		if ( ! $el || ! isset( $el->experiments ) ) {
			return false;
		}
		return $el->experiments->is_feature_active( 'container' );
	}

	public static function nested_active(): bool {
		if ( ! class_exists( '\Elementor\Plugin' ) ) {
			return false;
		}
		return \Elementor\Plugin::$instance->experiments->is_feature_active( 'nested-elements' );
	}

	/** Local breakpoints as name => max-width. */
	public static function local_breakpoints(): array {
		$out = [];
		if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->breakpoints ) ) {
			foreach ( \Elementor\Plugin::$instance->breakpoints->get_active_breakpoints() as $name => $bp ) {
				$out[ $name ] = (int) $bp->get_value();
			}
		}
		return $out;
	}
}
