<?php
namespace ERPC;

defined( 'ABSPATH' ) || exit;

class Admin {

	const CAP = 'manage_options';

	public static function init(): void {
		add_action( 'admin_menu', [ __CLASS__, 'menu' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'assets' ] );
		add_action( 'admin_post_erpc_save_settings', [ __CLASS__, 'save_settings' ] );
		foreach ( [ 'analyze', 'report', 'install', 'upload_zip', 'feature', 'prepare', 'media', 'build', 'undo' ] as $a ) {
			add_action( 'wp_ajax_erpc_' . $a, [ __CLASS__, 'ajax_' . $a ] );
		}
		add_filter( 'plugin_action_links_' . plugin_basename( ERPC_FILE ), function ( $links ) {
			array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=erpc' ) ) . '">' . esc_html__( 'Clone a page', 'erpc' ) . '</a>' );
			return $links;
		} );
	}

	public static function default_settings(): array {
		return [ 'fidelity' => 'editable', 'keep_scripts' => 0, 'user_agent' => '' ];
	}

	public static function settings(): array {
		return array_merge( self::default_settings(), (array) get_option( 'erpc_settings', [] ) );
	}

	public static function menu(): void {
		add_menu_page( __( 'Page Cloner', 'erpc' ), __( 'Page Cloner', 'erpc' ), self::CAP, 'erpc', [ __CLASS__, 'page' ], 'dashicons-admin-page', 59 );
	}

	public static function assets( $hook ): void {
		if ( 'toplevel_page_erpc' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'erpc-admin', ERPC_URL . 'assets/admin.css', [], ERPC_VERSION );
		wp_enqueue_script( 'erpc-admin', ERPC_URL . 'assets/admin.js', [], ERPC_VERSION, true );
		wp_localize_script( 'erpc-admin', 'ERPC', [
			'ajax'  => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'erpc' ),
			'home'  => home_url( '/' ),
			'pages' => array_map( function ( $p ) {
				return [ 'id' => $p->ID, 'title' => $p->post_title ?: '#' . $p->ID ];
			}, get_pages( [ 'post_status' => 'publish,draft,private', 'number' => 300 ] ) ),
		] );
	}

	/* -------------------------------------------------------------------- UI */

	public static function page(): void {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$tab = sanitize_key( $_GET['tab'] ?? 'clone' ); // phpcs:ignore WordPress.Security.NonceVerification
		$base = admin_url( 'admin.php?page=erpc' );
		?>
		<div class="wrap erpc">
			<header class="erpc-head">
				<h1><?php esc_html_e( 'Page Cloner', 'erpc' ); ?> <span class="erpc-ver">v<?php echo esc_html( ERPC_VERSION ); ?></span></h1>
				<p><?php esc_html_e( 'One public Elementor page in, one editable Elementor page out — with the plugins, media and styles it needs.', 'erpc' ); ?></p>
				<nav class="erpc-tabs">
					<a href="<?php echo esc_url( $base ); ?>" class="<?php echo 'clone' === $tab ? 'is-active' : ''; ?>"><?php esc_html_e( 'New clone', 'erpc' ); ?></a>
					<a href="<?php echo esc_url( $base . '&tab=history' ); ?>" class="<?php echo 'history' === $tab ? 'is-active' : ''; ?>"><?php esc_html_e( 'History', 'erpc' ); ?></a>
					<a href="<?php echo esc_url( $base . '&tab=settings' ); ?>" class="<?php echo 'settings' === $tab ? 'is-active' : ''; ?>"><?php esc_html_e( 'Settings', 'erpc' ); ?></a>
				</nav>
			</header>
			<?php
			if ( 'history' === $tab ) {
				self::history_tab();
			} elseif ( 'settings' === $tab ) {
				self::settings_tab();
			} else {
				self::clone_tab();
			}
			?>
		</div>
		<?php
	}

	private static function clone_tab(): void {
		?>
		<section class="erpc-step" id="erpc-step-source">
			<div class="erpc-step-num">1</div>
			<div class="erpc-step-body">
				<h2><?php esc_html_e( 'Source page', 'erpc' ); ?></h2>
				<form id="erpc-source-form" class="erpc-source">
					<input type="url" id="erpc-url" required placeholder="https://example.com/about-us/" />
					<button type="submit" class="button button-primary button-hero" id="erpc-analyze"><?php esc_html_e( 'Analyze page', 'erpc' ); ?></button>
				</form>
				<label class="erpc-consent"><input type="checkbox" id="erpc-consent" /> <?php esc_html_e( 'I own this page or have permission to reuse its content, images and fonts.', 'erpc' ); ?></label>
				<p class="erpc-hint"><?php esc_html_e( 'Only this single URL is fetched — no crawling, no admin access needed. Works with anything a normal visitor can see.', 'erpc' ); ?></p>
			</div>
		</section>

		<section class="erpc-step is-locked" id="erpc-step-analysis">
			<div class="erpc-step-num">2</div>
			<div class="erpc-step-body">
				<h2><?php esc_html_e( 'Analysis & required plugins', 'erpc' ); ?></h2>
				<div id="erpc-analysis"></div>
			</div>
		</section>

		<section class="erpc-step is-locked" id="erpc-step-options">
			<div class="erpc-step-num">3</div>
			<div class="erpc-step-body">
				<h2><?php esc_html_e( 'Import options', 'erpc' ); ?></h2>
				<div id="erpc-options"></div>
			</div>
		</section>

		<section class="erpc-step is-locked" id="erpc-step-build">
			<div class="erpc-step-num">4</div>
			<div class="erpc-step-body">
				<h2><?php esc_html_e( 'Clone', 'erpc' ); ?></h2>
				<div id="erpc-build"></div>
			</div>
		</section>
		<?php
	}

	private static function history_tab(): void {
		$rows = Jobs::history();
		echo '<table class="widefat striped erpc-history"><thead><tr><th>' . esc_html__( 'Date', 'erpc' ) . '</th><th>' . esc_html__( 'Source', 'erpc' ) . '</th><th>' . esc_html__( 'Status', 'erpc' ) . '</th><th>' . esc_html__( 'Result', 'erpc' ) . '</th><th></th></tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="5">' . esc_html__( 'No clones yet.', 'erpc' ) . '</td></tr>';
		}
		foreach ( $rows as $r ) {
			$post = $r['post_id'] ? get_post( $r['post_id'] ) : null;
			echo '<tr><td>' . esc_html( wp_date( 'Y-m-d H:i', $r['created'] ) ) . '</td><td><a href="' . esc_url( $r['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $r['url'] ) . '</a></td><td>' . esc_html( $r['status'] ) . '</td><td>';
			if ( $post ) {
				echo '<a href="' . esc_url( get_permalink( $post ) ) . '" target="_blank">' . esc_html( $post->post_title ) . '</a> · <a href="' . esc_url( admin_url( 'post.php?post=' . $post->ID . '&action=elementor' ) ) . '">' . esc_html__( 'Edit with Elementor', 'erpc' ) . '</a>';
			}
			echo '</td><td>';
			if ( 'done' === $r['status'] ) {
				echo '<button class="button erpc-undo" data-job="' . esc_attr( $r['id'] ) . '">' . esc_html__( 'Undo', 'erpc' ) . '</button>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}

	private static function settings_tab(): void {
		$s = self::settings();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="erpc-settings">
			<?php wp_nonce_field( 'erpc_settings' ); ?>
			<input type="hidden" name="action" value="erpc_save_settings" />
			<table class="form-table">
				<tr><th><?php esc_html_e( 'Default fidelity mode', 'erpc' ); ?></th><td>
					<label><input type="radio" name="fidelity" value="editable" <?php checked( 'editable', $s['fidelity'] ); ?> /> <?php esc_html_e( 'Editable — source style layer loads first; your Elementor edits always win.', 'erpc' ); ?></label><br>
					<label><input type="radio" name="fidelity" value="locked" <?php checked( 'locked', $s['fidelity'] ); ?> /> <?php esc_html_e( 'Locked — source style layer loads last; guarantees the source look, some style edits may be overridden.', 'erpc' ); ?></label>
				</td></tr>
				<tr><th><?php esc_html_e( 'Scripts inside HTML', 'erpc' ); ?></th><td>
					<label><input type="checkbox" name="keep_scripts" value="1" <?php checked( 1, (int) $s['keep_scripts'] ); ?> /> <?php esc_html_e( 'Keep <script> tags found in HTML widgets / fallbacks (only for sources you fully trust).', 'erpc' ); ?></label>
				</td></tr>
				<tr><th><?php esc_html_e( 'Custom user agent', 'erpc' ); ?></th><td>
					<input type="text" class="regular-text" name="user_agent" value="<?php echo esc_attr( $s['user_agent'] ); ?>" placeholder="<?php echo esc_attr( Fetcher::user_agent() ); ?>" />
				</td></tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<?php
	}

	public static function save_settings(): void {
		if ( ! current_user_can( self::CAP ) || ! check_admin_referer( 'erpc_settings' ) ) {
			wp_die( 'Forbidden' );
		}
		update_option( 'erpc_settings', [
			'fidelity'     => 'locked' === ( $_POST['fidelity'] ?? '' ) ? 'locked' : 'editable',
			'keep_scripts' => empty( $_POST['keep_scripts'] ) ? 0 : 1,
			'user_agent'   => sanitize_text_field( wp_unslash( $_POST['user_agent'] ?? '' ) ),
		] );
		wp_safe_redirect( admin_url( 'admin.php?page=erpc&tab=settings&saved=1' ) );
		exit;
	}

	/* ------------------------------------------------------------------ AJAX */

	private static function guard( string $cap = self::CAP ): void {
		if ( ! check_ajax_referer( 'erpc', 'nonce', false ) || ! current_user_can( $cap ) ) {
			wp_send_json_error( [ 'message' => __( 'Permission denied or session expired. Reload the page.', 'erpc' ) ], 403 );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 );
		}
		wp_raise_memory_limit( 'admin' );
	}

	private static function job_from_request(): array {
		$job = Jobs::load( sanitize_key( $_POST['job'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! $job ) {
			wp_send_json_error( [ 'message' => __( 'Job not found. Analyze the page again.', 'erpc' ) ] );
		}
		return $job;
	}

	private static function fail( $err ): void {
		wp_send_json_error( [ 'message' => is_wp_error( $err ) ? $err->get_error_message() : (string) $err ] );
	}

	public static function ajax_analyze(): void {
		self::guard();
		$url = esc_url_raw( wp_unslash( $_POST['url'] ?? '' ) );
		if ( empty( $_POST['consent'] ) ) {
			self::fail( __( 'Please confirm you own the page or have permission to reuse it.', 'erpc' ) );
		}
		$res = Fetcher::get( $url );
		if ( is_wp_error( $res ) ) {
			self::fail( $res );
		}
		if ( $res['type'] && false === stripos( $res['type'], 'html' ) ) {
			self::fail( __( 'The URL did not return an HTML page.', 'erpc' ) );
		}
		$det      = new Detector( $res['body'], $res['url'] );
		$analysis = $det->analyse();
		if ( ! $analysis['documents'] ) {
			self::fail( $analysis['elementor']['detected']
				? __( 'Elementor was detected, but no Elementor content was found in the page HTML (it may be loaded by JavaScript or blocked).', 'erpc' )
				: __( 'This page was not built with Elementor. Only Elementor sources are supported in this version.', 'erpc' ) );
		}

		$job = Jobs::create( $url );
		Jobs::put( $job['id'], 'page.html', $res['body'] );

		// Fetch Elementor-generated CSS.
		$sources = [];
		$warn    = [];
		foreach ( $analysis['css_sources'] as $src ) {
			if ( isset( $src['inline'] ) ) {
				$src['content'] = $src['inline'];
				unset( $src['inline'] );
				$sources[] = $src;
				continue;
			}
			$r = Fetcher::get( $src['url'], 20 );
			if ( is_wp_error( $r ) ) {
				$warn[] = sprintf( __( 'Could not load %1$s: %2$s', 'erpc' ), basename( (string) parse_url( $src['url'], PHP_URL_PATH ) ), $r->get_error_message() );
				continue;
			}
			$src['content'] = $r['body'];
			$sources[]      = $src;
		}
		Jobs::put( $job['id'], 'css.json', wp_json_encode( $sources ) );
		unset( $analysis['css_sources'] );
		$analysis['fetch_warnings'] = $warn;
		$job['analysis']            = $analysis;
		$job['status']              = 'analyzed';
		Jobs::log( $job, 'Analyzed ' . $res['url'] );
		Jobs::save( $job );
		wp_send_json_success( self::report( $job ) );
	}

	public static function ajax_report(): void {
		self::guard();
		wp_send_json_success( self::report( self::job_from_request() ) );
	}

	public static function ajax_install(): void {
		self::guard( 'install_plugins' );
		$job  = self::job_from_request();
		$slug = sanitize_key( $_POST['slug'] ?? '' );
		$allowed = array_column( $job['analysis']['plugins'], 'slug' );
		$reg     = Registry::get( $slug );
		if ( ! in_array( $slug, $allowed, true ) || ! $reg || 'wporg' !== ( $reg['source'] ?? '' ) ) {
			self::fail( __( 'This plugin cannot be installed automatically.', 'erpc' ) );
		}
		$res = Installer::install_and_activate( $slug );
		if ( is_wp_error( $res ) ) {
			self::fail( $res );
		}
		Jobs::log( $job, 'Installed/activated ' . $slug );
		Jobs::save( $job );
		wp_send_json_success( [ 'slug' => $slug, 'status' => Installer::status( $slug ) ] );
	}

	public static function ajax_upload_zip(): void {
		self::guard( 'install_plugins' );
		if ( empty( $_FILES['zip']['tmp_name'] ) ) {
			self::fail( __( 'No file uploaded.', 'erpc' ) );
		}
		$name = sanitize_file_name( wp_unslash( $_FILES['zip']['name'] ?? '' ) );
		if ( 'zip' !== strtolower( pathinfo( $name, PATHINFO_EXTENSION ) ) ) {
			self::fail( __( 'Please upload a .zip plugin package.', 'erpc' ) );
		}
		$res = Installer::install_zip( $_FILES['zip']['tmp_name'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( is_wp_error( $res ) ) {
			self::fail( $res );
		}
		wp_send_json_success( [ 'file' => $res ] );
	}

	public static function ajax_feature(): void {
		self::guard();
		$res = Installer::activate_feature( sanitize_key( $_POST['feature'] ?? '' ) );
		if ( is_wp_error( $res ) ) {
			self::fail( $res );
		}
		wp_send_json_success();
	}

	public static function ajax_prepare(): void {
		self::guard();
		$job  = self::job_from_request();
		$raw  = json_decode( wp_unslash( $_POST['options'] ?? '{}' ), true ) ?: [];
		$opts = Importer::sanitize_options( $raw, $job['analysis'] );
		if ( 'replace' === $opts['target'] && ! current_user_can( 'edit_post', $opts['replace_id'] ) ) {
			self::fail( __( 'You cannot edit the selected page.', 'erpc' ) );
		}
		$summary = Importer::prepare( $job, $opts );
		Jobs::save( $job );
		wp_send_json_success( [ 'total' => count( $job['assets'] ), 'done' => count( array_filter( $job['assets'], function ( $a ) {
			return 'pending' !== $a['status'];
		} ) ), 'summary' => $summary ] );
	}

	public static function ajax_media(): void {
		self::guard( 'upload_files' );
		$job = self::job_from_request();
		$res = Media::process( $job, 5 );
		Jobs::save( $job );
		wp_send_json_success( $res );
	}

	public static function ajax_build(): void {
		self::guard();
		$job = self::job_from_request();
		$res = Importer::build( $job );
		Jobs::save( $job );
		if ( is_wp_error( $res ) ) {
			self::fail( $res );
		}
		$errors = array_values( array_filter( array_map( function ( $a ) {
			return 'error' === $a['status'] ? basename( (string) parse_url( $a['url'], PHP_URL_PATH ) ) . ' – ' . ( $a['error'] ?? '' ) : null;
		}, $job['assets'] ) ) );
		$res['media_errors'] = $errors;
		$res['job']          = $job['id'];
		wp_send_json_success( $res );
	}

	public static function ajax_undo(): void {
		self::guard();
		$job = self::job_from_request();
		Importer::undo( $job );
		Jobs::save( $job );
		wp_send_json_success();
	}

	/* ---------------------------------------------------------------- report */

	public static function report( array $job ): array {
		$a        = $job['analysis'];
		$plugins  = [];
		$el_active = class_exists( '\Elementor\Plugin' );
		$reg_all  = Registry::all();

		foreach ( $a['plugins'] as $p ) {
			$reg  = $reg_all[ $p['slug'] ] ?? [];
			$st   = Installer::status( $p['slug'] );
			$plugins[] = [
				'slug'           => $p['slug'],
				'name'           => $reg['name'] ?? $p['slug'],
				'source'         => $reg['source'] ?? 'unknown',
				'buy_url'        => $reg['buy_url'] ?? '',
				'note'           => $reg['note'] ?? '',
				'status'         => $st['status'],
				'local_version'  => $st['version'],
				'source_version' => $p['source_version'],
				'widgets'        => $p['widgets'],
				'docs'           => array_map( 'intval', $p['docs'] ),
				'evidence'       => $p['evidence'],
				'ui'             => (bool) ( $p['widgets'] || in_array( 'page-markup', $p['evidence'], true ) || 'elementor' === $p['slug'] ),
			];
		}
		// Elementor must always be listed first.
		usort( $plugins, function ( $x, $y ) {
			$rank = function ( $p ) {
				return 'elementor' === $p['slug'] ? 0 : ( 'elementor-pro' === $p['slug'] ? 1 : ( $p['ui'] ? 2 : 3 ) );
			};
			return $rank( $x ) <=> $rank( $y );
		} );

		// Widget support preview per document.
		$docs = [];
		foreach ( $a['documents'] as $d ) {
			$widgets = [];
			foreach ( $d['widgets'] as $type => $count ) {
				$slug   = Registry::plugin_for_widget( $type );
				$active = 'elementor' === $slug ? $el_active : ( $slug ? 'active' === Installer::status( $slug )['status'] : false );
				$native = $active && method_exists( Widgets::class, 'w_' . str_replace( '-', '_', $type ) );
				$widgets[] = [
					'type'   => $type,
					'count'  => $count,
					'plugin' => $slug,
					'mode'   => $native ? 'native' : 'static',
				];
			}
			$d['widgets'] = $widgets;
			$docs[]       = $d;
		}

		$features = [];
		$need_containers = (bool) $a['elementor']['containers'];
		$need_nested     = false;
		foreach ( $a['documents'] as $d ) {
			if ( isset( $d['widgets']['nested-tabs'] ) || isset( $d['widgets']['nested-accordion'] ) ) {
				$need_nested = true;
			}
		}
		foreach ( Installer::features() as $key => $label ) {
			$required = 'container' === $key ? $need_containers : $need_nested;
			if ( ! $required ) {
				continue;
			}
			$features[] = [ 'key' => $key, 'label' => $label, 'active' => $el_active && Installer::feature_active( $key ) ];
		}

		$local_bp = $el_active ? WP_Env::local_breakpoints() : [];
		$src_bp   = [];
		foreach ( $a['active_breakpoints'] as $n ) {
			$src_bp[ $n ] = $a['breakpoints'][ $n ] ?? null;
		}
		$bp_mismatch = false;
		foreach ( $src_bp as $n => $v ) {
			if ( ! isset( $local_bp[ $n ] ) || (int) $local_bp[ $n ] !== (int) $v ) {
				$bp_mismatch = true;
			}
		}

		return [
			'job'              => $job['id'],
			'source'           => [
				'url'          => $a['url'],
				'title'        => $a['title'],
				'is_wordpress' => $a['is_wordpress'],
				'wp_version'   => $a['wp_version'],
				'theme'        => $a['theme'],
				'elementor'    => $a['elementor'],
				'template'     => $a['template'],
				'libraries'    => $a['libraries'],
			],
			'documents'        => $docs,
			'main_doc'         => (int) $a['main_doc'],
			'plugins'          => $plugins,
			'features'         => $features,
			'breakpoints'      => [ 'source' => $src_bp, 'local' => $local_bp, 'mismatch' => $el_active && $bp_mismatch ],
			'unknown_widgets'  => $a['unknown_widgets'],
			'elementor_active' => $el_active,
			'defaults'         => Importer::default_options( $a ),
			'warnings'         => $a['fetch_warnings'] ?? [],
			'can_install'      => current_user_can( 'install_plugins' ),
		];
	}
}
