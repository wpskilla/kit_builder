<?php
namespace ERPC;

defined( 'ABSPATH' ) || exit;

/**
 * Content translators: rendered widget markup → Elementor widget settings.
 *
 * Each translator returns the *content* settings (text, links, media, repeaters).
 * Styling is added afterwards by Style_Mapper; anything else is covered by the style layer.
 * Add your own with the `erpc_widget_translators` filter: [ 'widget-type' => callable ].
 */
class Widgets {

	/** Widgets that contain child containers (nested elements). */
	const NESTED = [ 'nested-tabs', 'nested-accordion' ];

	/** @var Converter */
	private $c;
	/** @var Dom */
	private $dom;

	public function __construct( Converter $c ) {
		$this->c   = $c;
		$this->dom = $c->dom;
	}

	/**
	 * @return array ['widgetType'=>string,'settings'=>array,'nested'=>bool,'fallback'=>?string]
	 */
	public function translate( \DOMElement $n, string $type, array $ds ): array {
		$root   = $this->dom->q( $n, '> .elementor-widget-container' ) ?: $n;
		$exists = $this->c->env->widget_exists( $type );

		$custom = function_exists( 'apply_filters' ) ? apply_filters( 'erpc_widget_translators', [] ) : [];
		if ( false !== $exists ) {
			if ( isset( $custom[ $type ] ) && is_callable( $custom[ $type ] ) ) {
				$s = call_user_func( $custom[ $type ], $n, $root, $ds, $this->c );
				if ( is_array( $s ) ) {
					return [ 'widgetType' => $type, 'settings' => $s, 'nested' => in_array( $type, self::NESTED, true ), 'fallback' => null ];
				}
			}
			$method = 'w_' . str_replace( '-', '_', $type );
			if ( method_exists( $this, $method ) ) {
				$s = $this->$method( $n, $root, $ds );
				if ( is_array( $s ) ) {
					return [ 'widgetType' => $type, 'settings' => $s, 'nested' => in_array( $type, self::NESTED, true ), 'fallback' => null ];
				}
			}
		}

		$reason = false === $exists ? 'widget not available on this site' : 'no native translator yet';
		if ( 'shortcode' === $type ) {
			$reason = 'shortcode output frozen as HTML';
		}
		return $this->fallback( $n, $root, $type, $reason );
	}

	public function fallback( \DOMElement $n, \DOMElement $root, string $type, string $reason ): array {
		$html = $this->dom->clean_inner( $root, $this->c->base, ! empty( $this->c->opts['keep_scripts'] ) );
		$this->c->scan_icon_libs( $html );
		return [
			'widgetType' => 'html',
			'settings'   => [
				'html'         => $html,
				'_css_classes' => 'elementor-widget-' . $type . ' erpc-fallback',
			],
			'nested'     => false,
			'fallback'   => $reason,
		];
	}

	/* ------------------------------------------------------------- helpers */

	private function link( ?\DOMElement $a ): ?array {
		if ( ! $a || ! $a->hasAttribute( 'href' ) ) {
			return null;
		}
		$href = trim( $a->getAttribute( 'href' ) );
		if ( '' === $href ) {
			return null;
		}
		return [
			'url'               => Util::abs_url( $href, $this->c->base ),
			'is_external'       => '_blank' === $a->getAttribute( 'target' ) ? 'on' : '',
			'nofollow'          => false !== strpos( (string) $a->getAttribute( 'rel' ), 'nofollow' ) ? 'on' : '',
			'custom_attributes' => '',
		];
	}

	private function media( string $url, string $alt = '' ): array {
		$m = [ 'url' => $url, 'id' => '', 'size' => '', 'source' => 'library' ];
		if ( $alt ) {
			$m['alt'] = $alt;
		}
		return $m;
	}

	private function img( ?\DOMElement $ctx ): ?array {
		if ( ! $ctx ) {
			return null;
		}
		$img = 'img' === strtolower( $ctx->nodeName ) ? $ctx : $this->dom->q( $ctx, 'img' );
		if ( ! $img ) {
			return null;
		}
		$src = Dom::img_src( $img, $this->c->base );
		return $src ? $this->media( $src, (string) $img->getAttribute( 'alt' ) ) : null;
	}

	private function inner( ?\DOMElement $el ): string {
		return $el ? $this->dom->clean_inner( $el, $this->c->base, false ) : '';
	}

	/** Innermost text holder: a > span > element itself. Also returns link. */
	private function title_parts( ?\DOMElement $el ): array {
		if ( ! $el ) {
			return [ '', null ];
		}
		$a = $this->dom->q( $el, 'a' );
		if ( $a ) {
			return [ $this->inner( $a ), $this->link( $a ) ];
		}
		$kids = Dom::children( $el );
		if ( 1 === count( $kids ) && 'span' === strtolower( $kids[0]->nodeName ) && Dom::text( $kids[0] ) === Dom::text( $el ) ) {
			return [ $this->inner( $kids[0] ), null ];
		}
		return [ $this->inner( $el ), null ];
	}

	private static function class_value( \DOMElement $el, string $regex ): ?string {
		foreach ( Dom::classes( $el ) as $cls ) {
			if ( preg_match( $regex, $cls, $m ) ) {
				return $m[1];
			}
		}
		return null;
	}

	private function rid(): string {
		return Util::gen_id();
	}

	/** Elementor icon value from <i>, <svg> (font-icon-svg or uploaded), or <img>. */
	public function icon( ?\DOMElement $ctx ): array {
		$none = [ 'value' => '', 'library' => '' ];
		if ( ! $ctx ) {
			return $none;
		}
		$cands = array_merge( [ $ctx ], iterator_to_array( $ctx->getElementsByTagName( '*' ) ) );
		foreach ( $cands as $el ) {
			if ( ! $el instanceof \DOMElement ) {
				continue;
			}
			$tag = strtolower( $el->nodeName );
			$cls = (string) $el->getAttribute( 'class' );
			$tokens = preg_split( '/\s+/', trim( $cls ) );
			if ( 'i' === $tag || ( 'span' === $tag && preg_grep( '/^(fa[srbl]?|fa-[\w-]+|eicon-[\w-]+|icon-[\w-]+|ekit-?icon.*)$/', $tokens ) ) ) {
				if ( '' === trim( $cls ) ) {
					continue;
				}
				return $this->icon_from_class( $cls );
			}
			if ( 'svg' === $tag ) {
				if ( preg_match( '/\be-(fas|far|fab)-([\w-]+)/', $cls, $m ) ) {
					$lib = [ 'fas' => 'fa-solid', 'far' => 'fa-regular', 'fab' => 'fa-brands' ][ $m[1] ];
					$this->c->icon_libs[ $lib ] = true;
					return [ 'value' => $m[1] . ' fa-' . $m[2], 'library' => $lib ];
				}
				if ( preg_match( '/\be-eicon-([\w-]+)/', $cls, $m ) ) {
					return [ 'value' => 'eicon-' . $m[1], 'library' => 'eicons' ];
				}
				$url = $this->c->inline_svg( $this->dom->outer_html( $el ) );
				return [ 'value' => [ 'url' => $url, 'id' => '' ], 'library' => 'svg' ];
			}
			if ( 'img' === $tag ) {
				$src = Dom::img_src( $el, $this->c->base );
				if ( $src ) {
					return [ 'value' => [ 'url' => $src, 'id' => '' ], 'library' => 'svg' ];
				}
			}
		}
		return $none;
	}

	private function icon_from_class( string $cls ): array {
		$parts = preg_split( '/\s+/', trim( $cls ) );
		$lib   = '';
		if ( array_intersect( $parts, [ 'fas', 'fa-solid' ] ) ) {
			$lib = 'fa-solid';
		} elseif ( array_intersect( $parts, [ 'far', 'fa-regular' ] ) ) {
			$lib = 'fa-regular';
		} elseif ( array_intersect( $parts, [ 'fab', 'fa-brands' ] ) ) {
			$lib = 'fa-brands';
		} elseif ( in_array( 'fa', $parts, true ) ) {
			$lib = 'fa-solid';
			$cls = 'fas ' . implode( ' ', array_diff( $parts, [ 'fa' ] ) );
		} elseif ( preg_grep( '/^eicon-/', $parts ) ) {
			$lib = 'eicons';
		} elseif ( preg_grep( '/^(ekit|icon-)/', $parts ) ) {
			$lib = 'ekiticons';
		}
		if ( 0 === strpos( $lib, 'fa-' ) ) {
			$this->c->icon_libs[ $lib ] = true;
		}
		$value = trim( implode( ' ', array_filter( preg_split( '/\s+/', $cls ), function ( $c ) {
			return ! in_array( $c, [ 'aria-hidden', 'elementor-icon', 'e-font-icon-svg' ], true );
		} ) ) );
		return [ 'value' => $value, 'library' => $lib ?: 'fa-solid' ];
	}

	private function align_classes( \DOMElement $n, string $key, array &$s ): void {
		foreach ( Dom::classes( $n ) as $cls ) {
			if ( preg_match( '/^elementor-(?:(tablet|mobile|laptop|tablet_extra|mobile_extra|widescreen)-)?align-(left|center|right|justify|start|end)$/', $cls, $m ) ) {
				$s[ $key . ( $m[1] ? '_' . $m[1] : '' ) ] = $m[2];
			}
		}
	}

	/* ---------------------------------------------------------- translators */

	private function w_heading( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$t = $this->dom->q( $root, '.elementor-heading-title' );
		if ( ! $t ) {
			return null;
		}
		$s = [ 'header_size' => strtolower( $t->nodeName ) ];
		$kids = Dom::children( $t );
		if ( 1 === count( $kids ) && 'a' === strtolower( $kids[0]->nodeName ) && Dom::text( $kids[0] ) === Dom::text( $t ) ) {
			$s['title'] = $this->inner( $kids[0] );
			$s['link']  = $this->link( $kids[0] );
		} else {
			$s['title'] = $this->inner( $t );
		}
		if ( $size = self::class_value( $t, '/^elementor-size-(\w+)$/' ) ) {
			$s['size'] = $size;
		}
		return $s;
	}

	private function w_text_editor( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$s = [ 'editor' => $this->inner( $root ) ];
		if ( Dom::has_class( $n, 'elementor-drop-cap-yes' ) ) {
			$s['drop_cap'] = 'yes';
		}
		return $s;
	}

	private function w_image( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$img = $this->img( $root );
		if ( ! $img ) {
			return null;
		}
		$s = [ 'image' => $img, 'image_size' => 'full' ];
		$a = $this->dom->q( $root, 'a' );
		if ( $a ) {
			$href = Util::abs_url( $a->getAttribute( 'href' ), $this->c->base );
			if ( $a->hasAttribute( 'data-elementor-open-lightbox' ) && Util::is_media_ext( Util::ext( $href ) ) && $href === $img['url'] ) {
				$s['link_to']       = 'file';
				$s['open_lightbox'] = $a->getAttribute( 'data-elementor-open-lightbox' );
			} else {
				$s['link_to'] = 'custom';
				$s['link']    = $this->link( $a );
			}
		}
		$cap = $this->dom->q( $root, 'figcaption' );
		if ( $cap ) {
			$s['caption_source'] = 'custom';
			$s['caption']        = Dom::text( $cap );
		}
		return $s;
	}

	private function w_button( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$a = $this->dom->q( $root, '.elementor-button' );
		if ( ! $a ) {
			return null;
		}
		$txt = $this->dom->q( $a, '.elementor-button-text' );
		$s   = [ 'text' => $txt ? Dom::text( $txt ) : Dom::text( $a ) ];
		if ( $l = $this->link( $a ) ) {
			$s['link'] = $l;
		}
		if ( $sz = self::class_value( $a, '/^elementor-size-(xs|sm|md|lg|xl)$/' ) ) {
			$s['size'] = $sz;
		}
		if ( $bt = self::class_value( $n, '/^elementor-button-(info|success|warning|danger)$/' ) ) {
			$s['button_type'] = $bt;
		}
		$icon = $this->dom->q( $a, '.elementor-button-icon' );
		if ( $icon ) {
			$s['selected_icon'] = $this->icon( $icon );
			$after              = false;
			if ( $txt ) {
				for ( $sib = $txt->nextSibling; $sib; $sib = $sib->nextSibling ) {
					if ( $sib === $icon ) {
						$after = true;
					}
				}
			}
			if ( Dom::has_class( $icon, 'elementor-align-icon-right' ) ) {
				$after = true;
			}
			$s['icon_align'] = $after ? 'right' : 'left';
		}
		if ( $a->hasAttribute( 'id' ) ) {
			$s['button_css_id'] = $a->getAttribute( 'id' );
		}
		$this->align_classes( $n, 'align', $s );
		return $s;
	}

	private function w_icon( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$i = $this->dom->q( $root, '.elementor-icon' );
		if ( ! $i ) {
			return null;
		}
		$s = [ 'selected_icon' => $this->icon( $i ) ];
		if ( 'a' === strtolower( $i->nodeName ) ) {
			$s['link'] = $this->link( $i );
		}
		if ( $v = self::class_value( $n, '/^elementor-view-(stacked|framed|default)$/' ) ) {
			$s['view'] = $v;
		}
		if ( $sh = self::class_value( $n, '/^elementor-shape-(circle|square|rounded)$/' ) ) {
			$s['shape'] = $sh;
		}
		return $s;
	}

	private function w_icon_box( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$s    = [];
		$wrap = $this->dom->q( $root, '.elementor-icon-box-icon' );
		$s['selected_icon'] = $wrap ? $this->icon( $wrap ) : [ 'value' => '', 'library' => '' ];
		$title = $this->dom->q( $root, '.elementor-icon-box-title' );
		if ( $title ) {
			[ $s['title_text'], $link ] = $this->title_parts( $title );
			$s['title_size']            = strtolower( $title->nodeName );
			if ( $link ) {
				$s['link'] = $link;
			}
		} else {
			$s['title_text'] = '';
		}
		$desc                   = $this->dom->q( $root, '.elementor-icon-box-description' );
		$s['description_text'] = $desc ? $this->inner( $desc ) : '';
		if ( $p = self::class_value( $n, '/^elementor-position-([\w-]+)$/' ) ) {
			$s['position'] = $p;
		}
		if ( $v = self::class_value( $n, '/^elementor-view-(stacked|framed|default)$/' ) ) {
			$s['view'] = $v;
		}
		if ( $sh = self::class_value( $n, '/^elementor-shape-(circle|square|rounded)$/' ) ) {
			$s['shape'] = $sh;
		}
		return $s;
	}

	private function w_image_box( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$s   = [];
		$img = $this->img( $this->dom->q( $root, '.elementor-image-box-img' ) );
		if ( $img ) {
			$s['image'] = $img;
		}
		$title = $this->dom->q( $root, '.elementor-image-box-title' );
		if ( $title ) {
			[ $s['title_text'], $link ] = $this->title_parts( $title );
			$s['title_size']            = strtolower( $title->nodeName );
			if ( $link ) {
				$s['link'] = $link;
			}
		}
		$desc                  = $this->dom->q( $root, '.elementor-image-box-description' );
		$s['description_text'] = $desc ? $this->inner( $desc ) : '';
		if ( $p = self::class_value( $n, '/^elementor-position-([\w-]+)$/' ) ) {
			$s['position'] = $p;
		}
		return $s;
	}

	private function w_icon_list( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$ul = $this->dom->q( $root, '.elementor-icon-list-items' );
		if ( ! $ul ) {
			return null;
		}
		$s = [ 'icon_list' => [] ];
		if ( Dom::has_class( $ul, 'elementor-inline-items' ) ) {
			$s['view'] = 'inline';
		}
		foreach ( Dom::children( $ul ) as $li ) {
			if ( ! Dom::has_class( $li, 'elementor-icon-list-item' ) ) {
				continue;
			}
			$item = [
				'_id'           => $this->rid(),
				'text'          => $this->inner( $this->dom->q( $li, '.elementor-icon-list-text' ) ),
				'selected_icon' => $this->icon( $this->dom->q( $li, '.elementor-icon-list-icon' ) ),
			];
			if ( $l = $this->link( $this->dom->q( $li, 'a' ) ) ) {
				$item['link'] = $l;
			}
			$s['icon_list'][] = $item;
		}
		return $s;
	}

	private function w_divider( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$s    = [];
		$text = $this->dom->q( $root, '.elementor-divider__text' );
		if ( $text ) {
			$s['look'] = 'line_text';
			$s['text'] = Dom::text( $text );
		}
		$icon = $this->dom->q( $root, '.elementor-divider__element .elementor-icon' );
		if ( $icon ) {
			$s['look']     = 'line_icon';
			$s['icon']     = $this->icon( $icon );
		}
		return $s;
	}

	private function w_spacer( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		return [];
	}

	private function w_video( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$s = [];
		if ( empty( $ds['youtube_url'] ) && empty( $ds['vimeo_url'] ) && empty( $ds['video_type'] ) ) {
			$iframe = $this->dom->q( $root, 'iframe' );
			if ( $iframe ) {
				$src = $iframe->getAttribute( 'src' ) ?: $iframe->getAttribute( 'data-src' );
				if ( false !== strpos( $src, 'youtube' ) && preg_match( '~embed/([\w-]+)~', $src, $m ) ) {
					$s['video_type']  = 'youtube';
					$s['youtube_url'] = 'https://www.youtube.com/watch?v=' . $m[1];
				} elseif ( false !== strpos( $src, 'vimeo' ) && preg_match( '~video/(\d+)~', $src, $m ) ) {
					$s['video_type'] = 'vimeo';
					$s['vimeo_url']  = 'https://vimeo.com/' . $m[1];
				}
			}
		}
		$video = $this->dom->q( $root, 'video' );
		if ( $video && ( ( $ds['video_type'] ?? '' ) === 'hosted' || ! $s ) ) {
			$src = $video->getAttribute( 'src' ) ?: ( $this->dom->q( $video, 'source' ) ? $this->dom->q( $video, 'source' )->getAttribute( 'src' ) : '' );
			if ( $src ) {
				$s['video_type'] = 'hosted';
				$s['hosted_url'] = [ 'url' => Util::abs_url( $src, $this->c->base ), 'id' => '' ];
			}
		}
		$overlay = $this->dom->q( $root, '.elementor-custom-embed-image-overlay' );
		if ( $overlay ) {
			$img = $this->img( $overlay );
			if ( ! $img && preg_match( '/url\([\'"]?(.*?)[\'"]?\)/', (string) $overlay->getAttribute( 'style' ), $m ) ) {
				$img = $this->media( Util::abs_url( $m[1], $this->c->base ) );
			}
			if ( $img ) {
				$s['show_image_overlay'] = 'yes';
				$s['image_overlay']      = $img;
			}
		}
		return $s;
	}

	private function w_google_maps( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$iframe = $this->dom->q( $root, 'iframe' );
		if ( ! $iframe ) {
			return null;
		}
		$src = html_entity_decode( $iframe->getAttribute( 'src' ) ?: $iframe->getAttribute( 'data-src' ) );
		parse_str( (string) parse_url( $src, PHP_URL_QUERY ), $q );
		$s = [ 'address' => $q['q'] ?? '' ];
		if ( isset( $q['z'] ) ) {
			$s['zoom'] = [ 'unit' => 'px', 'size' => (int) $q['z'], 'sizes' => [] ];
		}
		return $s;
	}

	private function w_counter( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$num = $this->dom->q( $root, '.elementor-counter-number' );
		if ( ! $num ) {
			return null;
		}
		$s = [
			'starting_number' => Util::num( $num->getAttribute( 'data-from-value' ) ?: 0 ),
			'ending_number'   => Util::num( $num->getAttribute( 'data-to-value' ) ?: 0 ),
			'prefix'          => Dom::text( $this->dom->q( $root, '.elementor-counter-number-prefix' ) ),
			'suffix'          => Dom::text( $this->dom->q( $root, '.elementor-counter-number-suffix' ) ),
			'title'           => Dom::text( $this->dom->q( $root, '.elementor-counter-title' ) ),
		];
		if ( $num->hasAttribute( 'data-duration' ) ) {
			$s['duration'] = (int) $num->getAttribute( 'data-duration' );
		}
		$delim                      = $num->getAttribute( 'data-delimiter' );
		$s['thousand_separator']    = $delim ? 'yes' : '';
		if ( $delim ) {
			$s['thousand_separator_char'] = $delim;
		}
		return $s;
	}

	private function w_progress( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$bar = $this->dom->q( $root, '.elementor-progress-bar' );
		if ( ! $bar ) {
			return null;
		}
		$s = [
			'title'              => Dom::text( $this->dom->q( $root, '.elementor-title' ) ),
			'percent'            => [ 'unit' => '%', 'size' => Util::num( $bar->getAttribute( 'data-max' ) ?: 0 ), 'sizes' => [] ],
			'inner_text'         => Dom::text( $this->dom->q( $root, '.elementor-progress-text' ) ),
			'display_percentage' => $this->dom->q( $root, '.elementor-progress-percentage' ) ? 'show' : 'hide',
		];
		$wrap = $this->dom->q( $root, '.elementor-progress-wrapper' );
		if ( $wrap && ( $t = self::class_value( $wrap, '/^progress-(info|success|warning|danger)$/' ) ) ) {
			$s['progress_type'] = $t;
		}
		return $s;
	}

	private function w_testimonial( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$s = [
			'testimonial_content' => $this->inner( $this->dom->q( $root, '.elementor-testimonial-content' ) ),
			'testimonial_name'    => Dom::text( $this->dom->q( $root, '.elementor-testimonial-name' ) ),
			'testimonial_job'     => Dom::text( $this->dom->q( $root, '.elementor-testimonial-job' ) ),
		];
		$img = $this->img( $this->dom->q( $root, '.elementor-testimonial-image' ) );
		if ( $img ) {
			$s['testimonial_image'] = $img;
		}
		$meta = $this->dom->q( $root, '.elementor-testimonial-meta' );
		if ( $meta && ( $pos = self::class_value( $meta, '/^elementor-testimonial-image-position-(aside|top)$/' ) ) ) {
			$s['testimonial_image_position'] = $pos;
		}
		$w = $this->dom->q( $root, '.elementor-testimonial-wrapper' );
		if ( $w && ( $al = self::class_value( $w, '/^elementor-testimonial-text-align-(left|center|right|justify)$/' ) ) ) {
			$s['testimonial_alignment'] = $al;
		}
		return $s;
	}

	private function w_tabs( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$titles   = $this->dom->qa( $root, '.elementor-tabs-wrapper .elementor-tab-title' );
		$contents = $this->dom->qa( $root, '.elementor-tabs-content-wrapper > .elementor-tab-content' );
		if ( ! $contents ) {
			return null;
		}
		$s = [ 'tabs' => [] ];
		foreach ( $contents as $i => $c ) {
			$s['tabs'][] = [
				'_id'         => $this->rid(),
				'tab_title'   => isset( $titles[ $i ] ) ? Dom::text( $titles[ $i ] ) : 'Tab ' . ( $i + 1 ),
				'tab_content' => $this->inner( $c ),
			];
		}
		if ( Dom::has_class( $n, 'elementor-tabs-view-vertical' ) ) {
			$s['type'] = 'vertical';
		}
		return $s;
	}

	private function accordion_like( \DOMElement $root, string $item_cls, string $icon_prefix ): ?array {
		$items = $this->dom->qa( $root, '.' . $item_cls );
		if ( ! $items ) {
			return null;
		}
		$s = [ 'tabs' => [] ];
		foreach ( $items as $it ) {
			$title = $this->dom->q( $it, '.elementor-tab-title' );
			$label = $title ? ( $this->dom->q( $title, 'a' ) ?: $this->dom->q( $title, '.elementor-accordion-title' ) ?: $this->dom->q( $title, '.elementor-toggle-title' ) ?: $title ) : null;
			$s['tabs'][] = [
				'_id'         => $this->rid(),
				'tab_title'   => Dom::text( $label ),
				'tab_content' => $this->inner( $this->dom->q( $it, '.elementor-tab-content' ) ),
			];
			if ( $title && ! isset( $s['title_html_tag'] ) ) {
				$s['title_html_tag'] = strtolower( $title->nodeName );
			}
		}
		$closed = $this->dom->q( $root, ".{$icon_prefix}-icon-closed" );
		$opened = $this->dom->q( $root, ".{$icon_prefix}-icon-opened" );
		if ( $closed ) {
			$s['selected_icon'] = $this->icon( $closed );
		}
		if ( $opened ) {
			$s['selected_active_icon'] = $this->icon( $opened );
		}
		return $s;
	}

	private function w_accordion( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		return $this->accordion_like( $root, 'elementor-accordion-item', 'elementor-accordion' );
	}

	private function w_toggle( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		return $this->accordion_like( $root, 'elementor-toggle-item', 'elementor-toggle' );
	}

	private function w_social_icons( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$items = $this->dom->qa( $root, '.elementor-social-icon' );
		if ( ! $items ) {
			return null;
		}
		$s = [ 'social_icon_list' => [] ];
		foreach ( $items as $it ) {
			$entry = [ '_id' => $this->rid(), 'social_icon' => $this->icon( $it ) ];
			if ( 'a' === strtolower( $it->nodeName ) && ( $l = $this->link( $it ) ) ) {
				$entry['link'] = $l;
			}
			$s['social_icon_list'][] = $entry;
		}
		if ( $sh = self::class_value( $n, '/^elementor-shape-(rounded|square|circle)$/' ) ) {
			$s['shape'] = $sh;
		}
		return $s;
	}

	private function w_star_rating( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$r = $this->dom->q( $root, '.elementor-star-rating' );
		if ( ! $r ) {
			return null;
		}
		$s = [ 'title' => Dom::text( $this->dom->q( $root, '.elementor-star-rating__title' ) ) ];
		if ( preg_match( '~([\d.]+)\s*/\s*(\d+)~', (string) $r->getAttribute( 'title' ), $m ) ) {
			$s['rating']       = Util::num( $m[1] );
			$s['rating_scale'] = $m[2];
		}
		if ( $st = self::class_value( $n, '/^elementor--star-style-(\w+)$/' ) ) {
			$s['star_style'] = $st;
		}
		return $s;
	}

	private function w_image_gallery( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$imgs = $this->dom->qa( $root, '.gallery-item img' );
		if ( ! $imgs ) {
			return null;
		}
		$s = [ 'wp_gallery' => [] ];
		foreach ( $imgs as $img ) {
			$s['wp_gallery'][] = [ 'id' => '', 'url' => Dom::img_src( $img, $this->c->base ) ];
		}
		$g = $this->dom->q( $root, '.gallery' );
		if ( $g && ( $cols = self::class_value( $g, '/^gallery-columns-(\d+)$/' ) ) ) {
			$s['gallery_columns'] = $cols;
		}
		$s['thumbnail_size'] = 'full';
		return $s;
	}

	private function w_image_carousel( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$s = [ 'carousel' => [], 'thumbnail_size' => 'full' ];
		foreach ( $this->dom->qa( $root, '.swiper-slide' ) as $slide ) {
			if ( Dom::has_class( $slide, 'swiper-slide-duplicate' ) ) {
				continue;
			}
			$img = $this->dom->q( $slide, 'img' );
			if ( $img ) {
				$s['carousel'][] = [ 'id' => '', 'url' => Dom::img_src( $img, $this->c->base ) ];
			}
		}
		return $s['carousel'] ? $s : null;
	}

	private function w_html( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$html = $this->dom->clean_inner( $root, $this->c->base, ! empty( $this->c->opts['keep_scripts'] ) );
		$this->c->scan_icon_libs( $html );
		return [ 'html' => $html ];
	}

	private function w_alert( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$a = $this->dom->q( $root, '.elementor-alert' );
		if ( ! $a ) {
			return null;
		}
		return [
			'alert_type'        => self::class_value( $a, '/^elementor-alert-(info|success|warning|danger)$/' ) ?: 'info',
			'alert_title'       => Dom::text( $this->dom->q( $a, '.elementor-alert-title' ) ),
			'alert_description' => $this->inner( $this->dom->q( $a, '.elementor-alert-description' ) ),
			'show_dismiss'      => $this->dom->q( $a, '.elementor-alert-dismiss' ) ? 'show' : 'hide',
		];
	}

	private function w_menu_anchor( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$a = $this->dom->q( $root, '.elementor-menu-anchor' );
		return $a ? [ 'anchor' => $a->getAttribute( 'id' ) ] : null;
	}

	/** Elements belonging to this widget, not to a nested widget inside it. */
	private function own( \DOMElement $widget, array $nodes ): array {
		return array_values( array_filter( $nodes, function ( $node ) use ( $widget ) {
			for ( $p = $node->parentNode; $p instanceof \DOMElement; $p = $p->parentNode ) {
				if ( $p->hasAttribute( 'data-element_type' ) ) {
					return $p === $widget;
				}
			}
			return false;
		} ) );
	}

	private function w_nested_tabs( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$titles = $this->own( $n, $this->dom->qa( $n, '.e-n-tab-title' ) );
		$s      = [ 'tabs' => [] ];
		$seen   = [];
		foreach ( $titles as $t ) {
			$key = $t->getAttribute( 'data-tab-index' ) ?: $t->getAttribute( 'aria-controls' ) ?: spl_object_hash( $t );
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$txt          = $this->dom->q( $t, '.e-n-tab-title-text' ) ?: $t;
			$s['tabs'][]  = [ '_id' => $this->rid(), 'tab_title' => Dom::text( $txt ) ];
		}
		return $s;
	}

	private function w_nested_accordion( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$items = $this->own( $n, $this->dom->qa( $n, '.e-n-accordion-item' ) );
		$s     = [ 'items' => [] ];
		foreach ( $items as $it ) {
			$txt          = $this->dom->q( $it, '.e-n-accordion-item-title-text' );
			$s['items'][] = [ '_id' => $this->rid(), 'item_title' => Dom::text( $txt ) ];
		}
		return $s;
	}

	/** Elementor Pro form → native form fields. */
	private function w_form( \DOMElement $n, \DOMElement $root, array $ds ): ?array {
		$form = $this->dom->q( $root, 'form' );
		if ( ! $form ) {
			return null;
		}
		$s           = [ 'form_name' => $form->getAttribute( 'name' ) ?: 'New Form', 'form_fields' => [] ];
		$all_hidden  = true;
		foreach ( $this->dom->qa( $form, '.elementor-field-group' ) as $g ) {
			$type = self::class_value( $g, '/^elementor-field-type-([\w-]+)$/' ) ?: 'text';
			if ( 'submit' === $type ) {
				$btn = $this->dom->q( $g, '.elementor-button-text' );
				if ( $btn ) {
					$s['button_text'] = Dom::text( $btn );
				}
				continue;
			}
			$label = $this->dom->q( $g, 'label' );
			if ( $label && ! Dom::has_class( $label, 'elementor-screen-only' ) ) {
				$all_hidden = false;
			}
			$input = $this->dom->q( $g, 'input' ) ?: $this->dom->q( $g, 'textarea' ) ?: $this->dom->q( $g, 'select' );
			$field = [
				'_id'         => $this->rid(),
				'field_type'  => $type,
				'field_label' => Dom::text( $label ),
				'placeholder' => $input ? (string) $input->getAttribute( 'placeholder' ) : '',
				'required'    => ( Dom::has_class( $g, 'elementor-field-required' ) || ( $input && $input->hasAttribute( 'required' ) ) ) ? 'true' : '',
				'width'       => self::class_value( $g, '/^elementor-col-(\d+)$/' ) ?: '100',
			];
			if ( $input && preg_match( '/^form-field-(.+)$/', (string) $input->getAttribute( 'id' ), $m ) ) {
				$field['custom_id'] = $m[1];
			}
			if ( 'select' === $type ) {
				$opts = [];
				foreach ( $this->dom->qa( $g, 'option' ) as $o ) {
					$opts[] = Dom::text( $o );
				}
				$field['field_options'] = implode( "\n", $opts );
			} elseif ( in_array( $type, [ 'radio', 'checkbox' ], true ) ) {
				$opts = [];
				foreach ( $this->dom->qa( $g, '.elementor-field-subgroup label' ) as $o ) {
					$opts[] = Dom::text( $o );
				}
				$field['field_options'] = implode( "\n", $opts );
			} elseif ( 'textarea' === $type && $input && $input->hasAttribute( 'rows' ) ) {
				$field['rows'] = (int) $input->getAttribute( 'rows' );
			} elseif ( 'acceptance' === $type ) {
				$field['acceptance_text'] = Dom::text( $this->dom->q( $g, '.elementor-field-subgroup label' ) );
			}
			$s['form_fields'][] = $field;
		}
		$s['show_labels'] = $all_hidden ? '' : 'yes';
		$this->c->warn( 'Form "' . $s['form_name'] . '": configure email/actions after import (submissions settings are not public).' );
		return $s;
	}
}
