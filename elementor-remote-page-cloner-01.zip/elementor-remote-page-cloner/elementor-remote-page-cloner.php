<?php
/**
 * Plugin Name:       Elementor Remote Page Cloner
 * Description:       Clone a single public Elementor page from any URL into an editable Elementor page on this site. Detects and installs required add-ons, rebuilds real widgets, imports media, and keeps a pixel-fidelity style layer.
 * Version:           1.0.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            ERPC
 * License:           GPL-2.0-or-later
 * Text Domain:       erpc
 */

defined( 'ABSPATH' ) || exit;

define( 'ERPC_VERSION', '1.0.0' );
define( 'ERPC_FILE', __FILE__ );
define( 'ERPC_DIR', plugin_dir_path( __FILE__ ) );
define( 'ERPC_URL', plugin_dir_url( __FILE__ ) );

require_once ERPC_DIR . 'includes/class-util.php';
require_once ERPC_DIR . 'includes/class-css-parser.php';
require_once ERPC_DIR . 'includes/class-dom.php';
require_once ERPC_DIR . 'includes/class-registry.php';
require_once ERPC_DIR . 'includes/class-env.php';
require_once ERPC_DIR . 'includes/class-detector.php';
require_once ERPC_DIR . 'includes/class-style-mapper.php';
require_once ERPC_DIR . 'includes/class-widgets.php';
require_once ERPC_DIR . 'includes/class-converter.php';
require_once ERPC_DIR . 'includes/class-validator.php';
require_once ERPC_DIR . 'includes/class-fetcher.php';
require_once ERPC_DIR . 'includes/class-jobs.php';
require_once ERPC_DIR . 'includes/class-installer.php';
require_once ERPC_DIR . 'includes/class-svg-sanitizer.php';
require_once ERPC_DIR . 'includes/class-media.php';
require_once ERPC_DIR . 'includes/class-importer.php';
require_once ERPC_DIR . 'includes/class-frontend.php';
require_once ERPC_DIR . 'includes/class-admin.php';

add_action( 'plugins_loaded', function () {
	ERPC\Frontend::init();
	if ( is_admin() ) {
		ERPC\Admin::init();
	}
} );

register_activation_hook( __FILE__, function () {
	ERPC\Jobs::ensure_dir();
	add_option( 'erpc_settings', ERPC\Admin::default_settings() );
} );
