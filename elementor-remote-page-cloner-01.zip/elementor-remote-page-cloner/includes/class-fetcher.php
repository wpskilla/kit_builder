<?php
namespace ERPC;

defined( 'ABSPATH' ) || exit;

/**
 * SSRF-safe remote fetching through the WordPress HTTP API.
 * wp_safe_remote_get() rejects localhost/private IP ranges and non-http(s) schemes.
 */
class Fetcher {

	const MAX_BYTES = 15728640; // 15 MB.

	public static function user_agent(): string {
		$s = Admin::settings();
		if ( ! empty( $s['user_agent'] ) ) {
			return $s['user_agent'];
		}
		return 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36 ERPC-PageCloner/' . ERPC_VERSION . '; +' . home_url( '/' );
	}

	/**
	 * @return array|\WP_Error ['body','code','url','type']
	 */
	public static function get( string $url, int $timeout = 30 ) {
		$url = esc_url_raw( trim( $url ) );
		if ( ! $url || ! wp_http_validate_url( $url ) ) {
			return new \WP_Error( 'erpc_bad_url', __( 'Invalid or disallowed URL (only public http/https addresses are allowed).', 'erpc' ) );
		}
		$res = wp_safe_remote_get(
			$url,
			[
				'timeout'             => $timeout,
				'redirection'         => 5,
				'user-agent'          => self::user_agent(),
				'limit_response_size' => self::MAX_BYTES,
				'headers'             => [
					'Accept'          => 'text/html,application/xhtml+xml,text/css,*/*;q=0.8',
					'Accept-Language' => 'en-US,en;q=0.9',
				],
			]
		);
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$body = (string) wp_remote_retrieve_body( $res );
		if ( $code >= 400 ) {
			$msg = sprintf( __( 'Remote server answered HTTP %d.', 'erpc' ), $code );
			if ( 403 === $code || 503 === $code ) {
				$msg .= ' ' . __( 'The site may be protected by a firewall/bot challenge (e.g. Cloudflare). Allow this server\'s IP or use a custom user agent in Settings.', 'erpc' );
			}
			return new \WP_Error( 'erpc_http', $msg );
		}
		$final = $url;
		if ( isset( $res['http_response'] ) && is_object( $res['http_response'] ) && method_exists( $res['http_response'], 'get_response_object' ) ) {
			$obj = $res['http_response']->get_response_object();
			if ( ! empty( $obj->url ) ) {
				$final = $obj->url;
			}
		}
		return [
			'body' => $body,
			'code' => $code,
			'url'  => $final,
			'type' => (string) wp_remote_retrieve_header( $res, 'content-type' ),
		];
	}
}
