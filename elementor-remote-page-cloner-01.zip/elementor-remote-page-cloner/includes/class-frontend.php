<?php
namespace ERPC;

defined( 'ABSPATH' ) || exit;

/**
 * Prints the per-page style layer.
 *
 * "editable" mode: printed in <head> BEFORE Elementor's CSS. Selectors have identical
 * specificity to Elementor's generated CSS, so every control you change in the editor wins,
 * while anything not mapped to a control still renders exactly like the source.
 * "locked" mode: printed AFTER Elementor's CSS – the source look always wins.
 */
class Frontend {

	private static $printed = [];

	public static function init(): void {
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue' ], 20 );
		add_action( 'wp_head', [ __CLASS__, 'head_early' ], 7 );
		add_action( 'wp_head', [ __CLASS__, 'head_late' ], 99 );
		// Templates (header/footer/section) rendered inside other pages.
		add_action( 'elementor/frontend/before_get_builder_content', [ __CLASS__, 'template_layer' ], 10, 1 );
	}

	private static function current_id(): int {
		if ( isset( $_GET['elementor-preview'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return absint( $_GET['elementor-preview'] ); // phpcs:ignore WordPress.Security.NonceVerification
		}
		return is_singular() ? (int) get_queried_object_id() : 0;
	}

	public static function enqueue(): void {
		$id = self::current_id();
		if ( ! $id || ! get_post_meta( $id, '_erpc_layer', true ) ) {
			return;
		}
		self::assets_for( $id );
	}

	private static function assets_for( int $id ): void {
		foreach ( (array) get_post_meta( $id, '_erpc_fonts', true ) as $i => $href ) {
			if ( $href ) {
				wp_enqueue_style( 'erpc-gf-' . $id . '-' . $i, esc_url_raw( $href ), [], null );
			}
		}
		$map = [
			'fa-solid'   => 'elementor-icons-fa-solid',
			'fa-regular' => 'elementor-icons-fa-regular',
			'fa-brands'  => 'elementor-icons-fa-brands',
			'eicons'     => 'elementor-icons',
		];
		foreach ( (array) get_post_meta( $id, '_erpc_icon_libs', true ) as $lib ) {
			if ( ! isset( $map[ $lib ] ) ) {
				continue;
			}
			if ( ! wp_style_is( $map[ $lib ], 'registered' ) && defined( 'ELEMENTOR_ASSETS_URL' ) ) {
				$file = 'eicons' === $lib ? 'eicons/css/elementor-icons.min.css' : 'font-awesome/css/' . substr( $lib, 3 ) . '.min.css';
				$deps = 'eicons' === $lib ? [] : [ 'erpc-fa-base' ];
				if ( 'eicons' !== $lib && ! wp_style_is( 'erpc-fa-base', 'registered' ) ) {
					wp_register_style( 'erpc-fa-base', ELEMENTOR_ASSETS_URL . 'lib/font-awesome/css/fontawesome.min.css', [], null );
				}
				wp_register_style( $map[ $lib ], ELEMENTOR_ASSETS_URL . 'lib/' . $file, $deps, null );
			}
			wp_enqueue_style( $map[ $lib ] );
		}
		foreach ( (array) get_post_meta( $id, '_erpc_plugin_css', true ) as $i => $path ) {
			$path = ltrim( (string) $path, '/' );
			if ( $path && false === strpos( $path, '..' ) && file_exists( WP_PLUGIN_DIR . '/' . $path ) ) {
				wp_enqueue_style( 'erpc-addon-' . md5( $path ), plugins_url( $path ), [], null );
			}
		}
	}

	public static function head_early(): void {
		$id = self::current_id();
		if ( $id && 'locked' !== get_post_meta( $id, '_erpc_mode', true ) ) {
			self::print_layer( $id );
		}
	}

	public static function head_late(): void {
		$id = self::current_id();
		if ( $id && 'locked' === get_post_meta( $id, '_erpc_mode', true ) ) {
			self::print_layer( $id );
		}
	}

	public static function template_layer( $document ): void {
		if ( ! is_object( $document ) || ! method_exists( $document, 'get_main_id' ) ) {
			return;
		}
		$id = (int) $document->get_main_id();
		if ( $id && $id !== self::current_id() && get_post_meta( $id, '_erpc_layer', true ) ) {
			self::print_layer( $id );
		}
	}

	private static function print_layer( int $id ): void {
		if ( isset( self::$printed[ $id ] ) ) {
			return;
		}
		$css = (string) get_post_meta( $id, '_erpc_layer', true );
		if ( '' === $css ) {
			return;
		}
		self::$printed[ $id ] = true;
		// Never allow the stylesheet to break out of the <style> element.
		$css = str_ireplace( '</style', '<\/style', $css );
		echo "\n<style id=\"erpc-layer-{$id}\">" . $css . "</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}
