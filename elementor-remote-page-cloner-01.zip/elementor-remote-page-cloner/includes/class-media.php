<?php
namespace ERPC;

defined( 'ABSPATH' ) || exit;

/**
 * Imports remote assets into the Media Library (fonts go to uploads/erpc/fonts).
 * Runs in small batches over AJAX so big pages never hit PHP time limits.
 */
class Media {

	const MAX_IMAGE = 25 * 1024 * 1024;
	const MAX_VIDEO = 80 * 1024 * 1024;

	private static function load_wp(): void {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
	}

	/**
	 * Process up to $batch pending assets of a job.
	 *
	 * @return array ['done'=>int,'total'=>int,'errors'=>[]]
	 */
	public static function process( array &$job, int $batch = 5 ): array {
		self::load_wp();
		$inline = json_decode( Jobs::get( $job['id'], 'inline.json' ), true ) ?: [];
		$errors = [];
		$count  = 0;
		foreach ( $job['assets'] as $i => $a ) {
			if ( 'pending' !== $a['status'] ) {
				continue;
			}
			if ( $count >= $batch ) {
				break;
			}
			$count++;
			$res = self::import_one( $a['url'], $a['kind'], $inline[ $a['url'] ] ?? null, $job );
			if ( is_wp_error( $res ) ) {
				$job['assets'][ $i ]['status'] = 'error';
				$job['assets'][ $i ]['error']  = $res->get_error_message();
				$errors[]                      = basename( (string) parse_url( $a['url'], PHP_URL_PATH ) ) . ': ' . $res->get_error_message();
			} else {
				$job['assets'][ $i ]['status'] = 'done';
				$job['media_map'][ $a['url'] ] = $res;
			}
		}
		$done = count( array_filter( $job['assets'], function ( $a ) {
			return 'pending' !== $a['status'];
		} ) );
		return [ 'done' => $done, 'total' => count( $job['assets'] ), 'errors' => $errors ];
	}

	/** @return array|\WP_Error ['id'=>int,'url'=>string] */
	public static function import_one( string $url, string $kind, ?string $inline, array &$job ) {
		if ( 'font' === $kind ) {
			return self::import_font( $url );
		}
		$existing = self::find_existing( $url );
		if ( $existing ) {
			return [ 'id' => $existing, 'url' => wp_get_attachment_url( $existing ) ];
		}

		if ( null !== $inline || 'svg' === $kind ) {
			$svg = $inline;
			if ( null === $svg ) {
				$r = Fetcher::get( $url );
				if ( is_wp_error( $r ) ) {
					return $r;
				}
				$svg = $r['body'];
			}
			$svg = Svg_Sanitizer::sanitize( $svg );
			if ( '' === $svg ) {
				return new \WP_Error( 'erpc_svg', __( 'SVG could not be sanitized.', 'erpc' ) );
			}
			$tmp = wp_tempnam( 'erpc-svg' );
			file_put_contents( $tmp, $svg );
			$name = null !== $inline ? 'icon-' . substr( md5( $url ), 0, 10 ) . '.svg' : self::filename( $url );
			return self::sideload( $tmp, $name, $url, $job, true );
		}

		$tmp = download_url( $url, 60 );
		if ( is_wp_error( $tmp ) ) {
			return $tmp;
		}
		$size = filesize( $tmp );
		if ( $size > ( 'video' === $kind ? self::MAX_VIDEO : self::MAX_IMAGE ) ) {
			@unlink( $tmp );
			return new \WP_Error( 'erpc_size', __( 'File too large, kept as remote URL.', 'erpc' ) );
		}
		return self::sideload( $tmp, self::filename( $url ), $url, $job, false );
	}

	private static function sideload( string $tmp, string $name, string $source, array &$job, bool $svg ) {
		$allow_svg = function ( $mimes ) {
			$mimes['svg'] = 'image/svg+xml';
			return $mimes;
		};
		$fix_svg = function ( $data, $file, $filename ) {
			if ( 'svg' === strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) ) ) {
				return [ 'ext' => 'svg', 'type' => 'image/svg+xml', 'proper_filename' => $data['proper_filename'] ?? false ];
			}
			return $data;
		};
		if ( $svg ) {
			add_filter( 'upload_mimes', $allow_svg );
			add_filter( 'wp_check_filetype_and_ext', $fix_svg, 10, 3 );
		}
		$id = media_handle_sideload( [ 'name' => $name, 'tmp_name' => $tmp ], 0, null, [ 'post_title' => pathinfo( $name, PATHINFO_FILENAME ) ] );
		if ( $svg ) {
			remove_filter( 'upload_mimes', $allow_svg );
			remove_filter( 'wp_check_filetype_and_ext', $fix_svg, 10 );
		}
		if ( is_wp_error( $id ) ) {
			@unlink( $tmp );
			return $id;
		}
		update_post_meta( $id, '_erpc_source_url', esc_url_raw( $source ) );
		update_post_meta( $id, '_erpc_job', $job['id'] );
		$job['created_attachments'][] = $id;
		return [ 'id' => $id, 'url' => wp_get_attachment_url( $id ) ];
	}

	private static function filename( string $url ): string {
		$base = basename( (string) parse_url( $url, PHP_URL_PATH ) );
		$base = sanitize_file_name( urldecode( $base ) );
		return $base ?: 'erpc-' . substr( md5( $url ), 0, 10 ) . '.jpg';
	}

	private static function find_existing( string $url ): int {
		$q = get_posts( [
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'meta_key'       => '_erpc_source_url',
			'meta_value'     => esc_url_raw( $url ),
			'no_found_rows'  => true,
		] );
		return $q ? (int) $q[0] : 0;
	}

	/** Fonts are not allowed in the Media Library; store them as plain files. */
	private static function import_font( string $url ) {
		Jobs::ensure_dir();
		$ext  = Util::ext( $url );
		$name = md5( $url ) . '.' . $ext;
		$path = Jobs::root() . '/fonts/' . $name;
		$u    = wp_upload_dir( null, false );
		$pub  = trailingslashit( $u['baseurl'] ) . 'erpc/fonts/' . $name;
		if ( file_exists( $path ) ) {
			return [ 'id' => 0, 'url' => $pub ];
		}
		$tmp = download_url( $url, 60 );
		if ( is_wp_error( $tmp ) ) {
			return $tmp;
		}
		if ( ! @rename( $tmp, $path ) ) {
			@copy( $tmp, $path );
			@unlink( $tmp );
		}
		return file_exists( $path ) ? [ 'id' => 0, 'url' => $pub ] : new \WP_Error( 'erpc_font', __( 'Could not store font file.', 'erpc' ) );
	}
}
