<?php
namespace ERPC;

defined( 'ABSPATH' ) || exit;

/**
 * Analyses the raw HTML of the source page. Pure PHP (no WP calls).
 */
class Detector {

	const DEFAULT_BREAKPOINTS = [
		'mobile'       => 767,
		'mobile_extra' => 880,
		'tablet'       => 1024,
		'tablet_extra' => 1200,
		'laptop'       => 1366,
		'widescreen'   => 2400,
	];

	/** @var Dom */
	private $dom;
	private $html;
	private $url;

	public function __construct( string $html, string $url ) {
		$this->html = $html;
		$this->url  = $url;
		$this->dom  = new Dom( $html );
	}

	public function dom(): Dom {
		return $this->dom;
	}

	public function analyse(): array {
		$html_unescaped = str_replace( '\\/', '/', $this->html );
		$body           = $this->dom->q( $this->dom->doc, 'body' );
		$body_classes   = $body ? Dom::classes( $body ) : [];

		$generators = [];
		foreach ( $this->dom->qa( $this->dom->doc, 'meta[name=generator]' ) as $m ) {
			$generators[] = $m->getAttribute( 'content' );
		}

		$wp_version = '';
		$elementor  = [
			'detected'          => false,
			'version'           => '',
			'pro_version'       => '',
			'features'          => [],
			'settings'          => [],
			'containers'        => false,
			'optimized_markup'  => false,
		];
		foreach ( $generators as $g ) {
			if ( preg_match( '/^WordPress\s+([\d.]+)/i', $g, $m ) ) {
				$wp_version = $m[1];
			}
			if ( preg_match( '/^Elementor\s+([\d.]+)(.*)$/i', $g, $m ) ) {
				$elementor['detected'] = true;
				$elementor['version']  = $m[1];
				if ( preg_match( '/features:\s*([^;]*)/', $m[2], $f ) ) {
					$elementor['features'] = array_filter( array_map( 'trim', explode( ',', $f[1] ) ) );
				}
				if ( preg_match( '/settings:\s*([^;]*)/', $m[2], $s ) ) {
					$elementor['settings'] = array_filter( array_map( 'trim', explode( ',', $s[1] ) ) );
				}
			}
		}

		$config = $this->extract_js_object( 'elementorFrontendConfig' );
		if ( $config ) {
			$elementor['detected'] = true;
			if ( ! $elementor['version'] && ! empty( $config['version'] ) ) {
				$elementor['version'] = $config['version'];
			}
		}
		$pro_config = $this->extract_js_object( 'ElementorProFrontendConfig' );

		// Asset paths → plugins + versions; theme.
		$assets = [];
		if ( preg_match_all( '~/wp-content/plugins/([a-z0-9._-]+)/[^"\'\s)]*~i', $html_unescaped, $mm, PREG_SET_ORDER ) ) {
			foreach ( $mm as $m ) {
				$slug = strtolower( $m[1] );
				$ver  = '';
				if ( preg_match( '/[?&]ver=([\w.-]+)/', $m[0], $v ) ) {
					$ver = $v[1];
				}
				if ( ! isset( $assets[ $slug ] ) || ( $ver && ! $assets[ $slug ] ) ) {
					$assets[ $slug ] = $ver;
				}
			}
		}
		if ( isset( $assets['elementor-pro'] ) ) {
			$elementor['pro_version'] = $assets['elementor-pro'] ?: 'unknown';
		} elseif ( $pro_config ) {
			$elementor['pro_version'] = 'unknown';
		}
		if ( ! $elementor['version'] && ! empty( $assets['elementor'] ) ) {
			$elementor['version'] = $assets['elementor'];
		}

		$theme = '';
		if ( preg_match( '~/wp-content/themes/([a-z0-9._-]+)/~i', $html_unescaped, $m ) ) {
			$theme = $m[1];
		}

		$is_wp = (bool) ( $wp_version || false !== strpos( $html_unescaped, '/wp-content/' ) || false !== strpos( $html_unescaped, '/wp-includes/' ) || false !== strpos( $html_unescaped, 'wp-json' ) );

		// Breakpoints.
		$bps = self::DEFAULT_BREAKPOINTS;
		$active_bps = [ 'mobile', 'tablet' ];
		if ( ! empty( $config['responsive']['breakpoints'] ) && is_array( $config['responsive']['breakpoints'] ) ) {
			$active_bps = [];
			foreach ( $config['responsive']['breakpoints'] as $name => $b ) {
				if ( isset( $b['value'] ) ) {
					$bps[ $name ] = (int) $b['value'];
				}
				if ( ! empty( $b['is_enabled'] ) ) {
					$active_bps[] = $name;
				}
			}
		}

		// Kit + page.
		$kit_id  = 0;
		$page_id = 0;
		foreach ( $body_classes as $c ) {
			if ( preg_match( '/^elementor-kit-(\d+)$/', $c, $m ) ) {
				$kit_id = (int) $m[1];
			}
			if ( preg_match( '/^(?:elementor-page-|page-id-|postid-)(\d+)$/', $c, $m ) && ! $page_id ) {
				$page_id = (int) $m[1];
			}
		}
		$template = 'default';
		if ( in_array( 'elementor-template-canvas', $body_classes, true ) ) {
			$template = 'elementor_canvas';
		} elseif ( in_array( 'elementor-template-full-width', $body_classes, true ) ) {
			$template = 'elementor_header_footer';
		}

		// Documents.
		$documents = [];
		$main_id   = 0;
		foreach ( $this->dom->qa( $this->dom->doc, '[data-elementor-type][data-elementor-id]' ) as $root ) {
			$id   = (int) $root->getAttribute( 'data-elementor-id' );
			$type = $root->getAttribute( 'data-elementor-type' );
			if ( isset( $documents[ $id ] ) ) {
				continue;
			}
			$stats = [ 'elements' => 0, 'widgets' => [], 'containers' => false, 'sections' => false ];
			$this->count( $root, $stats );
			$signals = [];
			$outer   = $this->dom->outer_html( $root );
			foreach ( Registry::all() as $slug => $p ) {
				foreach ( $p['doc_signals'] ?? [] as $s ) {
					if ( false !== strpos( $outer, $s ) ) {
						$signals[ $slug ] = true;
					}
				}
			}
			$nested = [];
			foreach ( $this->dom->qa( $root, '[data-elementor-id]' ) as $n ) {
				$nested[] = (int) $n->getAttribute( 'data-elementor-id' );
			}
			$documents[ $id ] = [
				'id'           => $id,
				'type'         => $type,
				'label'        => self::doc_label( $type, $id ),
				'elements'     => $stats['elements'],
				'widgets'      => $stats['widgets'],
				'containers'   => $stats['containers'],
				'sections'     => $stats['sections'],
				'doc_signals'  => array_keys( $signals ),
				'nested_docs'  => array_values( array_unique( $nested ) ),
				'is_main'      => false,
			];
			if ( $id === $page_id ) {
				$main_id = $id;
			}
		}
		if ( ! $main_id ) {
			foreach ( $documents as $d ) {
				if ( in_array( $d['type'], [ 'wp-page', 'wp-post', 'page', 'single-page', 'single-post', 'single' ], true ) && $d['elements'] ) {
					$main_id = $d['id'];
					break;
				}
			}
		}
		if ( ! $main_id && $documents ) {
			// Largest non header/footer document.
			$best = 0;
			foreach ( $documents as $d ) {
				if ( ! in_array( $d['type'], [ 'header', 'footer', 'popup' ], true ) && $d['elements'] > $best ) {
					$best    = $d['elements'];
					$main_id = $d['id'];
				}
			}
		}
		if ( $main_id ) {
			$documents[ $main_id ]['is_main'] = true;
		}
		foreach ( $documents as $d ) {
			if ( $d['containers'] ) {
				$elementor['containers'] = true;
			}
		}
		$elementor['optimized_markup'] = in_array( 'e_optimized_markup', $elementor['features'], true );

		// Per-plugin evidence.
		$plugins = [];
		foreach ( Registry::all() as $slug => $p ) {
			$asset_hit = array_key_exists( $slug, $assets );
			$sig_hit   = false;
			foreach ( $p['signals'] ?? [] as $s ) {
				if ( false !== strpos( $html_unescaped, $s ) ) {
					$sig_hit = true;
				}
			}
			if ( $asset_hit || $sig_hit ) {
				$plugins[ $slug ] = [
					'slug'           => $slug,
					'source_version' => $assets[ $slug ] ?? '',
					'evidence'       => array_values( array_filter( [ $asset_hit ? 'assets' : '', $sig_hit ? 'markup' : '' ] ) ),
					'widgets'        => [],
					'docs'           => [],
				];
			}
		}
		$unknown = [];
		foreach ( $documents as $d ) {
			foreach ( $d['widgets'] as $wt => $count ) {
				$slug = Registry::plugin_for_widget( $wt );
				if ( ! $slug ) {
					$unknown[ $wt ][] = $d['id'];
					continue;
				}
				if ( ! isset( $plugins[ $slug ] ) ) {
					$plugins[ $slug ] = [ 'slug' => $slug, 'source_version' => $assets[ $slug ] ?? '', 'evidence' => [], 'widgets' => [], 'docs' => [] ];
				}
				$plugins[ $slug ]['evidence'][]   = 'widgets';
				$plugins[ $slug ]['widgets'][]    = $wt;
				$plugins[ $slug ]['docs'][]       = $d['id'];
			}
			foreach ( $d['doc_signals'] as $slug ) {
				if ( ! isset( $plugins[ $slug ] ) ) {
					$plugins[ $slug ] = [ 'slug' => $slug, 'source_version' => $assets[ $slug ] ?? '', 'evidence' => [], 'widgets' => [], 'docs' => [] ];
				}
				$plugins[ $slug ]['evidence'][] = 'page-markup';
				$plugins[ $slug ]['docs'][]     = $d['id'];
			}
			if ( $d['elements'] && isset( $plugins['elementor'] ) ) {
				$plugins['elementor']['docs'][] = $d['id'];
			}
		}
		if ( $elementor['detected'] && ! isset( $plugins['elementor'] ) ) {
			$plugins['elementor'] = [ 'slug' => 'elementor', 'source_version' => $elementor['version'], 'evidence' => [ 'markup' ], 'widgets' => [], 'docs' => array_keys( $documents ) ];
		}
		if ( isset( $plugins['elementor'] ) ) {
			$plugins['elementor']['docs'] = array_keys( $documents );
		}
		foreach ( $plugins as &$p ) {
			$p['evidence'] = array_values( array_unique( $p['evidence'] ) );
			$p['widgets']  = array_values( array_unique( $p['widgets'] ) );
			$p['docs']     = array_values( array_unique( $p['docs'] ) );
		}
		unset( $p );

		// Other libraries of interest.
		$libs = [];
		foreach ( [
			'font-awesome' => '/font-awesome/',
			'eicons'       => '/eicons/',
			'swiper'       => 'swiper',
			'lottie'       => 'lottie',
			'gsap'         => 'gsap',
			'woocommerce'  => '/plugins/woocommerce/',
			'contact-form-7' => '/plugins/contact-form-7/',
			'wpforms'      => '/plugins/wpforms',
			'google-maps'  => 'maps.google',
			'recaptcha'    => 'recaptcha',
		] as $k => $needle ) {
			if ( false !== stripos( $html_unescaped, $needle ) ) {
				$libs[] = $k;
			}
		}

		return [
			'url'          => $this->url,
			'title'        => Dom::text( $this->dom->q( $this->dom->doc, 'title' ) ),
			'is_wordpress' => $is_wp,
			'wp_version'   => $wp_version,
			'theme'        => $theme,
			'elementor'    => $elementor,
			'breakpoints'  => $bps,
			'active_breakpoints' => array_values( array_unique( $active_bps ) ),
			'kit_id'       => $kit_id,
			'page_id'      => $page_id,
			'template'     => $template,
			'body_classes' => $body_classes,
			'documents'    => array_values( $documents ),
			'main_doc'     => $main_id,
			'plugins'      => array_values( $plugins ),
			'unknown_widgets' => array_map( 'array_values', array_map( 'array_unique', $unknown ) ),
			'libraries'    => $libs,
			'css_sources'  => $this->css_sources(),
			'font_links'   => $this->font_links(),
			'plugin_css'   => $this->plugin_css(),
		];
	}

	private static function doc_label( string $type, int $id ): string {
		$map = [
			'wp-page'     => 'Page content',
			'wp-post'     => 'Post content',
			'header'      => 'Header template',
			'footer'      => 'Footer template',
			'single-page' => 'Single page template',
			'single-post' => 'Single post template',
			'popup'       => 'Popup',
			'section'     => 'Section template',
			'page'        => 'Page template',
			'kit'         => 'Kit',
			'loop-item'   => 'Loop item',
		];
		return ( $map[ $type ] ?? ucfirst( $type ) ) . ' #' . $id;
	}

	private function count( \DOMElement $node, array &$stats ): void {
		foreach ( Dom::element_children( $node ) as $c ) {
			$stats['elements']++;
			$t = $c->getAttribute( 'data-element_type' );
			if ( 'container' === $t ) {
				$stats['containers'] = true;
			} elseif ( 'section' === $t ) {
				$stats['sections'] = true;
			}
			if ( 'widget' === $t ) {
				$wt = explode( '.', $c->getAttribute( 'data-widget_type' ) )[0];
				if ( $wt ) {
					$stats['widgets'][ $wt ] = ( $stats['widgets'][ $wt ] ?? 0 ) + 1;
				}
			}
			$this->count( $c, $stats );
		}
	}

	/** Locate `var NAME = {...};` in inline scripts and decode the JSON. */
	public function extract_js_object( string $name ): ?array {
		$pos = strpos( $this->html, $name );
		while ( false !== $pos ) {
			$eq = strpos( $this->html, '=', $pos );
			$br = strpos( $this->html, '{', $pos );
			if ( false !== $eq && false !== $br && $br > $eq && $br - $eq < 10 ) {
				$depth = 0;
				$quote = '';
				$len   = strlen( $this->html );
				for ( $i = $br; $i < $len; $i++ ) {
					$c = $this->html[ $i ];
					if ( $quote ) {
						if ( '\\' === $c ) {
							$i++;
							continue;
						}
						if ( $c === $quote ) {
							$quote = '';
						}
						continue;
					}
					if ( '"' === $c ) {
						$quote = $c;
					} elseif ( '{' === $c ) {
						$depth++;
					} elseif ( '}' === $c ) {
						$depth--;
						if ( 0 === $depth ) {
							$json = json_decode( substr( $this->html, $br, $i - $br + 1 ), true );
							return is_array( $json ) ? $json : null;
						}
					}
				}
			}
			$pos = strpos( $this->html, $name, $pos + strlen( $name ) );
		}
		return null;
	}

	/**
	 * Stylesheets we care about (Elementor generated CSS + local Google font CSS) and
	 * relevant inline <style> blocks.
	 */
	public function css_sources(): array {
		$out = [];
		foreach ( $this->dom->qa( $this->dom->doc, 'link' ) as $l ) {
			$rel  = strtolower( $l->getAttribute( 'rel' ) );
			$href = $l->getAttribute( 'href' );
			if ( ! $href || ( false === strpos( $rel, 'stylesheet' ) && 'preload' !== $rel ) ) {
				continue;
			}
			if ( 'preload' === $rel && 'style' !== $l->getAttribute( 'as' ) ) {
				continue;
			}
			$abs = Util::abs_url( $href, $this->url );
			$src = self::classify_css( $abs );
			if ( $src ) {
				$out[] = array_merge( [ 'url' => $abs ], $src );
			}
		}
		$i = 0;
		foreach ( $this->dom->qa( $this->dom->doc, 'style' ) as $s ) {
			$css = $s->textContent;
			$id  = $s->getAttribute( 'id' );
			$entry = null;
			if ( preg_match( '/elementor-post-(\d+)/', $id, $m ) ) {
				$entry = [ 'kind' => 'post', 'doc_id' => (int) $m[1] ];
			} elseif ( preg_match( '/\.elementor-kit-(\d+)/', $css, $m ) && false !== strpos( $css, '--e-global' ) ) {
				$entry = [ 'kind' => 'kit', 'doc_id' => (int) $m[1] ];
			} elseif ( preg_match( '/\.elementor-(\d+)\s+\.elementor-element/', $css, $m ) ) {
				$entry = [ 'kind' => 'post', 'doc_id' => (int) $m[1] ];
			} elseif ( false !== strpos( $css, '@font-face' ) && false === strpos( $css, 'elementor - v' ) ) {
				$entry = [ 'kind' => 'fonts', 'doc_id' => 0 ];
			}
			if ( $entry ) {
				$out[] = array_merge( [ 'url' => 'inline:' . ( $i++ ), 'inline' => $css ], $entry );
			}
		}
		return $out;
	}

	public static function classify_css( string $url ): ?array {
		if ( preg_match( '~/elementor/css/post-(\d+)\.css~', $url, $m ) ) {
			return [ 'kind' => 'post', 'doc_id' => (int) $m[1] ];
		}
		if ( preg_match( '~/elementor/css/global\.css~', $url ) ) {
			return [ 'kind' => 'global', 'doc_id' => 0 ];
		}
		if ( preg_match( '~/elementor/google-fonts/css/~', $url ) || preg_match( '~/uploads/.*fonts?.*\.css~i', $url ) ) {
			return [ 'kind' => 'fonts', 'doc_id' => 0 ];
		}
		return null;
	}

	/** Stylesheets that belong to plugins (used to style static fallbacks of add-on widgets). */
	public function plugin_css(): array {
		$out = [];
		foreach ( $this->dom->qa( $this->dom->doc, 'link' ) as $l ) {
			if ( false === strpos( strtolower( $l->getAttribute( 'rel' ) ), 'stylesheet' ) ) {
				continue;
			}
			$abs = Util::abs_url( $l->getAttribute( 'href' ), $this->url );
			if ( preg_match( '~/wp-content/plugins/(([a-z0-9._-]+)/[^?#]+\.css)~i', $abs, $m ) ) {
				$out[] = [ 'slug' => strtolower( $m[2] ), 'path' => $m[1], 'url' => $abs ];
			}
		}
		return $out;
	}

	/** Remote Google Fonts stylesheets (kept as links). */
	public function font_links(): array {
		$out = [];
		foreach ( $this->dom->qa( $this->dom->doc, 'link' ) as $l ) {
			$href = $l->getAttribute( 'href' );
			if ( $href && false !== strpos( $href, 'fonts.googleapis.com/css' ) ) {
				$out[] = Util::abs_url( $href, $this->url );
			}
		}
		return array_values( array_unique( $out ) );
	}
}
