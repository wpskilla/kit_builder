<?php
namespace ERPC;

defined( 'ABSPATH' ) || exit;

/**
 * Validates generated settings against the *installed* Elementor/add-on control
 * definitions (read at runtime), so we never save setting keys or option values the
 * recipient's Elementor version does not know. Dropped values are still rendered by the
 * style layer, so validation never costs visual fidelity.
 */
class Validator {

	const ALIASES = [
		'left'       => [ 'start', 'flex-start', 'inline-start', 'row' ],
		'right'      => [ 'end', 'flex-end', 'inline-end', 'row-reverse' ],
		'start'      => [ 'left', 'flex-start', 'top' ],
		'end'        => [ 'right', 'flex-end', 'bottom' ],
		'flex-start' => [ 'start', 'left', 'top' ],
		'flex-end'   => [ 'end', 'right', 'bottom' ],
		'top'        => [ 'block-start', 'start', 'flex-start' ],
		'bottom'     => [ 'block-end', 'end', 'flex-end' ],
		'center'     => [ 'middle', 'center center' ],
		'middle'     => [ 'center' ],
		'nowrap'     => [ 'no-wrap' ],
		'row'        => [ 'left' ],
		'row-reverse' => [ 'right' ],
	];

	/** Structural keys Elementor stores in element data that are not registered controls. */
	const STRUCTURAL = [ '_column_size', '_inline_size', '_inline_size_tablet', '_inline_size_mobile', 'structure', '_skin' ];

	const BP_SUFFIX = '/_(mobile|mobile_extra|tablet|tablet_extra|laptop|widescreen)$/';

	private $env;
	public $dropped = [];

	public function __construct( Env $env ) {
		$this->env = $env;
	}

	public function run( array &$elements ): void {
		foreach ( $elements as &$el ) {
			$this->element( $el );
		}
		unset( $el );
	}

	private function element( array &$el ): void {
		$controls = $this->env->controls( $el['elType'], $el['widgetType'] ?? '' );
		if ( is_array( $controls ) && $controls ) {
			$ctx = $el['elType'] . ( isset( $el['widgetType'] ) ? ':' . $el['widgetType'] : '' );
			foreach ( $el['settings'] as $k => $v ) {
				if ( 0 === strpos( $k, '__' ) ) {
					continue;
				}
				if ( in_array( $k, self::STRUCTURAL, true ) ) {
					continue;
				}
				if ( ! isset( $controls[ $k ] ) ) {
					// Elementor >= 3.4 stores responsive values as key_tablet / key_mobile even
					// when only the base control is registered (flagged is_responsive).
					$base = preg_replace( self::BP_SUFFIX, '', $k );
					if ( $base !== $k && isset( $controls[ $base ] ) && ( ! empty( $controls[ $base ]['is_responsive'] ) || isset( $controls[ $base ]['responsive'] ) ) ) {
						$c = $controls[ $base ];
					} else {
						$this->drop( $el, $k, $ctx );
						continue;
					}
				} else {
					$c = $controls[ $k ];
				}
				$type = $c['type'] ?? '';
				if ( in_array( $type, [ 'select', 'choose' ], true ) && is_string( $v ) && '' !== $v && ! empty( $c['options'] ) && is_array( $c['options'] ) ) {
					$opts = array_map( 'strval', array_keys( $c['options'] ) );
					$flat = ! array_filter( $c['options'], 'is_array' ) || 'choose' === $type;
					if ( $flat && ! in_array( $v, $opts, true ) ) {
						$alt = null;
						foreach ( self::ALIASES[ $v ] ?? [] as $a ) {
							if ( in_array( $a, $opts, true ) ) {
								$alt = $a;
								break;
							}
						}
						if ( null === $alt ) {
							$this->drop( $el, $k, $ctx );
						} else {
							$el['settings'][ $k ] = $alt;
						}
					}
				}
				if ( in_array( $type, [ 'slider', 'dimensions', 'gaps' ], true ) && is_array( $v ) && isset( $v['unit'] ) && ! empty( $c['size_units'] ) && is_array( $c['size_units'] ) ) {
					if ( ! in_array( $v['unit'], $c['size_units'], true ) ) {
						$this->drop( $el, $k, $ctx );
					}
				}
			}
		}
		if ( ! empty( $el['elements'] ) ) {
			foreach ( $el['elements'] as &$child ) {
				$this->element( $child );
			}
			unset( $child );
		}
	}

	private function drop( array &$el, string $k, string $ctx ): void {
		unset( $el['settings'][ $k ] );
		$this->dropped[ $ctx ][ $k ] = ( $this->dropped[ $ctx ][ $k ] ?? 0 ) + 1;
	}
}
