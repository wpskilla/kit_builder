<?php
/**
 * Uninstall: removes plugin options. Cloned pages, imported media and the
 * per-page style layer meta are intentionally kept (your pages keep working only
 * while the plugin is active – see readme "Deactivating").
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
delete_option( 'erpc_settings' );
delete_option( 'erpc_jobs' );
