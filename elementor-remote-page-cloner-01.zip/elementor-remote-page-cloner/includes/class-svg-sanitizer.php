<?php
namespace ERPC;

defined( 'ABSPATH' ) || exit;

/**
 * Allow-list SVG sanitizer (no external dependency).
 * Removes scripts, event handlers, foreignObject, external references and javascript: URLs.
 */
class Svg_Sanitizer {

	const ELEMENTS = [ 'svg', 'g', 'path', 'circle', 'ellipse', 'line', 'polyline', 'polygon', 'rect', 'text', 'tspan', 'textpath', 'defs', 'lineargradient', 'radialgradient', 'stop', 'clippath', 'mask', 'pattern', 'symbol', 'use', 'title', 'desc', 'style', 'filter', 'marker', 'image', 'switch',
		'feblend', 'fecolormatrix', 'fecomponenttransfer', 'fecomposite', 'feconvolvematrix', 'fediffuselighting', 'fedisplacementmap', 'fedistantlight', 'feflood', 'fefunca', 'fefuncb', 'fefuncg', 'fefuncr', 'fegaussianblur', 'femerge', 'femergenode', 'femorphology', 'feoffset', 'fepointlight', 'fespecularlighting', 'fespotlight', 'fetile', 'feturbulence', 'fedropshadow' ];

	public static function sanitize( string $svg ): string {
		$svg = trim( $svg );
		if ( '' === $svg || false === stripos( $svg, '<svg' ) ) {
			return '';
		}
		$svg = preg_replace( '/<!DOCTYPE[^>]*>/i', '', $svg );
		$svg = preg_replace( '/<!ENTITY[^>]*>/i', '', $svg );
		$doc  = new \DOMDocument();
		$prev = libxml_use_internal_errors( true );
		// Inline SVG taken from HTML may lack the namespace.
		if ( false === strpos( $svg, 'xmlns=' ) ) {
			$svg = preg_replace( '/<svg\b/i', '<svg xmlns="http://www.w3.org/2000/svg"', $svg, 1 );
		}
		$ok = $doc->loadXML( $svg, LIBXML_NONET );
		libxml_clear_errors();
		libxml_use_internal_errors( $prev );
		if ( ! $ok || ! $doc->documentElement || 'svg' !== strtolower( $doc->documentElement->localName ) ) {
			return '';
		}
		self::clean( $doc->documentElement );
		return $doc->saveXML( $doc->documentElement );
	}

	private static function clean( \DOMElement $el ): void {
		foreach ( iterator_to_array( $el->childNodes ) as $c ) {
			if ( $c instanceof \DOMElement ) {
				if ( ! in_array( strtolower( $c->localName ), self::ELEMENTS, true ) ) {
					$el->removeChild( $c );
					continue;
				}
				self::clean( $c );
			} elseif ( $c instanceof \DOMProcessingInstruction ) {
				$el->removeChild( $c );
			}
		}
		foreach ( iterator_to_array( $el->attributes ) as $attr ) {
			$name = strtolower( $attr->nodeName );
			$val  = trim( $attr->nodeValue );
			if ( 0 === strpos( $name, 'on' ) ) {
				$el->removeAttributeNode( $attr );
				continue;
			}
			if ( in_array( $name, [ 'href', 'xlink:href' ], true ) ) {
				if ( '' !== $val && '#' !== $val[0] && 0 !== stripos( $val, 'data:image/' ) ) {
					$el->removeAttributeNode( $attr );
				}
				continue;
			}
			if ( preg_match( '/(javascript|vbscript):|expression\s*\(/i', $val ) ) {
				$el->removeAttributeNode( $attr );
			}
		}
		if ( 'style' === strtolower( $el->localName ) ) {
			$el->textContent = preg_replace( '/@import[^;]*;|url\(\s*[\'"]?\s*(javascript|https?):[^)]*\)/i', '', $el->textContent );
		}
	}
}
