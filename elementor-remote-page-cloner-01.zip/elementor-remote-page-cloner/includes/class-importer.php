<?php
namespace ERPC;

defined( 'ABSPATH' ) || exit;

/**
 * Orchestrates prepare → (media batches) → build → undo for a job.
 */
class Importer {

	public static function default_options( array $analysis ): array {
		$main = (int) ( $analysis['main_doc'] ?? 0 );
		return [
			'docs'          => $main ? [ $main ] : [],
			'target'        => 'new',
			'replace_id'    => 0,
			'title'         => $analysis['title'] ? preg_replace( '/\s*[–|-].*$/u', '', $analysis['title'] ) : 'Cloned page',
			'status'        => 'draft',
			'template'      => 'source',
			'hide_title'    => true,
			'import_media'  => true,
			'import_videos' => false,
			'rewrite_links' => true,
			'fidelity'      => Admin::settings()['fidelity'],
			'keep_scripts'  => (bool) Admin::settings()['keep_scripts'],
		];
	}

	public static function sanitize_options( array $raw, array $analysis ): array {
		$d = self::default_options( $analysis );
		$valid_docs = array_map( 'intval', array_column( $analysis['documents'], 'id' ) );
		$docs = array_values( array_intersect( array_map( 'intval', (array) ( $raw['docs'] ?? $d['docs'] ) ), $valid_docs ) );
		return [
			'docs'          => $docs ?: $d['docs'],
			'target'        => in_array( $raw['target'] ?? '', [ 'new', 'replace', 'template' ], true ) ? $raw['target'] : 'new',
			'replace_id'    => absint( $raw['replace_id'] ?? 0 ),
			'title'         => sanitize_text_field( $raw['title'] ?? $d['title'] ) ?: $d['title'],
			'status'        => in_array( $raw['status'] ?? '', [ 'draft', 'publish', 'private' ], true ) ? $raw['status'] : 'draft',
			'template'      => in_array( $raw['template'] ?? '', [ 'source', 'default', 'elementor_canvas', 'elementor_header_footer' ], true ) ? $raw['template'] : 'source',
			'hide_title'    => ! empty( $raw['hide_title'] ),
			'import_media'  => ! empty( $raw['import_media'] ),
			'import_videos' => ! empty( $raw['import_videos'] ),
			'rewrite_links' => ! empty( $raw['rewrite_links'] ),
			'fidelity'      => in_array( $raw['fidelity'] ?? '', [ 'editable', 'locked' ], true ) ? $raw['fidelity'] : 'editable',
			'keep_scripts'  => ! empty( $raw['keep_scripts'] ),
		];
	}

	public static function converter( array $job, array $opts = [] ): Converter {
		$html    = Jobs::get( $job['id'], 'page.html' );
		$sources = json_decode( Jobs::get( $job['id'], 'css.json' ), true ) ?: [];
		$det     = new Detector( $html, $job['analysis']['url'] );
		return new Converter( $det->dom(), $job['analysis'], $sources, new WP_Env(), $opts );
	}

	/** Convert selected documents once to learn which assets need importing. */
	public static function prepare( array &$job, array $opts ): array {
		$conv     = self::converter( $job, $opts );
		$assets   = [];
		$inline   = [];
		$fb_slugs = [];
		$summary  = [];
		foreach ( $opts['docs'] as $doc_id ) {
			$r = $conv->convert_document( (int) $doc_id );
			if ( isset( $r['error'] ) ) {
				continue;
			}
			foreach ( $r['assets'] as $a ) {
				$assets[ $a['url'] ] = $a;
			}
			$inline   = array_merge( $inline, $r['inline'] );
			$fb_slugs = array_merge( $fb_slugs, $r['fallback_plugins'] );
			$summary[ $doc_id ] = $r['report'];
		}
		$list = [];
		foreach ( $assets as $a ) {
			$is_inline = 0 === strpos( $a['url'], 'erpc-inline:' );
			if ( ! $is_inline && ! $opts['import_media'] ) {
				continue;
			}
			if ( 'video' === $a['kind'] && ! $opts['import_videos'] ) {
				continue;
			}
			if ( 'json' === $a['kind'] ) {
				continue;
			}
			$list[] = [ 'url' => $a['url'], 'kind' => $a['kind'], 'status' => 'pending' ];
		}
		// Keep results of a previous run for the same URLs.
		foreach ( $list as &$item ) {
			if ( isset( $job['media_map'][ $item['url'] ] ) ) {
				$item['status'] = 'done';
			}
		}
		unset( $item );

		Jobs::put( $job['id'], 'inline.json', wp_json_encode( $inline ) );
		$job['assets']           = $list;
		$job['options']          = $opts;
		$job['fallback_plugins'] = array_values( array_unique( $fb_slugs ) );
		$job['status']           = 'prepared';
		self::collect_addon_css( $job );
		Jobs::log( $job, 'Prepared ' . count( $list ) . ' assets for ' . count( $opts['docs'] ) . ' document(s).' );
		return $summary;
	}

	/**
	 * Static fallbacks of add-on widgets still need the add-on's stylesheet. Prefer the local
	 * copy (plugin installed here); otherwise inline the source stylesheet.
	 */
	private static function collect_addon_css( array &$job ): void {
		$local  = [];
		$remote = '';
		$budget = 900 * 1024;
		foreach ( $job['analysis']['plugin_css'] ?? [] as $css ) {
			if ( ! in_array( $css['slug'], $job['fallback_plugins'], true ) ) {
				continue;
			}
			if ( file_exists( WP_PLUGIN_DIR . '/' . $css['path'] ) ) {
				$local[] = $css['path'];
				continue;
			}
			if ( strlen( $remote ) > $budget ) {
				continue;
			}
			$r = Fetcher::get( $css['url'], 20 );
			if ( ! is_wp_error( $r ) && strlen( $r['body'] ) < 400 * 1024 ) {
				$remote .= "\n/* {$css['path']} */\n" . Css_Parser::absolutize_urls( $r['body'], $css['url'] );
			}
		}
		$job['addon_css_local'] = array_values( array_unique( $local ) );
		Jobs::put( $job['id'], 'addon.css', $remote );
	}

	/** Build pages/templates. */
	public static function build( array &$job ) {
		if ( ! class_exists( '\Elementor\Plugin' ) ) {
			return new \WP_Error( 'erpc_no_elementor', __( 'Elementor must be installed and active.', 'erpc' ) );
		}
		$opts     = $job['options'];
		$analysis = $job['analysis'];
		$conv     = self::converter( $job, $opts );
		$env      = new WP_Env();

		$uses_containers = false;
		foreach ( $analysis['documents'] as $d ) {
			if ( in_array( (int) $d['id'], array_map( 'intval', $opts['docs'] ), true ) && $d['containers'] ) {
				$uses_containers = true;
			}
		}
		if ( $uses_containers && ! $env->container_active() ) {
			return new \WP_Error( 'erpc_container', __( 'The source page uses Flexbox Containers. Activate the "Flexbox Container" feature first (step 2).', 'erpc' ) );
		}

		$str_map = [];
		foreach ( $job['media_map'] as $src => $m ) {
			$str_map[ $src ] = $m['url'];
		}
		$origin    = Util::origin( $analysis['url'] );
		$addon_css = Jobs::get( $job['id'], 'addon.css' );
		$results   = [];
		$dropped   = [];
		$main      = (int) $analysis['main_doc'];

		foreach ( $opts['docs'] as $i => $doc_id ) {
			$doc_id = (int) $doc_id;
			$r      = $conv->convert_document( $doc_id );
			if ( isset( $r['error'] ) ) {
				continue;
			}
			$elements = $r['elements'];
			self::apply_media( $elements, $job['media_map'], $str_map );
			if ( $opts['rewrite_links'] && $origin ) {
				self::rewrite_links( $elements, $origin, untrailingslashit( home_url() ) );
			}
			$validator = new Validator( $env );
			$validator->run( $elements );
			$dropped = array_merge_recursive( $dropped, $validator->dropped );

			$doc_meta = null;
			foreach ( $analysis['documents'] as $d ) {
				if ( (int) $d['id'] === $doc_id ) {
					$doc_meta = $d;
				}
			}
			$is_page = $doc_id === $main || ( 1 === count( $opts['docs'] ) );
			$created = self::create_document( $elements, $opts, $analysis, $doc_meta, $is_page );
			if ( is_wp_error( $created ) ) {
				return $created;
			}
			[ $document, $post_id, $was_new ] = $created;

			$layer = strtr( $r['layer'], $str_map );
			$layer = str_replace( Converter::DOC_TOKEN, (string) $post_id, $layer );
			if ( $addon_css ) {
				$layer = $addon_css . "\n" . $layer;
			}
			update_post_meta( $post_id, '_erpc_layer', wp_slash( $layer ) );
			update_post_meta( $post_id, '_erpc_fonts', $analysis['font_links'] );
			update_post_meta( $post_id, '_erpc_icon_libs', $r['icon_libs'] );
			update_post_meta( $post_id, '_erpc_plugin_css', $job['addon_css_local'] ?? [] );
			update_post_meta( $post_id, '_erpc_mode', $opts['fidelity'] );
			update_post_meta( $post_id, '_erpc_source_url', esc_url_raw( $analysis['url'] ) );
			update_post_meta( $post_id, '_erpc_job', $job['id'] );

			$results[] = [
				'doc_id'   => $doc_id,
				'post_id'  => $post_id,
				'new'      => $was_new,
				'title'    => get_the_title( $post_id ),
				'type'     => get_post_type( $post_id ),
				'edit_url' => $document->get_edit_url(),
				'view_url' => get_permalink( $post_id ),
				'report'   => $r['report'],
			];
		}

		\Elementor\Plugin::$instance->files_manager->clear_cache();
		$job['result'] = [ 'posts' => $results, 'dropped' => $dropped ];
		$job['status'] = 'done';
		Jobs::log( $job, 'Built ' . count( $results ) . ' document(s).' );
		return $job['result'];
	}

	private static function create_document( array $elements, array $opts, array $analysis, ?array $doc_meta, bool $is_page ) {
		$plugin = \Elementor\Plugin::$instance;
		$title  = $opts['title'];
		$was_new = true;

		if ( ! $is_page ) {
			$title    = ( $doc_meta['label'] ?? 'Template' ) . ' – ' . $opts['title'];
			$document = $plugin->documents->create( 'section', [ 'post_title' => $title, 'post_status' => 'publish' ] );
		} elseif ( 'replace' === $opts['target'] ) {
			$post_id = (int) $opts['replace_id'];
			if ( ! $post_id || ! get_post( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
				return new \WP_Error( 'erpc_replace', __( 'Choose a valid page to replace.', 'erpc' ) );
			}
			$old = get_post_meta( $post_id, '_elementor_data', true );
			update_post_meta( $post_id, '_erpc_backup_data', wp_slash( is_string( $old ) ? $old : wp_json_encode( $old ) ) );
			update_post_meta( $post_id, '_erpc_backup_mode', (string) get_post_meta( $post_id, '_elementor_edit_mode', true ) );
			update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );
			if ( ! get_post_meta( $post_id, '_elementor_template_type', true ) ) {
				update_post_meta( $post_id, '_elementor_template_type', 'page' === get_post_type( $post_id ) ? 'wp-page' : 'wp-post' );
			}
			$document = $plugin->documents->get( $post_id, false );
			$was_new  = false;
		} elseif ( 'template' === $opts['target'] ) {
			$document = $plugin->documents->create( 'page', [ 'post_title' => $title, 'post_status' => 'publish' ] );
		} else {
			$document = $plugin->documents->create( 'wp-page', [ 'post_title' => $title, 'post_status' => $opts['status'], 'post_type' => 'page' ] );
		}
		if ( is_wp_error( $document ) ) {
			return $document;
		}
		if ( ! $document ) {
			return new \WP_Error( 'erpc_doc', __( 'Elementor could not create the document.', 'erpc' ) );
		}
		$post_id = $document->get_main_id();

		$settings = [];
		if ( $is_page ) {
			$template = 'source' === $opts['template'] ? ( $analysis['template'] ?? 'default' ) : $opts['template'];
			if ( 'template' !== $opts['target'] ) {
				$settings['template'] = $template;
			}
			if ( $opts['hide_title'] ) {
				$settings['hide_title'] = 'yes';
			}
		}
		$document->set_is_built_with_elementor( true );
		$saved = $document->save( [ 'elements' => $elements, 'settings' => $settings ] );
		if ( false === $saved ) {
			// Fallback: write the data directly.
			update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );
			update_post_meta( $post_id, '_elementor_data', wp_slash( wp_json_encode( $elements ) ) );
			update_post_meta( $post_id, '_elementor_version', defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '' );
		}
		if ( isset( $settings['template'] ) && 'page' === get_post_type( $post_id ) ) {
			update_post_meta( $post_id, '_wp_page_template', $settings['template'] );
		}
		return [ $document, $post_id, $was_new ];
	}

	/** Replace remote media URLs by imported ones (setting objects get the attachment id too). */
	public static function apply_media( array &$data, array $map, array $str_map ): void {
		foreach ( $data as $k => &$v ) {
			if ( is_array( $v ) ) {
				if ( isset( $v['url'] ) && is_string( $v['url'] ) && isset( $map[ $v['url'] ] ) && ! array_key_exists( 'is_external', $v ) ) {
					$m       = $map[ $v['url'] ];
					$v['url'] = $m['url'];
					if ( array_key_exists( 'id', $v ) || $m['id'] ) {
						$v['id'] = $m['id'] ?: '';
					}
				}
				self::apply_media( $v, $map, $str_map );
			} elseif ( is_string( $v ) && $str_map && ( false !== strpos( $v, 'http' ) || false !== strpos( $v, 'erpc-inline:' ) ) ) {
				$v = strtr( $v, $str_map );
			}
		}
		unset( $v );
	}

	/** Point links at this site instead of the source domain. */
	public static function rewrite_links( array &$data, string $origin, string $home ): void {
		foreach ( $data as $k => &$v ) {
			if ( is_array( $v ) ) {
				if ( array_key_exists( 'is_external', $v ) && isset( $v['url'] ) && is_string( $v['url'] ) && 0 === strpos( $v['url'], $origin ) ) {
					$v['url'] = $home . substr( $v['url'], strlen( $origin ) );
				}
				self::rewrite_links( $v, $origin, $home );
			} elseif ( is_string( $v ) && false !== strpos( $v, 'href=' ) ) {
				$v = preg_replace_callback(
					'~href=(["\'])' . preg_quote( $origin, '~' ) . '(/[^"\']*)?\1~i',
					function ( $m ) use ( $home ) {
						$path = $m[2] ?? '/';
						if ( Util::is_media_ext( Util::ext( $path ) ) ) {
							return $m[0];
						}
						return 'href=' . $m[1] . $home . $path . $m[1];
					},
					$v
				);
			}
		}
		unset( $v );
	}

	public static function undo( array &$job ) {
		foreach ( $job['result']['posts'] ?? [] as $p ) {
			$id = (int) $p['post_id'];
			if ( ! current_user_can( 'delete_post', $id ) ) {
				continue;
			}
			if ( $p['new'] ) {
				wp_delete_post( $id, true );
			} else {
				$backup = get_post_meta( $id, '_erpc_backup_data', true );
				update_post_meta( $id, '_elementor_data', wp_slash( $backup ) );
				update_post_meta( $id, '_elementor_edit_mode', get_post_meta( $id, '_erpc_backup_mode', true ) );
				foreach ( [ '_erpc_layer', '_erpc_fonts', '_erpc_icon_libs', '_erpc_plugin_css', '_erpc_mode', '_erpc_backup_data', '_erpc_backup_mode' ] as $m ) {
					delete_post_meta( $id, $m );
				}
			}
		}
		foreach ( $job['created_attachments'] ?? [] as $att ) {
			wp_delete_attachment( (int) $att, true );
		}
		if ( class_exists( '\Elementor\Plugin' ) ) {
			\Elementor\Plugin::$instance->files_manager->clear_cache();
		}
		$job['created_attachments'] = [];
		$job['media_map']           = [];
		$job['status']              = 'undone';
		Jobs::log( $job, 'Undone.' );
		return true;
	}
}
