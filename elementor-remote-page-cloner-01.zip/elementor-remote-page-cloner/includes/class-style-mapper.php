<?php
namespace ERPC;

defined( 'ABSPATH' ) || exit;

/**
 * Reverse-maps Elementor's generated CSS (post-ID.css) back to control settings.
 *
 * Elementor's CSS generator is setting-driven: every control writes declarations to
 * `.elementor-{doc} .elementor-element.elementor-element-{id}{suffix}`. We index those
 * rules by element id → breakpoint → normalized suffix and then apply per-element
 * "profiles" (suffix + property → control key).
 *
 * Anything we cannot map is still rendered pixel-exact by the style layer, so mapping
 * here is about *editability*, never about losing visuals.
 */
class Style_Mapper {

	/** @var array id => bp => suffix => [prop => value] */
	private $index = [];
	/** @var array CSS custom properties from kit (name => value) */
	private $vars = [];
	/** @var array breakpoint name => max width */
	private $bps = [];

	public function __construct( array $blocks, array $vars, array $breakpoints ) {
		$this->vars = $vars;
		$this->bps  = $breakpoints;
		$this->build_index( $blocks );
	}

	public function has( string $id ): bool {
		return isset( $this->index[ $id ] );
	}

	public function raw( string $id ): array {
		return $this->index[ $id ] ?? [];
	}

	/* ------------------------------------------------------------------ index */

	private function build_index( array $blocks ): void {
		foreach ( $blocks as $b ) {
			if ( 'rule' !== $b['type'] ) {
				continue;
			}
			$bp = $this->bp_suffix( $b['media'] );
			if ( null === $bp ) {
				continue;
			}
			foreach ( $b['selectors'] as $sel ) {
				if ( false !== strpos( $sel, 'elementor-motion-effects-layer' ) ) {
					continue; // duplicate of the main background selector.
				}
				if ( ! preg_match( '/\.elementor-element-([0-9a-f]{6,10})(?![\w-])/', $sel, $m, PREG_OFFSET_CAPTURE ) ) {
					continue;
				}
				$id     = $m[1][0];
				$suffix = substr( $sel, $m[0][1] + strlen( $m[0][0] ) );
				$suffix = self::normalize_suffix( $suffix );
				if ( null === $suffix ) {
					continue;
				}
				foreach ( $b['decls'] as [ $p, $v, $imp ] ) {
					$this->index[ $id ][ $bp ][ $suffix ][ $p ] = $v;
				}
			}
		}
	}

	/** Strip qualifiers glued to the element token and normalize Elementor wrapper names. */
	public static function normalize_suffix( string $s ): ?string {
		$s = str_replace( ':not(.elementor-motion-effects-element-type-background)', '', $s );
		// Qualifiers directly attached: .elementor-column.elementor-element[data-element_type="column"]
		$s = preg_replace( '/^((\.[\w-]+)|(\[[^\]]+\]))+/', '', $s );
		// Leading qualifiers may still remain after :hover etc. keep pseudo.
		$s = str_replace(
			[ '.elementor-widget-wrap.elementor-element-populated', '.elementor-element-populated', '.elementor-column-wrap' ],
			[ '.elementor-widget-wrap', '.elementor-widget-wrap', '.elementor-widget-wrap' ],
			$s
		);
		$s = preg_replace( '/\s*>\s*/', ' > ', $s );
		$s = preg_replace( '/\s+/', ' ', $s );
		$s = rtrim( $s );
		if ( '' !== $s && ' ' !== $s[0] && ':' !== $s[0] ) {
			$s = ' ' . $s;
		}
		// Map old column wrap nesting.
		$s = str_replace( ' > .elementor-widget-wrap > .elementor-widget-wrap', ' > .elementor-widget-wrap', $s );
		return $s;
	}

	/** Media query → Elementor responsive key suffix ('' desktop), or null if unsupported. */
	public function bp_suffix( string $media ): ?string {
		$media = strtolower( str_replace( ' ', '', $media ) );
		if ( '' === $media || 'all' === $media || 'screen' === $media ) {
			return '';
		}
		$max = preg_match( '/max-width:(\d+)px/', $media, $m1 ) ? (int) $m1[1] : null;
		$min = preg_match( '/min-width:(\d+)px/', $media, $m2 ) ? (int) $m2[1] : null;
		if ( null !== $max ) {
			foreach ( $this->bps as $name => $val ) {
				if ( abs( $val - $max ) <= 1 && 'widescreen' !== $name ) {
					return '_' . $name;
				}
			}
			return null;
		}
		if ( null !== $min ) {
			if ( isset( $this->bps['widescreen'] ) && $min === $this->bps['widescreen'] ) {
				return '_widescreen';
			}
			// (min-width: mobile+1) or (min-width: tablet+1) are "desktop" rules in Elementor.
			foreach ( [ 'mobile', 'tablet' ] as $n ) {
				if ( isset( $this->bps[ $n ] ) && $min === $this->bps[ $n ] + 1 ) {
					return '';
				}
			}
		}
		return null;
	}

	/* --------------------------------------------------------------- profiles */

	private static function common_widget(): array {
		$s = [ '', ' > .elementor-widget-container' ];
		return [
			[ $s, 'dims', 'margin', '_margin' ],
			[ $s, 'dims', 'padding', '_padding' ],
			[ $s, 'bg', '_background' ],
			[ $s, 'border', '_border' ],
			[ $s, 'dims', 'border-radius', '_border_radius' ],
			[ $s, 'shadow', 'box-shadow', '_box_shadow' ],
			[ [ '' ], 'number', 'z-index', '_z_index' ],
		];
	}

	private static function profile( string $el_type, string $widget ): array {
		if ( 'container' === $el_type ) {
			$s = [ '' ];
			return [
				[ $s, 'var_raw', '--display', 'container_type', [ 'grid' => 'grid', 'flex' => 'flex' ] ],
				[ $s, 'var_raw', '--flex-direction', 'flex_direction' ],
				[ $s, 'var_raw', '--justify-content', 'flex_justify_content' ],
				[ $s, 'var_raw', '--align-items', 'flex_align_items' ],
				[ $s, 'var_raw', '--flex-wrap', 'flex_wrap' ],
				[ $s, 'gap', '--gap', 'flex_gap' ],
				[ $s, 'slider', '--content-width', 'boxed_width' ],
				[ $s, 'slider', '--width', 'width' ],
				[ $s, 'slider', '--min-height', 'min_height' ],
				[ $s, 'slider', 'min-height', 'min_height' ],
				[ $s, 'dims', 'padding', 'padding' ],
				[ $s, 'vdims', '--padding', 'padding' ],
				[ $s, 'dims', 'margin', 'margin' ],
				[ $s, 'vdims', '--margin', 'margin' ],
				[ $s, 'bg', 'background' ],
				[ $s, 'border', 'border' ],
				[ $s, 'vdims', '--border-%s-width', 'border_width' ],
				[ $s, 'dims', 'border-radius', 'border_radius' ],
				[ $s, 'vdims', '--border-radius', 'border_radius' ],
				[ $s, 'shadow', 'box-shadow', 'box_shadow' ],
				[ $s, 'number', 'z-index', 'z_index' ],
				[ $s, 'number', '--z-index', 'z_index' ],
				[ $s, 'raw', 'overflow', 'overflow' ],
				[ $s, 'var_raw', '--overflow', 'overflow' ],
				[ $s, 'grid', '--e-con-grid-template-columns', 'grid_columns_grid' ],
				[ $s, 'grid', '--e-con-grid-template-rows', 'grid_rows_grid' ],
				[ $s, 'opacity', '--overlay-opacity', 'background_overlay_opacity' ],
				[ [ '::before', ' > .elementor-background-overlay', ' > .e-con-inner > .elementor-background-overlay' ], 'bg', 'background_overlay' ],
				[ [ '::before', ' > .elementor-background-overlay' ], 'opacity', 'opacity', 'background_overlay_opacity' ],
			];
		}
		if ( 'section' === $el_type ) {
			$s = [ '' ];
			return [
				[ $s, 'dims', 'padding', 'padding' ],
				[ $s, 'dims', 'margin', 'margin' ],
				[ $s, 'bg', 'background' ],
				[ $s, 'border', 'border' ],
				[ $s, 'dims', 'border-radius', 'border_radius' ],
				[ $s, 'shadow', 'box-shadow', 'box_shadow' ],
				[ $s, 'number', 'z-index', 'z_index' ],
				[ [ ' > .elementor-container' ], 'slider', 'max-width', 'content_width' ],
				[ [ ' > .elementor-container' ], 'slider', 'min-height', 'custom_height' ],
				[ [ ' > .elementor-background-overlay' ], 'bg', 'background_overlay' ],
				[ [ ' > .elementor-background-overlay' ], 'opacity', 'opacity', 'background_overlay_opacity' ],
			];
		}
		if ( 'column' === $el_type ) {
			$w = [ ' > .elementor-widget-wrap' ];
			return [
				[ [ '' ], 'inline_size', 'width', '_inline_size' ],
				[ $w, 'dims', 'padding', 'padding' ],
				[ $w, 'dims', 'margin', 'margin' ],
				[ $w, 'bg', 'background' ],
				[ $w, 'border', 'border' ],
				[ $w, 'dims', 'border-radius', 'border_radius' ],
				[ $w, 'shadow', 'box-shadow', 'box_shadow' ],
				[ $w, 'raw', 'align-content', 'content_position', [ 'flex-start' => 'top', 'center' => 'center', 'flex-end' => 'bottom', 'space-between' => 'space-between', 'space-around' => 'space-around', 'space-evenly' => 'space-evenly' ] ],
				[ [ ' > .elementor-widget-wrap > .elementor-background-overlay' ], 'bg', 'background_overlay' ],
				[ [ ' > .elementor-widget-wrap > .elementor-background-overlay' ], 'opacity', 'opacity', 'background_overlay_opacity' ],
				[ [ '' ], 'number', 'z-index', 'z_index' ],
			];
		}

		$p = self::common_widget();
		switch ( $widget ) {
			case 'heading':
				$t = [ ' .elementor-heading-title', ' .elementor-heading-title a' ];
				$p = array_merge( $p, [
					[ [ '' ], 'raw', 'text-align', 'align' ],
					[ $t, 'raw', 'text-align', 'align' ],
					[ $t, 'color', 'color', 'title_color' ],
					[ $t, 'typo', 'typography' ],
					[ $t, 'shadow', 'text-shadow', 'text_shadow' ],
					[ $t, 'raw', 'mix-blend-mode', 'blend_mode' ],
				] );
				break;
			case 'text-editor':
				$p = array_merge( $p, [
					[ [ '' ], 'raw', 'text-align', 'align' ],
					[ [ '' ], 'color', 'color', 'text_color' ],
					[ [ '' ], 'typo', 'typography' ],
					[ [ '' ], 'shadow', 'text-shadow', 'text_shadow' ],
				] );
				break;
			case 'image':
				$i = [ ' img' ];
				$p = array_merge( $p, [
					[ [ '' ], 'raw', 'text-align', 'align' ],
					[ $i, 'slider', 'width', 'width' ],
					[ $i, 'slider', 'max-width', 'space' ],
					[ $i, 'slider', 'height', 'height' ],
					[ $i, 'raw', 'object-fit', 'object-fit' ],
					[ $i, 'raw', 'object-position', 'object-position' ],
					[ $i, 'opacity', 'opacity', 'opacity' ],
					[ $i, 'border', 'image_border' ],
					[ $i, 'dims', 'border-radius', 'image_border_radius' ],
					[ $i, 'shadow', 'box-shadow', 'image_box_shadow' ],
					[ [ ' .widget-image-caption' ], 'color', 'color', 'caption_color' ],
					[ [ ' .widget-image-caption' ], 'typo', 'caption_typography' ],
				] );
				break;
			case 'button':
				$b = [ ' .elementor-button' ];
				$h = [ ' .elementor-button:hover', ' .elementor-button:focus' ];
				$p = array_merge( $p, [
					[ $b, 'typo', 'typography' ],
					[ $b, 'color', 'color', 'button_text_color' ],
					[ $b, 'bg', 'background' ],
					[ $b, 'dims', 'padding', 'text_padding' ],
					[ $b, 'border', 'border' ],
					[ $b, 'dims', 'border-radius', 'border_radius' ],
					[ $b, 'shadow', 'box-shadow', 'button_box_shadow' ],
					[ $b, 'shadow', 'text-shadow', 'text_shadow' ],
					[ $h, 'color', 'color', 'hover_color' ],
					[ $h, 'bg', 'button_background_hover' ],
					[ $h, 'color', 'border-color', 'button_hover_border_color' ],
				] );
				break;
			case 'icon':
				$p = array_merge( $p, [
					[ [ '' ], 'raw', 'text-align', 'align' ],
					[ [ ' .elementor-icon' ], 'slider', 'font-size', 'size' ],
					[ [ ' .elementor-icon' ], 'color', 'color', 'primary_color' ],
					[ [ ' .elementor-icon' ], 'dims', 'border-radius', 'border_radius' ],
					[ [ ' .elementor-icon:hover' ], 'color', 'color', 'hover_primary_color' ],
				] );
				break;
			case 'icon-box':
				$p = array_merge( $p, [
					[ [ ' .elementor-icon-box-wrapper' ], 'raw', 'text-align', 'text_align' ],
					[ [ ' .elementor-icon' ], 'slider', 'font-size', 'icon_size' ],
					[ [ ' .elementor-icon' ], 'color', 'color', 'primary_color' ],
					[ [ ' .elementor-icon-box-title', ' .elementor-icon-box-title a' ], 'color', 'color', 'title_color' ],
					[ [ ' .elementor-icon-box-title', ' .elementor-icon-box-title a' ], 'typo', 'title_typography' ],
					[ [ ' .elementor-icon-box-description' ], 'color', 'color', 'description_color' ],
					[ [ ' .elementor-icon-box-description' ], 'typo', 'description_typography' ],
				] );
				break;
			case 'image-box':
				$p = array_merge( $p, [
					[ [ ' .elementor-image-box-wrapper' ], 'raw', 'text-align', 'text_align' ],
					[ [ ' .elementor-image-box-img' ], 'slider', 'width', 'image_size' ],
					[ [ ' .elementor-image-box-img img' ], 'dims', 'border-radius', 'image_border_radius' ],
					[ [ ' .elementor-image-box-title' ], 'color', 'color', 'title_color' ],
					[ [ ' .elementor-image-box-title' ], 'typo', 'title_typography' ],
					[ [ ' .elementor-image-box-description' ], 'color', 'color', 'description_color' ],
					[ [ ' .elementor-image-box-description' ], 'typo', 'description_typography' ],
				] );
				break;
			case 'icon-list':
				$p = array_merge( $p, [
					[ [ ' .elementor-icon-list-text' ], 'color', 'color', 'text_color' ],
					[ [ ' .elementor-icon-list-item > .elementor-icon-list-text', ' .elementor-icon-list-item > a', ' .elementor-icon-list-text' ], 'typo', 'icon_typography' ],
					[ [ ' .elementor-icon-list-icon i' ], 'color', 'color', 'icon_color' ],
					[ [ '' ], 'slider', '--e-icon-list-icon-size', 'icon_size' ],
				] );
				break;
			case 'counter':
				$p = array_merge( $p, [
					[ [ ' .elementor-counter-number-wrapper' ], 'color', 'color', 'number_color' ],
					[ [ ' .elementor-counter-number-wrapper' ], 'typo', 'typography_number' ],
					[ [ ' .elementor-counter-title' ], 'color', 'color', 'title_color' ],
					[ [ ' .elementor-counter-title' ], 'typo', 'typography_title' ],
				] );
				break;
			case 'progress':
				$p = array_merge( $p, [
					[ [ ' .elementor-progress-wrapper .elementor-progress-bar' ], 'color', 'background-color', 'bar_color' ],
					[ [ ' .elementor-progress-wrapper' ], 'color', 'background-color', 'bar_bg_color' ],
					[ [ ' .elementor-progress-bar' ], 'slider', 'height', 'bar_height' ],
					[ [ ' .elementor-title' ], 'color', 'color', 'title_color' ],
					[ [ ' .elementor-title' ], 'typo', 'typography' ],
				] );
				break;
			case 'testimonial':
				$p = array_merge( $p, [
					[ [ ' .elementor-testimonial-content' ], 'color', 'color', 'content_content_color' ],
					[ [ ' .elementor-testimonial-content' ], 'typo', 'content_typography' ],
					[ [ ' .elementor-testimonial-name' ], 'color', 'color', 'name_text_color' ],
					[ [ ' .elementor-testimonial-name' ], 'typo', 'name_typography' ],
					[ [ ' .elementor-testimonial-job' ], 'color', 'color', 'job_text_color' ],
					[ [ ' .elementor-testimonial-job' ], 'typo', 'job_typography' ],
				] );
				break;
			case 'divider':
				$p = array_merge( $p, [
					[ [ '' ], 'var_raw', '--divider-border-style', 'style' ],
					[ [ '' ], 'color', '--divider-color', 'color' ],
					[ [ '' ], 'slider', '--divider-border-width', 'weight' ],
					[ [ ' .elementor-divider-separator' ], 'slider', 'width', 'width' ],
					[ [ ' .elementor-divider' ], 'slider', 'padding-top', 'gap' ],
					[ [ ' .elementor-divider' ], 'slider', 'padding-block-start', 'gap' ],
				] );
				break;
			case 'spacer':
				$p = array_merge( $p, [
					[ [ '' ], 'slider', '--spacer-size', 'space' ],
					[ [ ' .elementor-spacer-inner' ], 'slider', 'height', 'space' ],
				] );
				break;
			case 'google_maps':
				$p = array_merge( $p, [
					[ [ ' iframe' ], 'slider', 'height', 'height' ],
				] );
				break;
			case 'tabs':
			case 'accordion':
			case 'toggle':
				$p = array_merge( $p, [
					[ [ ' .elementor-tab-title', ' .elementor-tab-title a', ' .elementor-accordion-title', ' .elementor-toggle-title' ], 'color', 'color', 'title_color' ],
					[ [ ' .elementor-tab-title', ' .elementor-tab-title a', ' .elementor-accordion-title', ' .elementor-toggle-title' ], 'typo', 'title_typography' ],
					[ [ ' .elementor-tab-content' ], 'color', 'color', 'content_color' ],
					[ [ ' .elementor-tab-content' ], 'typo', 'content_typography' ],
				] );
				break;
		}
		return $p;
	}

	/* ------------------------------------------------------------------ apply */

	/**
	 * Map CSS of element $id into $settings.
	 */
	public function apply( string $id, string $el_type, string $widget, array &$settings ): void {
		if ( empty( $this->index[ $id ] ) ) {
			return;
		}
		$profile = self::profile( $el_type, $widget );
		foreach ( $this->index[ $id ] as $bp => $by_suffix ) {
			foreach ( $profile as $entry ) {
				$suffixes = $entry[0];
				$decls    = [];
				foreach ( $suffixes as $sfx ) {
					if ( isset( $by_suffix[ $sfx ] ) ) {
						$decls = array_merge( $decls, $by_suffix[ $sfx ] );
					}
				}
				if ( ! $decls ) {
					continue;
				}
				$this->run_op( $entry, $decls, $bp, $settings );
			}
		}
	}

	private function run_op( array $e, array $d, string $bp, array &$s ): void {
		$op = $e[1];
		switch ( $op ) {
			case 'color':
				if ( isset( $d[ $e[2] ] ) ) {
					$c = $this->resolve( $d[ $e[2] ] );
					if ( '' !== $c && Util::is_color( $c ) ) {
						$s[ $e[3] . $bp ] = $c;
					}
				}
				break;
			case 'slider':
				if ( isset( $d[ $e[2] ] ) ) {
					$v = $this->slider( $d[ $e[2] ] );
					if ( $v ) {
						$s[ $e[3] . $bp ] = $v;
					}
				}
				break;
			case 'opacity':
				if ( isset( $d[ $e[2] ] ) && is_numeric( trim( $d[ $e[2] ] ) ) ) {
					$s[ $e[3] . $bp ] = [ 'unit' => 'px', 'size' => Util::num( $d[ $e[2] ] ), 'sizes' => [] ];
				}
				break;
			case 'number':
				if ( isset( $d[ $e[2] ] ) && is_numeric( trim( $d[ $e[2] ] ) ) ) {
					$s[ $e[3] . $bp ] = Util::num( $d[ $e[2] ] );
				}
				break;
			case 'raw':
			case 'var_raw':
				if ( isset( $d[ $e[2] ] ) ) {
					$v = strtolower( trim( $this->resolve( $d[ $e[2] ] ) ) );
					if ( isset( $e[4] ) ) {
						$v = $e[4][ $v ] ?? null;
					}
					if ( null !== $v && '' !== $v && false === strpos( $v, 'var(' ) ) {
						$s[ $e[3] . $bp ] = $v;
					}
				}
				break;
			case 'inline_size':
				if ( isset( $d['width'] ) && preg_match( '/^([\d.]+)%$/', trim( $d['width'] ), $m ) ) {
					$s[ $e[3] . $bp ] = Util::num( $m[1] );
				}
				break;
			case 'dims':
				$v = $this->dims( $d, $e[2] );
				if ( $v ) {
					$s[ $e[3] . $bp ] = $v;
				}
				break;
			case 'vdims':
				$v = $this->vdims( $d, $e[2] );
				if ( $v ) {
					$s[ $e[3] . $bp ] = $v;
				}
				break;
			case 'gap':
				$v = $this->gap( $d );
				if ( $v ) {
					$s[ $e[3] . $bp ] = $v;
				}
				break;
			case 'grid':
				if ( isset( $d[ $e[2] ] ) && preg_match( '/repeat\(\s*(\d+)\s*,\s*1fr\s*\)/', $d[ $e[2] ], $m ) ) {
					$s[ $e[3] . $bp ] = [ 'unit' => 'fr', 'size' => (int) $m[1], 'sizes' => [] ];
				}
				break;
			case 'typo':
				$this->typo( $d, $e[2], $bp, $s );
				break;
			case 'bg':
				$this->bg( $d, $e[2], $bp, $s );
				break;
			case 'border':
				$this->border( $d, $e[2], $bp, $s );
				break;
			case 'shadow':
				$this->shadow( $d, $e[2], $e[3], $bp, $s );
				break;
		}
	}

	/* ---------------------------------------------------------------- helpers */

	/** Resolve var(--x, fallback) using kit vars. */
	public function resolve( string $v ): string {
		$guard = 0;
		while ( false !== strpos( $v, 'var(' ) && $guard++ < 5 ) {
			$v = preg_replace_callback(
				'/var\(\s*(--[\w-]+)\s*(?:,\s*([^()]*(?:\([^()]*\))?[^()]*))?\)/',
				function ( $m ) {
					if ( isset( $this->vars[ $m[1] ] ) ) {
						return $this->vars[ $m[1] ];
					}
					return isset( $m[2] ) && '' !== trim( $m[2] ) ? trim( $m[2] ) : $m[0];
				},
				$v,
				-1,
				$count
			);
			if ( ! $count ) {
				break;
			}
		}
		return trim( $v );
	}

	public function slider( string $raw ): ?array {
		$p = Util::parse_size( $this->resolve( $raw ) );
		if ( ! $p ) {
			$raw = trim( $this->resolve( $raw ) );
			if ( preg_match( '/^(calc|min|max|clamp)\(/', $raw ) ) {
				return [ 'unit' => 'custom', 'size' => $raw, 'sizes' => [] ];
			}
			return null;
		}
		if ( '' === $p['unit'] ) {
			$p['unit'] = 'px';
		}
		return [ 'unit' => $p['unit'], 'size' => $p['size'], 'sizes' => [] ];
	}

	/** Build a dimensions value from 4 raw strings; null if units differ/unsupported. */
	private function make_dims( array $four ): ?array {
		$unit = null;
		$vals = [];
		foreach ( $four as $raw ) {
			if ( null === $raw ) {
				$vals[] = '';
				continue;
			}
			$p = Util::parse_size( $this->resolve( $raw ) );
			if ( ! $p ) {
				return null;
			}
			if ( '' !== $p['unit'] ) {
				if ( null !== $unit && $unit !== $p['unit'] && 0 != $p['size'] ) {
					return null;
				}
				if ( null === $unit || 0 != $p['size'] ) {
					$unit = $p['unit'];
				}
			}
			$vals[] = (string) $p['size'];
		}
		if ( array_filter( $vals, 'strlen' ) === [] ) {
			return null;
		}
		$linked = count( array_unique( $vals ) ) === 1;
		return [
			'unit'     => $unit ?: 'px',
			'top'      => $vals[0],
			'right'    => $vals[1],
			'bottom'   => $vals[2],
			'left'     => $vals[3],
			'isLinked' => $linked,
		];
	}

	private function dims( array $d, string $prop ): ?array {
		$four = [ null, null, null, null ];
		if ( 'border-radius' === $prop ) {
			if ( isset( $d['border-radius'] ) && false === strpos( $d['border-radius'], '/' ) ) {
				$four = Util::expand_box( $d['border-radius'] );
			}
			foreach ( [ 'border-top-left-radius', 'border-top-right-radius', 'border-bottom-right-radius', 'border-bottom-left-radius' ] as $i => $l ) {
				if ( isset( $d[ $l ] ) ) {
					$four[ $i ] = $d[ $l ];
				}
			}
		} else {
			$base  = 'border-width' === $prop ? 'border' : $prop;
			$sfx   = 'border-width' === $prop ? '-width' : '';
			if ( isset( $d[ $prop ] ) ) {
				$four = Util::expand_box( $d[ $prop ] );
			}
			$logical = [ 'top' => 'block-start', 'right' => 'inline-end', 'bottom' => 'block-end', 'left' => 'inline-start' ];
			foreach ( [ 'top', 'right', 'bottom', 'left' ] as $i => $side ) {
				foreach ( [ "$base-$side$sfx", "$base-{$logical[$side]}$sfx" ] as $l ) {
					if ( isset( $d[ $l ] ) ) {
						$four[ $i ] = $d[ $l ];
					}
				}
			}
		}
		if ( [ null, null, null, null ] === $four ) {
			return null;
		}
		foreach ( $four as $v ) {
			if ( null !== $v && ( 'auto' === trim( $v ) || false !== strpos( $v, 'calc' ) ) ) {
				return null;
			}
		}
		return $this->make_dims( $four );
	}

	/** Container CSS variables like --padding-top or pattern --border-%s-width. */
	private function vdims( array $d, string $base ): ?array {
		$four = [ null, null, null, null ];
		$pattern = false !== strpos( $base, '%s' ) ? $base : $base . '-%s';
		if ( false === strpos( $base, '%s' ) && isset( $d[ $base ] ) ) {
			$four = Util::expand_box( $d[ $base ] );
		}
		$alias = [ 'top' => 'block-start', 'right' => 'inline-end', 'bottom' => 'block-end', 'left' => 'inline-start' ];
		foreach ( [ 'top', 'right', 'bottom', 'left' ] as $i => $side ) {
			foreach ( [ sprintf( $pattern, $side ), sprintf( $pattern, $alias[ $side ] ) ] as $k ) {
				if ( isset( $d[ $k ] ) ) {
					$four[ $i ] = $d[ $k ];
				}
			}
		}
		if ( [ null, null, null, null ] === $four ) {
			return null;
		}
		return $this->make_dims( $four );
	}

	private function gap( array $d ): ?array {
		$row = $col = null;
		if ( isset( $d['--gap'] ) ) {
			$parts = Util::split_ws( $this->resolve( $d['--gap'] ) );
			$row   = $parts[0] ?? null;
			$col   = $parts[1] ?? $row;
		}
		if ( isset( $d['--row-gap'] ) ) {
			$row = $this->resolve( $d['--row-gap'] );
		}
		if ( isset( $d['--column-gap'] ) ) {
			$col = $this->resolve( $d['--column-gap'] );
		}
		if ( null === $row && null === $col ) {
			return null;
		}
		$r = Util::parse_size( (string) ( $row ?? $col ) );
		$c = Util::parse_size( (string) ( $col ?? $row ) );
		if ( ! $r || ! $c ) {
			return null;
		}
		$unit = $c['unit'] ?: ( $r['unit'] ?: 'px' );
		return [
			'column'   => (string) $c['size'],
			'row'      => (string) $r['size'],
			'isLinked' => $c['size'] == $r['size'],
			'unit'     => $unit,
			'size'     => $c['size'],
		];
	}

	private function typo( array $d, string $p, string $bp, array &$s ): void {
		$set = false;
		if ( '' === $bp ) {
			if ( isset( $d['font-family'] ) ) {
				$fam = $this->resolve( $d['font-family'] );
				$fam = trim( explode( ',', $fam )[0], " \"'" );
				if ( $fam && ! in_array( strtolower( $fam ), [ 'inherit', 'initial', 'sans-serif', 'serif' ], true ) ) {
					$s[ "{$p}_font_family" ] = $fam;
					$set                     = true;
				}
			}
			foreach ( [ 'font-weight' => 'font_weight', 'text-transform' => 'text_transform', 'font-style' => 'font_style', 'text-decoration' => 'text_decoration', 'text-decoration-line' => 'text_decoration' ] as $css => $k ) {
				if ( isset( $d[ $css ] ) ) {
					$v = strtolower( $this->resolve( $d[ $css ] ) );
					if ( '' !== $v && false === strpos( $v, 'var(' ) ) {
						$s[ "{$p}_{$k}" ] = $v;
						$set              = true;
					}
				}
			}
		}
		foreach ( [ 'font-size' => 'font_size', 'line-height' => 'line_height', 'letter-spacing' => 'letter_spacing', 'word-spacing' => 'word_spacing' ] as $css => $k ) {
			if ( ! isset( $d[ $css ] ) ) {
				continue;
			}
			$raw = $this->resolve( $d[ $css ] );
			$v   = Util::parse_size( $raw );
			if ( $v ) {
				if ( '' === $v['unit'] ) {
					$v['unit'] = 'line-height' === $css ? 'em' : 'px';
				}
				$s[ "{$p}_{$k}{$bp}" ] = [ 'unit' => $v['unit'], 'size' => $v['size'], 'sizes' => [] ];
				$set                   = true;
			} elseif ( preg_match( '/^(calc|clamp|min|max)\(/', $raw ) ) {
				$s[ "{$p}_{$k}{$bp}" ] = [ 'unit' => 'custom', 'size' => $raw, 'sizes' => [] ];
				$set                   = true;
			}
		}
		if ( $set ) {
			$s[ "{$p}_typography" ] = 'custom';
		}
	}

	private function bg( array $d, string $p, string $bp, array &$s ): void {
		$color = null;
		$image = null;
		$grad  = null;
		if ( isset( $d['background'] ) ) {
			$val = $this->resolve( $d['background'] );
			foreach ( Util::split_ws( $val ) as $tok ) {
				if ( preg_match( '/^(linear|radial)-gradient\(/i', $tok ) ) {
					$grad = $tok;
				} elseif ( preg_match( '/^url\(/i', $tok ) ) {
					$image = $tok;
				} elseif ( Util::is_color( $tok ) ) {
					$color = $tok;
				}
			}
		}
		if ( isset( $d['background-color'] ) ) {
			$color = $this->resolve( $d['background-color'] );
		}
		if ( isset( $d['background-image'] ) ) {
			$bi = $this->resolve( $d['background-image'] );
			if ( preg_match( '/^(linear|radial)-gradient\(/i', $bi ) ) {
				$grad = $bi;
			} elseif ( preg_match( '/^url\(/i', $bi ) ) {
				$image = $bi;
			}
		}
		if ( $grad && $this->gradient( $grad, $p, $bp, $s ) ) {
			return;
		}
		if ( $color && 'transparent' !== strtolower( $color ) && Util::is_color( $color ) ) {
			$s[ "{$p}_background" ] = 'classic';
			$s[ "{$p}_color{$bp}" ]  = $color;
		}
		if ( $image && preg_match( '/url\(\s*[\'"]?(.*?)[\'"]?\s*\)/i', $image, $m ) && preg_match( '~^https?://~', $m[1] ) ) {
			$s[ "{$p}_background" ] = 'classic';
			$s[ "{$p}_image{$bp}" ]  = [ 'url' => $m[1], 'id' => '', 'size' => '', 'source' => 'library' ];
			$map                    = [
				'background-position'   => 'position',
				'background-repeat'     => 'repeat',
				'background-size'       => 'size',
				'background-attachment' => 'attachment',
			];
			foreach ( $map as $css => $k ) {
				if ( isset( $d[ $css ] ) ) {
					$v = strtolower( trim( $d[ $css ] ) );
					if ( 'background-position' === $css ) {
						$v = strtr( $v, [ '50%' => 'center', '0%' => 'left', '100%' => 'right' ] );
						if ( 'center' === $v ) {
							$v = 'center center';
						}
						if ( preg_match( '/^(top|bottom)\s+(left|right|center)$/', $v, $mm ) ) {
							$v = $mm[1] . ' ' . $mm[2];
						} elseif ( preg_match( '/^(left|right|center)\s+(top|bottom|center)$/', $v, $mm ) ) {
							$v = $mm[2] . ' ' . $mm[1];
						}
					}
					$s[ "{$p}_{$k}{$bp}" ] = $v;
				}
			}
		}
	}

	private function gradient( string $g, string $p, string $bp, array &$s ): bool {
		if ( ! preg_match( '/^(linear|radial)-gradient\((.*)\)$/is', trim( $g ), $m ) ) {
			return false;
		}
		$type  = strtolower( $m[1] );
		$args  = Util::split_top( $m[2], ',' );
		$angle = 180;
		$pos   = 'center center';
		if ( $args && ! Util::is_color( Util::split_ws( $args[0] )[0] ) ) {
			$first = strtolower( array_shift( $args ) );
			if ( preg_match( '/^(-?[\d.]+)deg$/', $first, $a ) ) {
				$angle = Util::num( $a[1] );
			} elseif ( preg_match( '/^to\s+(.*)$/', $first, $a ) ) {
				$angle = [ 'top' => 0, 'right' => 90, 'bottom' => 180, 'left' => 270 ][ trim( $a[1] ) ] ?? 180;
			} elseif ( preg_match( '/at\s+(.*)$/', $first, $a ) ) {
				$pos = trim( $a[1] );
			}
		}
		if ( count( $args ) !== 2 ) {
			return false;
		}
		$stops = [];
		foreach ( $args as $a ) {
			$parts = Util::split_ws( trim( $a ) );
			$col   = $parts[0];
			$at    = isset( $parts[1] ) ? (float) $parts[1] : ( $stops ? 100 : 0 );
			$stops[] = [ $col, Util::num( $at ) ];
		}
		$s[ "{$p}_background" ]             = 'gradient';
		$s[ "{$p}_color{$bp}" ]              = $stops[0][0];
		$s[ "{$p}_color_stop{$bp}" ]         = [ 'unit' => '%', 'size' => $stops[0][1], 'sizes' => [] ];
		$s[ "{$p}_color_b{$bp}" ]            = $stops[1][0];
		$s[ "{$p}_color_b_stop{$bp}" ]       = [ 'unit' => '%', 'size' => $stops[1][1], 'sizes' => [] ];
		$s[ "{$p}_gradient_type" ]          = $type;
		if ( 'linear' === $type ) {
			$s[ "{$p}_gradient_angle{$bp}" ] = [ 'unit' => 'deg', 'size' => $angle, 'sizes' => [] ];
		} else {
			$s[ "{$p}_gradient_position{$bp}" ] = $pos;
		}
		return true;
	}

	private function border( array $d, string $p, string $bp, array &$s ): void {
		$style = $d['border-style'] ?? null;
		$color = $d['border-color'] ?? null;
		$width = null;
		if ( isset( $d['border'] ) ) {
			foreach ( Util::split_ws( $this->resolve( $d['border'] ) ) as $t ) {
				if ( in_array( $t, [ 'none', 'solid', 'double', 'dotted', 'dashed', 'groove', 'ridge', 'inset', 'outset' ], true ) ) {
					$style = $t;
				} elseif ( Util::is_color( $t ) ) {
					$color = $t;
				} elseif ( Util::parse_size( $t ) ) {
					$width = $t;
				}
			}
		}
		if ( $style ) {
			$s[ "{$p}_border" ] = strtolower( trim( $style ) );
		}
		$dw = $this->dims( $width ? array_merge( $d, [ 'border-width' => $width ] ) : $d, 'border-width' );
		if ( $dw ) {
			$s[ "{$p}_width{$bp}" ] = $dw;
		}
		if ( $color ) {
			$c = $this->resolve( $color );
			if ( Util::is_color( $c ) ) {
				$s[ "{$p}_color{$bp}" ] = $c;
			}
		}
	}

	private function shadow( array $d, string $prop, string $group, string $bp, array &$s ): void {
		if ( ! isset( $d[ $prop ] ) || 'none' === trim( $d[ $prop ] ) ) {
			return;
		}
		$first  = Util::split_top( $this->resolve( $d[ $prop ] ), ',' )[0];
		$nums   = [];
		$color  = 'rgba(0,0,0,0.5)';
		$inset  = false;
		foreach ( Util::split_ws( $first ) as $t ) {
			if ( 'inset' === $t ) {
				$inset = true;
			} elseif ( Util::is_color( $t ) ) {
				$color = $t;
			} elseif ( $sz = Util::parse_size( $t ) ) {
				$nums[] = $sz['size'];
			}
		}
		if ( count( $nums ) < 2 ) {
			return;
		}
		if ( 'text-shadow' === $prop ) {
			$s[ "{$group}_text_shadow_type" ] = 'yes';
			$s[ "{$group}_text_shadow{$bp}" ] = [ 'horizontal' => $nums[0], 'vertical' => $nums[1], 'blur' => $nums[2] ?? 0, 'color' => $color ];
			return;
		}
		$s[ "{$group}_box_shadow_type" ] = 'yes';
		$s[ "{$group}_box_shadow{$bp}" ] = [ 'horizontal' => $nums[0], 'vertical' => $nums[1], 'blur' => $nums[2] ?? 0, 'spread' => $nums[3] ?? 0, 'color' => $color ];
		if ( $inset ) {
			$s[ "{$group}_box_shadow_position" ] = 'inset';
		}
	}
}
