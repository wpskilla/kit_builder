<?php
namespace ERPC;

defined( 'ABSPATH' ) || exit;

/**
 * Pure helpers. No WordPress calls here so the conversion engine can be unit-tested from CLI.
 */
class Util {

	/** Random 7-char hex id, same format Elementor uses. */
	public static function gen_id(): string {
		return substr( bin2hex( random_bytes( 4 ) ), 0, 7 );
	}

	/** Resolve a (possibly relative) URL against a base URL. */
	public static function abs_url( string $url, string $base ): string {
		$url = trim( html_entity_decode( $url, ENT_QUOTES ) );
		if ( '' === $url || preg_match( '~^(data:|mailto:|tel:|javascript:|#|erpc-inline:)~i', $url ) ) {
			return $url;
		}
		if ( preg_match( '~^https?://~i', $url ) ) {
			return $url;
		}
		$b = parse_url( $base );
		if ( empty( $b['host'] ) ) {
			return $url;
		}
		$scheme = $b['scheme'] ?? 'https';
		$origin = $scheme . '://' . $b['host'] . ( isset( $b['port'] ) ? ':' . $b['port'] : '' );
		if ( 0 === strpos( $url, '//' ) ) {
			return $scheme . ':' . $url;
		}
		if ( '/' === $url[0] ) {
			return $origin . self::normalize_path( $url );
		}
		$path = $b['path'] ?? '/';
		$dir  = substr( $path, 0, strrpos( $path, '/' ) + 1 );
		if ( '?' === $url[0] ) {
			return $origin . $path . $url;
		}
		return $origin . self::normalize_path( $dir . $url );
	}

	private static function normalize_path( string $path ): string {
		$query = '';
		if ( false !== ( $q = strpos( $path, '?' ) ) ) {
			$query = substr( $path, $q );
			$path  = substr( $path, 0, $q );
		}
		$out = [];
		foreach ( explode( '/', $path ) as $seg ) {
			if ( '..' === $seg ) {
				array_pop( $out );
			} elseif ( '.' !== $seg ) {
				$out[] = $seg;
			}
		}
		$res = implode( '/', $out );
		return ( '' === $res || '/' !== $res[0] ? '/' . $res : $res ) . $query;
	}

	public static function origin( string $url ): string {
		$p = parse_url( $url );
		if ( empty( $p['host'] ) ) {
			return '';
		}
		return ( $p['scheme'] ?? 'https' ) . '://' . $p['host'] . ( isset( $p['port'] ) ? ':' . $p['port'] : '' );
	}

	/**
	 * "20px" → ['unit'=>'px','size'=>20]. Unitless → unit ''. Returns null when not a plain size.
	 */
	public static function parse_size( string $v ): ?array {
		$v = strtolower( trim( str_replace( '!important', '', $v ) ) );
		if ( preg_match( '/^(-?\d*\.?\d+)(px|em|rem|%|vw|vh|vmin|vmax|deg|s|ms|fr|ch|ex)?$/', $v, $m ) ) {
			return [
				'unit' => $m[2] ?? '',
				'size' => self::num( $m[1] ),
			];
		}
		return null;
	}

	/** Numeric string → int|float without trailing zeros. */
	public static function num( $n ) {
		$f = (float) $n;
		return ( floor( $f ) == $f && abs( $f ) < 1e12 ) ? (int) $f : round( $f, 4 );
	}

	/** Split a CSS value by whitespace, ignoring whitespace inside parentheses. */
	public static function split_ws( string $v ): array {
		$out   = [];
		$buf   = '';
		$depth = 0;
		$len   = strlen( $v );
		for ( $i = 0; $i < $len; $i++ ) {
			$c = $v[ $i ];
			if ( '(' === $c ) {
				$depth++;
			} elseif ( ')' === $c ) {
				$depth--;
			}
			if ( 0 === $depth && ctype_space( $c ) ) {
				if ( '' !== $buf ) {
					$out[] = $buf;
				}
				$buf = '';
				continue;
			}
			$buf .= $c;
		}
		if ( '' !== $buf ) {
			$out[] = $buf;
		}
		return $out;
	}

	/** Split by a delimiter at paren depth 0. */
	public static function split_top( string $v, string $delim = ',' ): array {
		$out   = [];
		$buf   = '';
		$depth = 0;
		$quote = '';
		$len   = strlen( $v );
		for ( $i = 0; $i < $len; $i++ ) {
			$c = $v[ $i ];
			if ( $quote ) {
				if ( $c === $quote && '\\' !== $v[ $i - 1 ] ) {
					$quote = '';
				}
				$buf .= $c;
				continue;
			}
			if ( '"' === $c || "'" === $c ) {
				$quote = $c;
			} elseif ( '(' === $c || '[' === $c ) {
				$depth++;
			} elseif ( ')' === $c || ']' === $c ) {
				$depth--;
			} elseif ( 0 === $depth && $c === $delim ) {
				$out[] = trim( $buf );
				$buf   = '';
				continue;
			}
			$buf .= $c;
		}
		if ( '' !== trim( $buf ) ) {
			$out[] = trim( $buf );
		}
		return $out;
	}

	/** CSS box shorthand ("10px 20px") → [top,right,bottom,left] raw strings. */
	public static function expand_box( string $v ): array {
		$p = self::split_ws( trim( $v ) );
		switch ( count( $p ) ) {
			case 1:
				return [ $p[0], $p[0], $p[0], $p[0] ];
			case 2:
				return [ $p[0], $p[1], $p[0], $p[1] ];
			case 3:
				return [ $p[0], $p[1], $p[2], $p[1] ];
			default:
				return [ $p[0], $p[1], $p[2], $p[3] ];
		}
	}

	public static function is_color( string $t ): bool {
		$t = strtolower( trim( $t ) );
		return (bool) preg_match( '/^(#[0-9a-f]{3,8}|rgba?\(|hsla?\(|var\(|transparent$|currentcolor$|white$|black$|red$|blue$|green$|gray$|grey$|yellow$|orange$|purple$|pink$)/', $t );
	}

	public static function ext( string $url ): string {
		$path = parse_url( $url, PHP_URL_PATH );
		return strtolower( pathinfo( (string) $path, PATHINFO_EXTENSION ) );
	}

	public static function is_media_ext( string $ext ): bool {
		return in_array( $ext, [ 'jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'svg', 'bmp', 'ico', 'mp4', 'webm', 'ogg', 'mov', 'json', 'woff', 'woff2', 'ttf', 'otf', 'eot' ], true );
	}

	public static function asset_kind( string $url ): string {
		if ( 0 === strpos( $url, 'erpc-inline:' ) ) {
			return 'svg';
		}
		$e = self::ext( $url );
		if ( in_array( $e, [ 'woff', 'woff2', 'ttf', 'otf', 'eot' ], true ) ) {
			return 'font';
		}
		if ( in_array( $e, [ 'mp4', 'webm', 'ogg', 'mov' ], true ) ) {
			return 'video';
		}
		if ( 'svg' === $e ) {
			return 'svg';
		}
		if ( 'json' === $e ) {
			return 'json';
		}
		return 'image';
	}

	/** Recursively walk an array and apply $fn(&$value, $key, &$parent). */
	public static function walk( array &$arr, callable $fn ): void {
		foreach ( $arr as $k => &$v ) {
			$fn( $v, $k, $arr );
			if ( is_array( $v ) ) {
				self::walk( $v, $fn );
			}
		}
		unset( $v );
	}
}
