<?php
namespace ERPC;

defined( 'ABSPATH' ) || exit;

/**
 * Small, dependency-free CSS parser good enough for Elementor's generated CSS.
 *
 * Output: flat list of blocks:
 *   ['type'=>'rule','media'=>'(max-width:767px)','selectors'=>[...],'decls'=>[[prop,value,important],...]]
 *   ['type'=>'font-face','media'=>'','decls'=>[...]]
 *   ['type'=>'raw','media'=>'','raw'=>'@keyframes x{...}']
 *   ['type'=>'import','media'=>'','raw'=>'@import url(...);']
 */
class Css_Parser {

	public static function parse( string $css, string $media = '' ): array {
		$css = preg_replace( '~/\*.*?\*/~s', '', $css );
		$out = [];
		$len = strlen( $css );
		$i   = 0;
		while ( $i < $len ) {
			[ $prelude, $i, $term ] = self::read_prelude( $css, $i );
			if ( null === $term ) {
				break;
			}
			$prelude = trim( $prelude );
			if ( ';' === $term ) {
				if ( 0 === stripos( $prelude, '@import' ) ) {
					$out[] = [ 'type' => 'import', 'media' => $media, 'raw' => $prelude . ';' ];
				}
				continue;
			}
			if ( '}' === $term ) {
				continue; // stray closing brace.
			}
			[ $body, $i ] = self::read_block( $css, $i );
			if ( '' === $prelude ) {
				continue;
			}
			if ( '@' === $prelude[0] ) {
				$name = strtolower( preg_split( '/[\s({]/', substr( $prelude, 1 ), 2 )[0] );
				if ( 'media' === $name ) {
					$m     = trim( substr( $prelude, 6 ) );
					$inner = '' === $media ? $m : $media . ' and ' . $m;
					foreach ( self::parse( $body, $inner ) as $child ) {
						$out[] = $child;
					}
				} elseif ( 'font-face' === $name ) {
					$out[] = [ 'type' => 'font-face', 'media' => $media, 'decls' => self::parse_decls( $body ) ];
				} else {
					$out[] = [ 'type' => 'raw', 'media' => $media, 'raw' => $prelude . '{' . $body . '}' ];
				}
				continue;
			}
			$out[] = [
				'type'      => 'rule',
				'media'     => $media,
				'selectors' => Util::split_top( $prelude, ',' ),
				'decls'     => self::parse_decls( $body ),
			];
		}
		return $out;
	}

	private static function read_prelude( string $css, int $i ): array {
		$len   = strlen( $css );
		$buf   = '';
		$quote = '';
		$depth = 0;
		for ( ; $i < $len; $i++ ) {
			$c = $css[ $i ];
			if ( $quote ) {
				if ( $c === $quote && '\\' !== $css[ $i - 1 ] ) {
					$quote = '';
				}
				$buf .= $c;
				continue;
			}
			if ( '"' === $c || "'" === $c ) {
				$quote = $c;
			} elseif ( '(' === $c ) {
				$depth++;
			} elseif ( ')' === $c ) {
				$depth--;
			} elseif ( 0 === $depth && ( '{' === $c || ';' === $c || '}' === $c ) ) {
				return [ $buf, $i + 1, $c ];
			}
			$buf .= $c;
		}
		return [ $buf, $len, null ];
	}

	private static function read_block( string $css, int $i ): array {
		$len   = strlen( $css );
		$depth = 1;
		$quote = '';
		$start = $i;
		for ( ; $i < $len; $i++ ) {
			$c = $css[ $i ];
			if ( $quote ) {
				if ( $c === $quote && '\\' !== $css[ $i - 1 ] ) {
					$quote = '';
				}
				continue;
			}
			if ( '"' === $c || "'" === $c ) {
				$quote = $c;
			} elseif ( '{' === $c ) {
				$depth++;
			} elseif ( '}' === $c ) {
				$depth--;
				if ( 0 === $depth ) {
					return [ substr( $css, $start, $i - $start ), $i + 1 ];
				}
			}
		}
		return [ substr( $css, $start ), $len ];
	}

	public static function parse_decls( string $body ): array {
		$out = [];
		foreach ( Util::split_top( $body, ';' ) as $d ) {
			$pos = strpos( $d, ':' );
			if ( false === $pos ) {
				continue;
			}
			$prop = trim( substr( $d, 0, $pos ) );
			$val  = trim( substr( $d, $pos + 1 ) );
			if ( '' === $prop || '' === $val ) {
				continue;
			}
			$imp = false;
			if ( preg_match( '/\s*!\s*important\s*$/i', $val ) ) {
				$imp = true;
				$val = trim( preg_replace( '/\s*!\s*important\s*$/i', '', $val ) );
			}
			if ( 0 !== strpos( $prop, '--' ) ) {
				$prop = strtolower( $prop );
			}
			$out[] = [ $prop, $val, $imp ];
		}
		return $out;
	}

	/** Make every url(...) absolute against $base. */
	public static function absolutize_urls( string $css, string $base ): string {
		return preg_replace_callback(
			'~url\(\s*([\'"]?)(.*?)\1\s*\)~i',
			function ( $m ) use ( $base ) {
				$u = trim( $m[2] );
				if ( '' === $u || 0 === stripos( $u, 'data:' ) || '#' === $u[0] ) {
					return $m[0];
				}
				return 'url("' . Util::abs_url( $u, $base ) . '")';
			},
			$css
		);
	}

	/**
	 * Serialize blocks back to CSS. $selector_cb may rewrite selectors (return '' to drop).
	 */
	public static function serialize( array $blocks, ?callable $selector_cb = null ): string {
		$out    = '';
		$groups = [];
		foreach ( $blocks as $b ) {
			$css = '';
			if ( 'rule' === $b['type'] ) {
				$sels = $b['selectors'];
				if ( $selector_cb ) {
					$sels = array_values( array_filter( array_map( $selector_cb, $sels ) ) );
				}
				if ( ! $sels || ! $b['decls'] ) {
					continue;
				}
				$css = implode( ',', array_unique( $sels ) ) . '{' . self::decls_to_string( $b['decls'] ) . '}';
			} elseif ( 'font-face' === $b['type'] ) {
				$css = '@font-face{' . self::decls_to_string( $b['decls'] ) . '}';
			} elseif ( 'raw' === $b['type'] ) {
				$css = $b['raw'];
			} else {
				continue;
			}
			$groups[] = [ $b['media'], $css ];
		}
		// Merge consecutive blocks with identical media.
		$cur_media = null;
		$buf       = '';
		foreach ( $groups as [ $media, $css ] ) {
			if ( $media !== $cur_media ) {
				$out      .= self::wrap_media( $cur_media, $buf );
				$buf       = '';
				$cur_media = $media;
			}
			$buf .= $css;
		}
		$out .= self::wrap_media( $cur_media, $buf );
		return $out;
	}

	private static function wrap_media( ?string $media, string $css ): string {
		if ( '' === $css ) {
			return '';
		}
		return ( null === $media || '' === $media ) ? $css : '@media ' . $media . '{' . $css . '}';
	}

	public static function decls_to_string( array $decls ): string {
		$s = '';
		foreach ( $decls as [ $p, $v, $imp ] ) {
			$s .= $p . ':' . $v . ( $imp ? '!important' : '' ) . ';';
		}
		return $s;
	}
}
