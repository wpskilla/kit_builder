/* Elementor Remote Page Cloner – admin wizard (no build step, no dependencies). */
(function () {
	'use strict';

	const $ = (s, c) => (c || document).querySelector(s);
	const $$ = (s, c) => Array.from((c || document).querySelectorAll(s));
	const esc = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

	const state = { job: null, report: null, docs: [] };

	async function call(action, data, file) {
		const fd = new FormData();
		fd.append('action', 'erpc_' + action);
		fd.append('nonce', ERPC.nonce);
		Object.entries(data || {}).forEach(([k, v]) => fd.append(k, typeof v === 'object' ? JSON.stringify(v) : v));
		if (file) fd.append('zip', file);
		const res = await fetch(ERPC.ajax, { method: 'POST', body: fd, credentials: 'same-origin' });
		let json;
		try { json = await res.json(); } catch (e) { throw new Error('Server error (HTTP ' + res.status + '). Check PHP error log / memory limit.'); }
		if (!json.success) throw new Error((json.data && json.data.message) || 'Request failed');
		return json.data;
	}

	function unlock(id) { const el = $('#' + id); if (el) el.classList.remove('is-locked'); }
	function lock(id) { const el = $('#' + id); if (el) el.classList.add('is-locked'); }
	function notice(el, msg, type) { el.insertAdjacentHTML('afterbegin', `<div class="erpc-notice is-${type || 'error'}">${esc(msg)}</div>`); }
	function busy(btn, on, label) {
		if (!btn) return;
		if (on) { btn.dataset.label = btn.textContent; btn.textContent = label || 'Working…'; btn.disabled = true; }
		else { btn.textContent = btn.dataset.label || btn.textContent; btn.disabled = false; }
	}

	/* ---------------------------------------------------------- step 1 */
	const form = $('#erpc-source-form');
	if (form) {
		form.addEventListener('submit', async (e) => {
			e.preventDefault();
			const btn = $('#erpc-analyze');
			const box = $('#erpc-analysis');
			$$('.erpc-notice', form.parentNode).forEach((n) => n.remove());
			if (!$('#erpc-consent').checked) { notice(form.parentNode, 'Please confirm you own this page or have permission to reuse it.'); return; }
			busy(btn, true, 'Fetching & analyzing…');
			lock('erpc-step-options'); lock('erpc-step-build');
			try {
				const report = await call('analyze', { url: $('#erpc-url').value, consent: 1 });
				state.job = report.job;
				state.docs = [report.main_doc];
				renderAnalysis(report);
				unlock('erpc-step-analysis');
				$('#erpc-step-analysis').scrollIntoView({ behavior: 'smooth', block: 'start' });
			} catch (err) {
				notice(form.parentNode, err.message);
			} finally { busy(btn, false); }
		});
	}

	/* ---------------------------------------------------------- step 2 */
	function requiredPlugins(r) {
		return r.plugins.filter((p) => p.slug === 'elementor' || (p.ui && p.docs.some((d) => state.docs.includes(d))));
	}

	function renderAnalysis(r) {
		state.report = r;
		const s = r.source;
		const el = s.elementor;
		const layout = el.containers ? 'Flexbox containers' : 'Sections & columns';
		const tmpl = { elementor_canvas: 'Elementor Canvas', elementor_header_footer: 'Elementor Full Width', default: 'Theme default' }[s.template] || s.template;

		let h = `<div class="erpc-stack">
			<div><span>Page</span><strong>${esc(s.title || s.url)}</strong></div>
			<div><span>WordPress</span><strong>${s.is_wordpress ? 'Yes' + (s.wp_version ? ' · ' + esc(s.wp_version) : '') : 'No'}</strong></div>
			<div><span>Theme</span><strong>${esc(s.theme || '—')}</strong></div>
			<div><span>Elementor</span><strong>${el.detected ? esc(el.version || 'yes') : 'No'}${el.pro_version ? ' + Pro' : ''}</strong></div>
			<div><span>Layout</span><strong>${layout}</strong></div>
			<div><span>Page template</span><strong>${esc(tmpl)}</strong></div>
		</div>`;

		(r.warnings || []).forEach((w) => { h += `<div class="erpc-notice is-warning">${esc(w)}</div>`; });

		h += `<h3>What to clone</h3><div class="erpc-docs">`;
		r.documents.forEach((d) => {
			const checked = state.docs.includes(d.id) ? 'checked' : '';
			const chips = d.widgets.map((w) => `<span class="erpc-chip is-${w.mode}" title="${w.mode === 'native' ? 'Rebuilt as a real, editable widget' : 'Kept as static HTML (styled exactly, content not editable as widget)'}">${esc(w.type)} ×${w.count}</span>`).join('');
			h += `<label class="erpc-doc ${d.is_main ? 'is-main' : ''}">
				<input type="checkbox" class="erpc-doc-cb" value="${d.id}" ${checked}>
				<span class="erpc-doc-title">${esc(d.label)}${d.is_main ? ' <em>main</em>' : ''}<small>${d.elements} elements${d.type !== 'wp-page' && d.type !== 'wp-post' ? ' · imported as a template' : ''}</small></span>
				<span class="erpc-chips">${chips || '<em>No widgets</em>'}</span>
			</label>`;
		});
		h += `</div><p class="erpc-legend"><span class="erpc-chip is-native">native</span> real Elementor widget &nbsp; <span class="erpc-chip is-static">static</span> exact-looking HTML fallback (install the add-on below to turn more into native widgets where translators exist)</p>`;

		h += `<h3>Required plugins</h3><div id="erpc-plugins"></div>`;

		if (r.features.length) {
			h += `<h3>Elementor features</h3><table class="erpc-table"><tbody>`;
			r.features.forEach((f) => {
				h += `<tr><td>${esc(f.label)}</td><td>${f.active ? '<span class="erpc-ok">Active</span>' : `<button class="button erpc-feature" data-key="${f.key}">Activate</button>`}</td></tr>`;
			});
			h += `</tbody></table>`;
		}

		if (r.breakpoints.mismatch) {
			const fmt = (o) => Object.entries(o).map(([k, v]) => `${k} ${v}px`).join(', ') || 'default';
			h += `<div class="erpc-notice is-warning">Breakpoints differ — source: ${esc(fmt(r.breakpoints.source))}; this site: ${esc(fmt(r.breakpoints.local))}. Responsive values for breakpoints this site lacks are still applied by the style layer, but you can match them in Elementor › Site Settings › Layout › Breakpoints.</div>`;
		}

		const unknown = Object.keys(r.unknown_widgets || {});
		if (unknown.length) {
			h += `<div class="erpc-notice is-warning">Widgets from unrecognised add-ons (kept as static HTML): ${esc(unknown.join(', '))}</div>`;
		}

		h += `<div class="erpc-actions">
			<button class="button button-primary" id="erpc-install-all">Install & activate all required</button>
			<button class="button" id="erpc-refresh">Re-check</button>
			<button class="button button-primary button-hero" id="erpc-continue">Continue to options →</button>
		</div>`;

		$('#erpc-analysis').innerHTML = h;
		renderPlugins();

		$$('.erpc-doc-cb').forEach((cb) => cb.addEventListener('change', () => {
			state.docs = $$('.erpc-doc-cb').filter((c) => c.checked).map((c) => parseInt(c.value, 10));
			renderPlugins();
		}));
		$$('.erpc-feature').forEach((b) => b.addEventListener('click', async () => {
			busy(b, true, 'Activating…');
			try { await call('feature', { feature: b.dataset.key }); await refresh(); } catch (e) { alert(e.message); busy(b, false); }
		}));
		$('#erpc-install-all').addEventListener('click', installAll);
		$('#erpc-refresh').addEventListener('click', refresh);
		$('#erpc-continue').addEventListener('click', () => {
			if (!state.docs.length) { alert('Select at least one document to clone.'); return; }
			const r2 = state.report;
			if (!r2.elementor_active) { alert('Elementor must be installed and active first.'); return; }
			const inactive = r2.features.filter((f) => !f.active);
			if (inactive.length) { alert('Activate required Elementor features first: ' + inactive.map((f) => f.label).join(', ')); return; }
			renderOptions(r2);
			unlock('erpc-step-options');
			$('#erpc-step-options').scrollIntoView({ behavior: 'smooth', block: 'start' });
		});
	}

	function pluginRow(p, required) {
		let action;
		if (p.status === 'active') action = '<span class="erpc-ok">Active</span>';
		else if (p.source === 'wporg' && state.report.can_install) action = `<button class="button erpc-install" data-slug="${p.slug}">${p.status === 'installed' ? 'Activate' : 'Install & activate'}</button>`;
		else if (p.source === 'premium') action = `${p.buy_url ? `<a href="${esc(p.buy_url)}" target="_blank" rel="noopener">Get license</a> · ` : ''}<label class="erpc-upload">Upload ZIP<input type="file" accept=".zip" class="erpc-zip"></label>`;
		else action = '<em>Manual</em>';
		const why = p.widgets.length ? p.widgets.join(', ') : (p.evidence.includes('page-markup') ? 'page markup' : 'builder');
		const ver = p.source_version ? `source ${esc(p.source_version)}` : '';
		const loc = p.local_version ? ` · here ${esc(p.local_version)}` : '';
		return `<tr class="${required ? '' : 'is-optional'}">
			<td><strong>${esc(p.name)}</strong>${p.note ? `<br><small>${esc(p.note)}</small>` : ''}</td>
			<td><small>${esc(why)}</small></td>
			<td>${p.source === 'wporg' ? 'WordPress.org' : p.source === 'premium' ? 'Premium' : 'Unknown'}</td>
			<td><span class="erpc-status is-${p.status}">${p.status}</span><br><small>${ver}${loc}</small></td>
			<td>${action}</td>
		</tr>`;
	}

	function renderPlugins() {
		const r = state.report;
		const req = requiredPlugins(r);
		const other = r.plugins.filter((p) => !req.includes(p));
		let h = `<table class="erpc-table"><thead><tr><th>Plugin</th><th>Needed for</th><th>Source</th><th>Status</th><th></th></tr></thead><tbody>`;
		req.forEach((p) => { h += pluginRow(p, true); });
		h += `</tbody></table>`;
		if (other.length) {
			h += `<details class="erpc-other"><summary>${other.length} more plugin(s) detected on the source site but not needed for this page</summary><table class="erpc-table"><tbody>`;
			other.forEach((p) => { h += pluginRow(p, false); });
			h += `</tbody></table></details>`;
		}
		const box = $('#erpc-plugins');
		box.innerHTML = h;
		$$('.erpc-install', box).forEach((b) => b.addEventListener('click', async () => {
			busy(b, true, 'Installing…');
			try { await call('install', { job: state.job, slug: b.dataset.slug }); await refresh(); }
			catch (e) { alert(e.message); busy(b, false); }
		}));
		$$('.erpc-zip', box).forEach((inp) => inp.addEventListener('change', async () => {
			if (!inp.files[0]) return;
			inp.parentNode.firstChild.textContent = 'Uploading… ';
			try { await call('upload_zip', {}, inp.files[0]); await refresh(); }
			catch (e) { alert(e.message); inp.parentNode.firstChild.textContent = 'Upload ZIP'; }
		}));
	}

	async function installAll() {
		const btn = $('#erpc-install-all');
		const todo = requiredPlugins(state.report).filter((p) => p.status !== 'active' && p.source === 'wporg');
		if (!todo.length) { await refresh(); return; }
		// Elementor first so add-ons can activate against it.
		todo.sort((a, b) => (a.slug === 'elementor' ? -1 : b.slug === 'elementor' ? 1 : 0));
		const errors = [];
		for (let i = 0; i < todo.length; i++) {
			busy(btn, true, `Installing ${i + 1}/${todo.length}: ${todo[i].name}…`);
			try { await call('install', { job: state.job, slug: todo[i].slug }); }
			catch (e) { errors.push(todo[i].name + ': ' + e.message); }
		}
		busy(btn, false);
		await refresh();
		if (errors.length) notice($('#erpc-analysis'), errors.join(' | '));
	}

	async function refresh() {
		const r = await call('report', { job: state.job });
		const keep = state.docs.slice();
		renderAnalysis(r);
		state.docs = keep;
		$$('.erpc-doc-cb').forEach((c) => { c.checked = keep.includes(parseInt(c.value, 10)); });
		renderPlugins();
	}

	/* ---------------------------------------------------------- step 3 */
	function renderOptions(r) {
		const d = r.defaults;
		const pages = (ERPC.pages || []).map((p) => `<option value="${p.id}">${esc(p.title)} (#${p.id})</option>`).join('');
		const missingPremium = requiredPlugins(r).filter((p) => p.status !== 'active');
		let h = '';
		if (missingPremium.length) {
			h += `<div class="erpc-notice is-warning">Not active: ${esc(missingPremium.map((p) => p.name).join(', '))}. Their widgets will be kept as static HTML (looks the same, not editable as widgets).</div>`;
		}
		h += `<div class="erpc-grid">
			<label>Page title<input type="text" id="o-title" value="${esc(d.title)}"></label>
			<label>Status<select id="o-status"><option value="draft">Draft</option><option value="publish">Published</option><option value="private">Private</option></select></label>
			<label>Page template<select id="o-template">
				<option value="source">Same as source</option><option value="elementor_header_footer">Elementor Full Width</option>
				<option value="elementor_canvas">Elementor Canvas</option><option value="default">Theme default</option></select></label>
		</div>
		<fieldset class="erpc-target"><legend>Create as</legend>
			<label><input type="radio" name="o-target" value="new" checked> New page</label>
			<label><input type="radio" name="o-target" value="replace"> Replace content of an existing page <select id="o-replace"><option value="">— choose —</option>${pages}</select></label>
			<label><input type="radio" name="o-target" value="template"> Elementor library template</label>
		</fieldset>
		<fieldset class="erpc-checks"><legend>Content & media</legend>
			<label><input type="checkbox" id="o-media" ${d.import_media ? 'checked' : ''}> Import images, SVGs and fonts into this site</label>
			<label><input type="checkbox" id="o-videos" ${d.import_videos ? 'checked' : ''}> Also import self-hosted videos (can be large)</label>
			<label><input type="checkbox" id="o-links" ${d.rewrite_links ? 'checked' : ''}> Point links to the source domain at this site instead</label>
			<label><input type="checkbox" id="o-hide" ${d.hide_title ? 'checked' : ''}> Hide the theme's page title</label>
			<label><input type="checkbox" id="o-scripts" ${d.keep_scripts ? 'checked' : ''}> Keep &lt;script&gt; tags in HTML widgets (trusted sources only)</label>
		</fieldset>
		<fieldset class="erpc-checks"><legend>Fidelity</legend>
			<label><input type="radio" name="o-fid" value="editable" ${d.fidelity !== 'locked' ? 'checked' : ''}> Editable — exact source look, and your Elementor edits always win</label>
			<label><input type="radio" name="o-fid" value="locked" ${d.fidelity === 'locked' ? 'checked' : ''}> Locked — the source look always wins over edits</label>
		</fieldset>
		<div class="erpc-actions"><button class="button button-primary button-hero" id="erpc-start">Clone now</button></div>`;
		$('#erpc-options').innerHTML = h;
		$('#o-status').value = d.status;
		$('#o-template').value = d.template;
		$('#erpc-start').addEventListener('click', start);
	}

	function options() {
		const target = $('input[name="o-target"]:checked').value;
		return {
			docs: state.docs,
			title: $('#o-title').value,
			status: $('#o-status').value,
			template: $('#o-template').value,
			target,
			replace_id: target === 'replace' ? $('#o-replace').value : 0,
			import_media: $('#o-media').checked ? 1 : 0,
			import_videos: $('#o-videos').checked ? 1 : 0,
			rewrite_links: $('#o-links').checked ? 1 : 0,
			hide_title: $('#o-hide').checked ? 1 : 0,
			keep_scripts: $('#o-scripts').checked ? 1 : 0,
			fidelity: $('input[name="o-fid"]:checked').value,
		};
	}

	/* ---------------------------------------------------------- step 4 */
	async function start() {
		const opts = options();
		if (opts.target === 'replace' && !opts.replace_id) { alert('Choose the page to replace.'); return; }
		if (opts.target === 'replace' && !confirm('The selected page\'s current Elementor content will be replaced (a backup is kept for Undo). Continue?')) return;
		const btn = $('#erpc-start');
		busy(btn, true, 'Cloning…');
		unlock('erpc-step-build');
		const box = $('#erpc-build');
		box.innerHTML = `<div class="erpc-progress"><div class="erpc-bar"><span style="width:0%"></span></div><ol class="erpc-log"></ol></div>`;
		$('#erpc-step-build').scrollIntoView({ behavior: 'smooth', block: 'start' });
		const log = (m) => $('.erpc-log', box).insertAdjacentHTML('beforeend', `<li>${esc(m)}</li>`);
		const bar = (p) => { $('.erpc-bar span', box).style.width = Math.max(2, Math.min(100, p)) + '%'; };
		try {
			log('Converting layout, widgets and styles…');
			const prep = await call('prepare', { job: state.job, options: opts });
			bar(10);
			let done = prep.done, total = prep.total;
			log(total ? `Importing ${total} media file(s)…` : 'No media to import.');
			const mediaErrors = [];
			let guard = 0;
			while (done < total && guard++ < 500) {
				const m = await call('media', { job: state.job });
				done = m.done; total = m.total;
				(m.errors || []).forEach((e) => mediaErrors.push(e));
				bar(10 + (done / Math.max(1, total)) * 75);
				$('.erpc-log li:last-child', box).textContent = `Importing media… ${done}/${total}`;
			}
			log('Building Elementor page(s)…');
			const res = await call('build', { job: state.job });
			bar(100);
			renderResult(box, res, mediaErrors);
		} catch (e) {
			notice(box, e.message);
		} finally { busy(btn, false); }
	}

	function renderResult(box, res, mediaErrors) {
		let h = '<div class="erpc-result">';
		res.posts.forEach((p) => {
			const c = p.report.counts;
			const score = c.widgets ? Math.round((c.native / c.widgets) * 100) : 100;
			h += `<div class="erpc-result-card">
				<h3>${esc(p.title)} <small>${esc(p.type)} #${p.post_id}</small></h3>
				<p class="erpc-metrics"><span><b>${c.elements}</b> elements</span><span><b>${c.native}</b> native widgets</span><span><b>${c.fallback}</b> static fallbacks</span><span><b>${score}%</b> editable</span></p>
				<p><a class="button button-primary" href="${esc(p.edit_url)}" target="_blank">Edit with Elementor</a>
				${p.view_url ? `<a class="button" href="${esc(p.view_url)}" target="_blank">View</a>` : ''}
				<a class="button" href="${esc(state.report.source.url)}" target="_blank" rel="noopener">Open source</a></p>`;
			if (p.report.fallbacks.length) {
				h += `<details><summary>Static fallbacks (${p.report.fallbacks.length})</summary><ul>${p.report.fallbacks.map((f) => `<li><code>${esc(f.type)}</code> #${esc(f.id)} — ${esc(f.reason)}</li>`).join('')}</ul></details>`;
			}
			if (p.report.warnings.length) {
				h += `<ul class="erpc-warn">${p.report.warnings.map((w) => `<li>${esc(w)}</li>`).join('')}</ul>`;
			}
			h += '</div>';
		});
		const dropped = res.dropped || {};
		const dcount = Object.values(dropped).reduce((a, o) => a + Object.keys(o).length, 0);
		if (dcount) {
			h += `<details><summary>${dcount} setting key(s) not supported by this site's Elementor version (still rendered by the style layer)</summary><pre>${esc(JSON.stringify(dropped, null, 1))}</pre></details>`;
		}
		const merr = (res.media_errors || []).concat(mediaErrors);
		if (merr.length) {
			h += `<details><summary>${merr.length} media file(s) kept as remote URLs</summary><ul>${[...new Set(merr)].map((e) => `<li>${esc(e)}</li>`).join('')}</ul></details>`;
		}
		h += `<p><button class="button erpc-undo" data-job="${esc(res.job)}">Undo this clone</button></p></div>`;
		box.insertAdjacentHTML('beforeend', h);
		bindUndo(box);
	}

	function bindUndo(ctx) {
		$$('.erpc-undo', ctx).forEach((b) => b.addEventListener('click', async () => {
			if (!confirm('Delete the cloned page(s) and the media this clone imported (replaced pages are restored)?')) return;
			busy(b, true, 'Undoing…');
			try { await call('undo', { job: b.dataset.job }); b.textContent = 'Undone'; }
			catch (e) { alert(e.message); busy(b, false); }
		}));
	}
	bindUndo(document);
})();
